package com.ps.jinja;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.ps.jinja.AsynTask.ProductsListAsyncTask;
import com.ps.jinja.adapters.ProductsListAdapter;
import com.ps.jinja.adapters.ShoppingSubCatAdapter;
import com.ps.jinja.listItems.ProductsListItem;
import com.ps.jinja.listItems.ShoppingSubCatListItem;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class ProductsList extends Activity implements OnClickListener{
	ListView productsListView;
	ImageView backImv;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.get_sh_products_list);
		int catId=getIntent().getExtras().getInt("sendId");
		String catTitle=getIntent().getExtras().getString("sendTitle");
		TextView titleTxt=(TextView) findViewById(R.id.get_sh_products_list_title_tv);
		titleTxt.setText(catTitle);
		productsListView=(ListView) findViewById(R.id.get_sh_products_list_products_listView);
		backImv=(ImageView) findViewById(R.id.get_sh_products_list_back_imv);
		backImv.setOnClickListener(this);
		Log.i(String.valueOf(catId), "Cat Id");
		ProductsListAsyncTask runner=new ProductsListAsyncTask(this);
		runner.execute(String.valueOf(catId));
		
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.get_sh_cat_back_imv:
			finish();
			break;

		default:
			break;
		}
		
	}
	public void loadNewsSubCategoryList(String jsonResult) {
		// TODO Auto-generated method stub
		final List<ProductsListItem> productsList=new ArrayList<ProductsListItem>();
		try {
			JSONArray productListJsonArray=new JSONArray(jsonResult);
			for(int i=0;i<productListJsonArray.length();i++){
				JSONObject productListJsonObj=productListJsonArray.getJSONObject(i);
				productsList.add(new ProductsListItem(productListJsonObj.getInt("product_id"),
						productListJsonObj.getString("product_name"), productListJsonObj.getString("image_url"), 
						productListJsonObj.getInt("category_id"), productListJsonObj.getInt("status"), 
						productListJsonObj.getInt("price")));
						}
			ListAdapter newAdapter=new ProductsListAdapter(productsList,this);
			productsListView.setAdapter(newAdapter);
			productsListView.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1,
						int arg2, long arg3) {
					// TODO Auto-generated method stub
					ProductsListItem item=productsList.get(arg2);
					int sendId=item.getpId();
//					String sendTitle=item.getsSubTitle();
//					Toast.makeText(getApplicationContext(), "Hai"+item, Toast.LENGTH_SHORT).show();
					Intent productListIntent=new Intent(ProductsList.this, Product.class);
					productListIntent.putExtra("sendId", sendId);
					startActivity(productListIntent);
			
					
					
				}
			});
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
