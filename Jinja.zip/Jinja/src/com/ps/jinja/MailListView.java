package com.ps.jinja;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.ps.jinja.adapters.NewsListItemAdapter;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class MailListView extends Activity {
	String url1 = "http://mem01flux.fluxmachine.com/services/call.php?url=get-news&category_id=";
	String url;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mail_list_view);
		
		TextView fromGridTitle = (TextView) findViewById(R.id.get_title_fromgrid_tv);
		TextView fromGridId = (TextView) findViewById(R.id.get_id_fromgrid_tv);

		ListView showDetilTiltle = (ListView) findViewById(R.id.show_grid_title_list_tv);
		String gridTitle = getIntent().getStringExtra("sendCatTitle");
		fromGridTitle.setText(gridTitle + "--Top News");
		int gridId = getIntent().getExtras().getInt("sendCatId");
		fromGridId.setText(String.valueOf(gridId));
		Log.i(String.valueOf(gridId), "recieved");
		url = url1 + gridId;
		Log.i(url1, "dfaf");
		Log.i(url, "fjshf");
		HttpClient newsHttpclient = new DefaultHttpClient();
		HttpPost newsHttppost = new HttpPost(url);
		try {
			HttpResponse newsHttpResponse = newsHttpclient
					.execute(newsHttppost);
			String newsJsonResult = inputStreamToString(
					newsHttpResponse.getEntity().getContent()).toString();
			JSONArray newsJsonArray = new JSONArray(newsJsonResult);
			final List<NewsListItem> myJsonArrayList = new ArrayList<NewsListItem>(
					5);

			for (int i = 0; i < newsJsonArray.length(); i++) {
				JSONObject newsJObj = (JSONObject) newsJsonArray.get(i);
				int newsCatId = newsJObj.getInt("category_id");
				int newsEntId = newsJObj.getInt("entry_id");
				String newsTitle = newsJObj.getString("title");
				String newsDiscription = newsJObj.getString("description");
				String imageUrl = newsJObj.getString("image_url");

				myJsonArrayList.add(new NewsListItem(newsCatId, newsEntId,
						newsTitle, newsDiscription, imageUrl));
			}
			ListAdapter adapter = new NewsListItemAdapter(myJsonArrayList,
					this);
			showDetilTiltle.setAdapter(adapter);
			showDetilTiltle.setTextFilterEnabled(true);
			showDetilTiltle.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1,
						int position, long arg3) {
					// TODO Auto-generated method stub
					final NewsListItem item = myJsonArrayList.get(position);
					Intent newIntent = new Intent(MailListView.this,
							DisplayListDetails.class);
					int sendeId = item.geteId();
					newIntent.putExtra("sendeId", sendeId);
					startActivity(newIntent);

				}
			});
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private StringBuilder inputStreamToString(InputStream is) {
		// TODO Auto-generated method stub
		String rLine = "";
		StringBuilder answer = new StringBuilder();

		InputStreamReader isr = new InputStreamReader(is);

		BufferedReader rd = new BufferedReader(isr);

		try {
			while ((rLine = rd.readLine()) != null) {
				answer.append(rLine);
			}
		}

		catch (IOException e) {
			e.printStackTrace();
		}
		return answer;

	}
}
