package com.ps.jinja;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.ps.jinja.AsynTask.MenuMagazineAsyncTask;
import com.ps.jinja.AsynTask.MenuSubscriptionAsyncTask;
import com.ps.jinja.adapters.CategoryListMenuAdapter;
import com.ps.jinja.adapters.MagazineGridAdap;
import com.ps.jinja.adapters.MyGridListItemAdapter;
import com.ps.jinja.constants.URLConstants;
import com.ps.jinja.session.SessionHandler;
import com.ps.jinja.utils.ApiHelper;
import com.ps.jinja.utils.ImageHelper;
import com.ps.jinja.vo.UserVO;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class MenuOption extends Activity {
	TextView menuUserName, myJinjaUserName, addSubscription;
	GridView magaGridView;
	ListView listViewCate;
	String[] values = new String[] { "My JinJa", "Classifieds", "Notifications","Shopping",
			"Friends", };

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.menu_option_layout);
		addSubscription = (TextView) findViewById(R.id.My_jinja_relative_subscription_edit_title_tv);
		menuUserName = (TextView) findViewById(R.id.menu_option_user_name_tv);
		magaGridView = (GridView) findViewById(R.id.My_jinja_magazine_gridview);
		myJinjaUserName = (TextView) findViewById(R.id.My_jinja_relative_user_name_tv);
		listViewCate = (ListView) findViewById(R.id.menu_option_categories_listView);
		ImageView userImageview = (ImageView) findViewById(R.id.My_jinja_relative_user_imv);
		final ListView listAccount = (ListView) findViewById(R.id.menu_option_user_account_lv);
		UserVO userVO = SessionHandler.get().getUserVO();
		if (null != userVO) {
			menuUserName.setText(userVO.getfName() + " " + userVO.getlName());
			myJinjaUserName
					.setText(userVO.getfName() + " " + userVO.getlName());
			String userImage = userVO.getImageUrl();
			ImageHelper.loadImage(userImageview, userImage, true, true, 30);
			Button signOut = (Button) findViewById(R.id.sign_out_btn);
			signOut.setVisibility(View.VISIBLE);
			signOut.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					Intent newIntent = new Intent(getApplicationContext(),
							SplashLogActivity.class);
					startActivity(newIntent);

				}
			});
			MenuSubscriptionAsyncTask runner=new MenuSubscriptionAsyncTask(this);
			runner.execute();
			MenuMagazineAsyncTask runner1=new MenuMagazineAsyncTask(this);
			runner1.execute("");

			
		} else {
			addSubscription.setVisibility(View.GONE);
			String guest = "Guest";
			menuUserName.setText(guest);
			myJinjaUserName.setText(guest);
			ImageHelper.loadImage(userImageview, URLConstants.GUEST_IMAGE,
					true, true, 30);
			Button logIn = (Button) findViewById(R.id.log_in_btn);
			logIn.setVisibility(View.VISIBLE);
			logIn.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent newIntent = new Intent(getApplicationContext(),
							SplashLogActivity.class);
					startActivity(newIntent);
				}
			});
			
			
			try {
				String JsonResult = ApiHelper
						.getHttpResponseAsString(URLConstants.CATEGORIES_URL);
				if (JsonResult == null) {
					return;
				}
				JSONArray catsJsonArray = new JSONArray(JsonResult);

				final List<CatListItem> JsonArrayList = new ArrayList<CatListItem>(
						2);

				for (int i = 0; i < catsJsonArray.length(); i++) {
					JSONObject catsJObj = (JSONObject) catsJsonArray.get(i);
					int newsCatId = catsJObj.getInt("category_id");
					String newsTitle = catsJObj.getString("category_name");
					String newsImage = catsJObj.getString("image_url");
					Log.i(newsImage, "Categories Image In Grid");
					JsonArrayList.add(new CatListItem(newsCatId, newsTitle));
					
				}
				ListAdapter adp = new CategoryListMenuAdapter(JsonArrayList, this);

				listViewCate.setAdapter(adp);
				listViewCate.setOnItemClickListener(new OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> arg0, View arg1,
							int position, long arg3) {
						// TODO Auto-generated method stub
						CatListItem catitem = JsonArrayList.get(position);
						Intent newCatIntent = new Intent(MenuOption.this,
								SubCategoriesNewsPage.class);
						int sendCatId = catitem.getcId();
						String sendCatTitle = catitem.getcTitle();
						Log.i(String.valueOf(sendCatId), "fhfgj");
						newCatIntent.putExtra("sendId", sendCatId);
						newCatIntent.putExtra("sendTitle", sendCatTitle);
						startActivity(newCatIntent);

					}
				});
				

				


			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		
		ArrayAdapter<String> adapterList = new ArrayAdapter<String>(this,
				R.layout.example, R.id.textvey, values);

		listAccount.setAdapter(adapterList);
		listAccount.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				int itemposition = position;
				String itemvalue = (String) listAccount
						.getItemAtPosition(position);
				Toast.makeText(getApplicationContext(), "" + itemvalue,
						Toast.LENGTH_SHORT).show();
				if (itemvalue == "Classifieds") {
					Intent classifiesIntent = new Intent(MenuOption.this,
							Classified.class);
					startActivity(classifiesIntent);
				}
				else if (itemvalue=="Shopping"){
					Intent shoppingIntent=new Intent(MenuOption.this, Shopping.class);
					startActivity(shoppingIntent);
				}
			}
		});

	

	}

	@Override
	protected void onResume() {

		super.onResume();
		this.onCreate(null);
	}

	public void onBackPressed() {

		finish();

	}

	public void loadMenuSubcription(String jsonResult) {
		// TODO Auto-generated method stub
//		String getSubscription = ApiHelper
//				.getHttpResponseAsString(URLConstants.GET_SUBSCRIPTIONS_URL
//						+ "&user_id=" + userVO.getUserId());
		String JsonRe = ApiHelper
				.getHttpResponseAsString(URLConstants.CATEGORIES_URL);
		JSONObject getSubObj;
		try {
			getSubObj = new JSONObject(jsonResult);
		
		final String commaValu = getSubObj.getString("category_ids");

		String[] subArray = commaValu.split(",");
		HashSet<String> subsCatSet = new HashSet<String>(
				Arrays.asList(subArray));
		JSONArray catsLeftJsonArray = new JSONArray(JsonRe);
		final List<MyGridCustomListItem> myJsonArrayList = new ArrayList<MyGridCustomListItem>(
				5);
		
		final List<CatListItem> JsonArrayList = new ArrayList<CatListItem>(
				2);
		
		for (int j = 0; j < catsLeftJsonArray.length(); j++) {
			JSONObject catsJObj = (JSONObject) catsLeftJsonArray.get(j);
			int newsCatId = catsJObj.getInt("category_id");
			String newsTitle = catsJObj.getString("category_name");
			String newsImage = catsJObj.getString("image_url");
			Log.i(newsImage, "Categories Image In Grid");
			if (subsCatSet.contains(newsCatId + "")) {
				myJsonArrayList.add(new MyGridCustomListItem(newsCatId,
						newsTitle, newsImage));
				JsonArrayList.add(new CatListItem(newsCatId, newsTitle));
			}
			

		}
		ListAdapter adp = new CategoryListMenuAdapter(JsonArrayList, this);
		listViewCate.setAdapter(adp);
		listViewCate.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1,
					int position, long arg3) {
				// TODO Auto-generated method stub
				CatListItem catitem = JsonArrayList.get(position);
				Intent newCatIntent = new Intent(MenuOption.this,
						SubCategoriesNewsPage.class);
				int sendCatId = catitem.getcId();
				String sendCatTitle = catitem.getcTitle();
				Log.i(String.valueOf(sendCatId), "fhfgj");
				newCatIntent.putExtra("sendId", sendCatId);
				newCatIntent.putExtra("sendTitle", sendCatTitle);
				startActivity(newCatIntent);

			}
		});
		
		
		
		ListAdapter adapter = new MyGridListItemAdapter(myJsonArrayList,
				this);
		GridView newsGrid = (GridView) findViewById(R.id.My_jinja_relative_subscription_gridView);
		newsGrid.setAdapter(adapter);
		newsGrid.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1,
					int position, long arg3) {
				final MyGridCustomListItem item = myJsonArrayList
						.get(position);
				Intent newIntent = new Intent(MenuOption.this,
						SubCategoriesNewsPage.class);
				int sendId = item.getgId();
				String sendTitle = item.getgTitle();
				newIntent.putExtra("sendTitle", sendTitle);
				newIntent.putExtra("sendId", sendId);

				newIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

				startActivity(newIntent);

			}
		});
		addSubscription.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent newIntent = new Intent(MenuOption.this,
						AddSubscription.class);
				newIntent.putExtra("commaValu", commaValu);
				startActivity(newIntent);

			}
		});
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void loadMenuMagazine(String jsonResult) {
		// TODO Auto-generated method stub

		try {

			final List<MagListItem> MagazineArrayList = new ArrayList<MagListItem>();
			JSONArray detailArray = new JSONArray(jsonResult);
			for (int i = 0; i < detailArray.length(); i++) {
				JSONObject newsJObj = (JSONObject) detailArray.get(i);
				String newsDetTitle = newsJObj.getString("title");
				Log.i(newsDetTitle, "detTitle");
				String newsDetimageUrl = newsJObj.getString("image_url");
				int newsDetEntryId = newsJObj.getInt("news_id");
				MagazineArrayList.add(new MagListItem(newsDetimageUrl,
						newsDetTitle, newsDetEntryId));

			}
			ListAdapter mag_adapter = new MagazineGridAdap(
					MagazineArrayList, this);

			magaGridView.setAdapter(mag_adapter);
			magaGridView.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1,
						int position, long arg3) {
					// TODO Auto-generated method stub
					final MagListItem item = MagazineArrayList
							.get(position);
					Intent newIntent = new Intent(MenuOption.this,
							DisplayListDetails.class);
					int sendId = item.getcEid();
					newIntent.putExtra("sendeId", sendId);
					startActivity(newIntent);

				}
			});



		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
