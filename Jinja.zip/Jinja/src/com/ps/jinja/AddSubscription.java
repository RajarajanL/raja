package com.ps.jinja;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.ps.jinja.adapters.AddSubscriptionAdapter;
import com.ps.jinja.constants.URLConstants;
import com.ps.jinja.session.SessionHandler;
import com.ps.jinja.utils.ApiHelper;
import com.ps.jinja.vo.UserVO;
import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ListView;
import android.widget.Toast;

public class AddSubscription extends Activity {
	ListView categoriesList;
	Button update,cancel;
	ArrayList<SubscriptionItems> catJsonArrayList;
	AddSubscriptionAdapter<SubscriptionItems> adpapter;
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add_subscription_categories);
		categoriesList=(ListView) findViewById(R.id.add_subscription_categories_listview);
		update=(Button) findViewById(R.id.add_subscription_categories_update_btn);
		cancel=(Button) findViewById(R.id.add_subscription_categories_cancel_btn);
		String categoryApi=ApiHelper.getHttpResponseAsString(URLConstants.CATEGORIES_URL);
		final UserVO userVO = SessionHandler.get().getUserVO();
		int userId=userVO.getUserId();
		
			try {
				JSONArray catJsonArray=new JSONArray(categoryApi);
				catJsonArrayList=new ArrayList<SubscriptionItems>();
//				String subcribedCategory=ApiHelper.getHttpResponseAsString("http://mem01flux.fluxmachine.com/services/call.php?url=get-subscriptions&user_id="+userId);
//				JSONObject jobj=new JSONObject(subcribedCategory);
//				String catIds=jobj.getString("category_ids");
//				Log.i(catIds, "Cat Ids");
//				Log.i(String.valueOf(userId), "User Id Cat Ids");
				String catIds=getIntent().getExtras().getString("commaValu");
				Log.i(catIds, "Cat Intent Ids");
				String[] subArray = catIds.split(",");
				HashSet<String> subsCatSet = new HashSet<String>(Arrays.asList(subArray));
				for(int i=0;i<catJsonArray.length();i++){
					JSONObject catJOBj=(JSONObject) catJsonArray.get(i);
					int catIdSub=catJOBj.getInt("category_id");
					String catNameSub=catJOBj.getString("category_name");
					boolean isSubscribed = (subsCatSet.contains(catIdSub+""))?true:false;
					catJsonArrayList.add(new SubscriptionItems(catIdSub, catNameSub,isSubscribed));
				}
				 adpapter=new AddSubscriptionAdapter(catJsonArrayList, this);
				categoriesList.setAdapter(adpapter);
				cancel.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						finish();
						
					}
				});
				update.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						if(adpapter!=null){
							
							
							List<SubscriptionItems> mArrayProducts = adpapter.getCheckedItems();
							Log.d(AddSubscription.class.getSimpleName(), "Selected Items: " + mArrayProducts.toString());
							String addSub="";
							Boolean is=false;
							for(SubscriptionItems si : mArrayProducts){
//								Toast.makeText(getApplicationContext(), si.getcTitle(), Toast.LENGTH_SHORT).show();
								if(is==false){
									addSub+=String.valueOf(si.getcId());
									is=true;
								}else{
								addSub+=","+String.valueOf(si.getcId());
								}
							}
							Log.i(addSub, "Appended Id With comma");
							if(null!=userVO){
								int userId=userVO.getUserId();
								Log.i(String.valueOf(userId), "User In");
								Log.i(addSub, "Appended Id user");
								
								HttpClient mClient= new DefaultHttpClient();

								HttpGet get = new HttpGet(URLConstants.UPLOAD_SUBSCRIPTION
										+ "&user_id=" + userId + "&category_ids="
										+ addSub);
								
								
								try {
									mClient.execute(get);
									
									finish();
								} catch (ClientProtocolException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}

								 
								
						
							}
						}
						
					}
				});
//				final CheckBox selectAllCheck=(CheckBox) findViewById(R.id.add_subscription_selectall_checkbox);
//				selectAllCheck.setOnClickListener(new OnClickListener() {
//
//			        public void onClick(View v) {
//			            // TODO Auto-generated method stub
//			            int size = 0;
//			            boolean isChecked = selectAllCheck.isChecked();
//			            if (isChecked == true) {
//			                size = adpapter.getCount();
//			                for (int i = 0; i <= size; i++)
//			                    categoriesList.setItemChecked(i, true);
//			            } else if(isChecked==false)
//			            {
//			                size = adpapter.getCount();
//			                for (int i = 0; i <= size; i++)
//			                    categoriesList.setItemChecked(i, false);
//			            }
//			        }
//			    });
				
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			
		}
	}

}
