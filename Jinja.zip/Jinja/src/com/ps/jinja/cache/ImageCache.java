package com.ps.jinja.cache;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class ImageCache {

	private static ImageCache singleton = new ImageCache();
	private static HashMap<String, Bitmap> imageCacheMap = new HashMap<String, Bitmap>();
	private ImageCache(){
		
	}
	
	public static ImageCache get(){
		return singleton;
	}
	
	
	public Bitmap getBitmapFromCache(String src){
		try {
			Bitmap myBitmap = null;
			if(!imageCacheMap.containsKey(src)){
		        URL url = new URL(src);
		        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		        connection.setDoInput(true);
		        connection.connect();
		        InputStream input = connection.getInputStream();
		        myBitmap = BitmapFactory.decodeStream(input);
		        input.close();
		        imageCacheMap.put(src, myBitmap);
			}else{
				myBitmap = imageCacheMap.get(src);
			}
	        return myBitmap;
	    } catch (IOException e) {
	        e.printStackTrace();
	        return null;
	    }
	}
	
}
