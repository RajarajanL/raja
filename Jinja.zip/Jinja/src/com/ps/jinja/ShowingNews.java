package com.ps.jinja;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.TextView;

import com.aphidmobile.flip.FlipViewController;
import com.ps.jinja.AsynTask.ShowingNewsAsynTask;
import com.ps.jinja.adapters.NewsListItemAdapter;

public class ShowingNews extends Activity implements OnClickListener {
	ImageView backImage,menuImageView;
	protected FlipViewController flipview;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.diplaying_subcategory_list);
		backImage=(ImageView) findViewById(R.id.dis_subcat_top_lay_back_imv);
		menuImageView=(ImageView) findViewById(R.id.dis_subcat_top_lay_menu_imv);
		flipview=(FlipViewController) findViewById(R.id.mail_main_displayCatTitle_Sub_cat_FlipView);
		TextView title=(TextView) findViewById(R.id.dis_subcat_top_lay_title_tv);
		int gridId=getIntent().getExtras().getInt("sendCatId");
		String titleTxt=getIntent().getExtras().getString("sendCatTitle");
		title.setText(titleTxt);
		 ShowingNewsAsynTask runner1=new ShowingNewsAsynTask(this);
         runner1.execute(String.valueOf(gridId));
		
		


}
	public void loadShowNewsFlip(String jsonResult) {
		// TODO Auto-generated method stub
		int no_Of_part=4;
		List<NewsListItem> partitionList=new ArrayList<NewsListItem>();
		final List<List<NewsListItem>> flipList=new ArrayList<List<NewsListItem>>();
		try {
			int counter=0;
			final JSONArray newsJsonArray = new JSONArray(jsonResult);
			for(int i=0;i<newsJsonArray.length();i++)
				{
					JSONObject newsJObj=(JSONObject)newsJsonArray.get(i);
					int newsCatId=newsJObj.getInt("category_id");
					int newsEntId=newsJObj.getInt("entry_id");
					String newsTitle=newsJObj.getString("title");
					String newsDiscription=newsJObj.getString("description");
					String imageUrl=newsJObj.getString("image_url");
					Log.i(imageUrl, "New Image Url");
					partitionList.add(new NewsListItem(newsCatId, newsEntId, newsTitle, newsDiscription, imageUrl));
					
					counter++;
					if(counter%no_Of_part==0||counter==newsJsonArray.length()){
						flipList.add(partitionList);
						partitionList=new ArrayList<NewsListItem>();
					}
				         
				  
				}
			flipview.setAdapter(new BaseAdapter() {

				@Override
				public int getCount() {
					return flipList.size();
				}

				@Override
				public Object getItem(int position) {
					return position;
				}

				@Override
				public long getItemId(int position) {
					return position;
				}

				@Override
				public View getView(int position, View convertView,
						ViewGroup parent) {

					LinearLayout itemLayout = null;
					final Context context = parent.getContext();
					final List<NewsListItem> items = flipList.get(position);
						
					ListAdapter adapter = new NewsListItemAdapter(items, context);

					
					itemLayout = (LinearLayout) LayoutInflater.from(context)
							.inflate(R.layout.jinja_main_flip_showing_news_list_item,
									parent, false);
					// Set the icon as defined in our list item
					GridView flipGrid = (GridView) itemLayout
							.findViewById(R.id.jinja_main_showing_news_flip_grid_view);
					flipGrid.setAdapter(adapter);
					flipGrid.setTextFilterEnabled(true);
					flipGrid.setOnItemClickListener(new OnItemClickListener() {
		
						@Override
						public void onItemClick(AdapterView<?> arg0, View arg1,
								int position, long arg3) {
							// TODO Auto-generated method stub
							final NewsListItem item = items
									.get(position);
							Intent newIntent = new Intent(ShowingNews.this,
									DisplayListDetails.class);
							int sendId = item.geteId();
							newIntent.putExtra("sendeId", sendId);
							startActivity(newIntent);
							
						}
					});
					
					
					
					return itemLayout;
				}
			});
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.dis_subcat_top_lay_back_imv:
			finish();
			break;
		case R.id.dis_subcat_top_lay_menu_imv:
			
			Intent newIntent=new Intent(ShowingNews.this, MenuOption.class);
			startActivity(newIntent);
			break;
		default:
			break;
		}
		
		
	}

	}


