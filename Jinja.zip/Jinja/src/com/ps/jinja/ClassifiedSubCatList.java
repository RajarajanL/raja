package com.ps.jinja;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.ps.jinja.adapters.ClassSubCatListAdaAdapter;
import com.ps.jinja.constants.URLConstants;
import com.ps.jinja.session.SessionHandler;
import com.ps.jinja.utils.ApiHelper;
import com.ps.jinja.utils.ImageHelper;
import com.ps.jinja.vo.UserVO;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


public class ClassifiedSubCatList extends Activity implements OnClickListener{
	TextView userNameTxt;
	ImageView userImageview,backimv;
	ListView catList;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.classified_sub_category_list);
		backimv = (ImageView) findViewById(R.id.clas_sub_cat_list_back_imv);
		backimv.setOnClickListener(this);
		userNameTxt = (TextView) findViewById(R.id.clas_sub_cat_list_user_name_tv);
		userImageview = (ImageView) findViewById(R.id.clas_sub_cat_list_userImage_imv);
		catList = (ListView) findViewById(R.id.clas_sub_cat_list_listview);
		int catId = getIntent().getExtras().getInt("catId");
		String aa = URLConstants.CLASSIFIED_GET_CLASSIFIEDS_BY_CAT_ID
				+ "&category_id=" + catId;
		Toast.makeText(getApplicationContext(), aa, Toast.LENGTH_LONG).show();
		UserVO userVO = SessionHandler.get().getUserVO();
		try {
			if (null != userVO) {
				userNameTxt
						.setText(userVO.getfName() + " " + userVO.getlName());
				String userImage = userVO.getImageUrl();
				if (userImage.equals("") || userImage == null) {
					Log.i(userImage, "User Image Empty");

				} else {
					Log.i(userImage, "image");

				}
				URL url = new URL(userImage);
				Bitmap bmp = BitmapFactory.decodeStream(url.openConnection()
						.getInputStream());
				Bitmap finalImg = ImageHelper.getRoundedCornerBitmap(bmp, 10);
				userImageview.setImageBitmap(finalImg);
			} else {
				userNameTxt.setText("Guest");
				URL url = new URL(URLConstants.GUEST_IMAGE);
				Bitmap bmp = BitmapFactory.decodeStream(url.openConnection()
						.getInputStream());
				Bitmap finalImg = ImageHelper.getRoundedCornerBitmap(bmp, 10);
				userImageview.setImageBitmap(finalImg);
			}

		} catch (IOException e) {
			Log.e("Debug", "error: " + e.getMessage(), e);
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String clasSubJsonStringResult = ApiHelper
				.getHttpResponseAsString(URLConstants.CLASSIFIED_GET_CLASSIFIEDS_BY_CAT_ID
						+ "&category_id=" + catId);

		try {
			final JSONArray clasSubJsonArray = new JSONArray(
					clasSubJsonStringResult);
			final List<ClassfiedSubCatListItem> classSubList = new ArrayList<ClassfiedSubCatListItem>();
//			for(int i=0;i<6;i++){
//			int id = 1;
//			String image = "http://www.motorbeam.com/wp-content/uploads/Honda_CBR250R_HRC.jpg";
//			String postDate = "posted_date";
//			String title="title";
//			String address="address";
//			int price=4444;
//			int userId=22;
//			int categoryId=3;
//			String fName="f_name";
//			classSubList.add(new ClassfiedSubCatListItem(id, title, image, postDate, address, price, userId, categoryId, fName));
//			}
			for (int i = 0; i < clasSubJsonArray.length(); i++) {
				JSONObject newsJObj = (JSONObject) clasSubJsonArray.get(i);
				int id = newsJObj.getInt("id");
				String image = newsJObj.getString("image_url");
				String postDate = newsJObj.getString("posted_date");
				String title=newsJObj.getString("title");
				String address=newsJObj.getString("address");
				int price=newsJObj.getInt("price");
//				int price=111111;
				int userId=newsJObj.getInt("user_id");
				int categoryId=newsJObj.getInt("category_id");
				String fName=newsJObj.getString("f_name");
				classSubList.add(new ClassfiedSubCatListItem(id, title, image, postDate, address, price, userId, categoryId, fName));
						
			}
			ListAdapter adp1 = new ClassSubCatListAdaAdapter(classSubList, this);
			catList.setAdapter(adp1);
			catList.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1,
						int position, long arg3) {
					// TODO Auto-generated method stub
					
					ClassfiedSubCatListItem item=classSubList.get(position);
					Intent newIntent=new Intent(ClassifiedSubCatList.this,GetClassifiedsAndClassified.class);
					int id=item.getcId();
					newIntent.putExtra("id", id);
					startActivity(newIntent);
					
				}
			});
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.clas_sub_cat_list_back_imv:
			finish();
			break;
		

		default:
			break;
		}
		
	}

}
