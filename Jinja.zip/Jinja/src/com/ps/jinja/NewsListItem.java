package com.ps.jinja;

public class NewsListItem {
	private String nTitle;
    private int cId;
    private int eId;
    private String nDesc;
    private String nPicture;
    public NewsListItem(int cid,int eid,String ntitle,String ndesc,String npicture)
    {
    	cId=cid;
    	eId=eid;
    	nTitle=ntitle;
    	nDesc=ndesc;
    	nPicture=npicture;
    }
    public int getcId() {
        return cId;
    }
    public int geteId() {
        return eId;
    }
    public String getnTitle() {
        return nTitle;
    }
    public String getnDesc() {
        return nDesc;
    }
    public String getnPicture(){
    	return nPicture;
    }

}
