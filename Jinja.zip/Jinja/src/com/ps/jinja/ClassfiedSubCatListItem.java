package com.ps.jinja;

public class ClassfiedSubCatListItem {
	private String cTitle;
    private int cId;
    private String cImage;
    private String cPostDate;
    private String cAddress;
    private int cPrice;
    private int cUserId;
    private int cCatId;
    private String cFname;
    
    public ClassfiedSubCatListItem(int cid,String ctitle,String cimage,String cpostdate,String caddress,int cprice,int cuserid,int ccatid,String cfname)
    {
    	cId=cid;
     	cTitle=ctitle;
     	cImage=cimage;
     	cPostDate=cpostdate;
     	cAddress=caddress;
     	cPrice=cprice;
     	cUserId=cuserid;
     	cCatId=ccatid;
     	cFname=cfname;
    	
    }
    public int getcId() {
        return cId;
    }
    public int getcUserId() {
        return cUserId;
    }
    public int getcCatId() {
        return cCatId;
    }
    public int getcPrice() {
        return cPrice;
    }
    public String getcTitle() {
        return cTitle;
    }
    public String getcImage() {
        return cImage;
    }
    public String getcAddress() {
        return cAddress;
    }
    public String getcFname() {
        return cFname;
    }
    public String getcPostDate() {
        return cPostDate;
    }

}
