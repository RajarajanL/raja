package com.ps.jinja;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.ps.jinja.AsynTask.ShoppingCategoryAsyncTask;
import com.ps.jinja.adapters.ShopingCatAdapter;
import com.ps.jinja.listItems.ShoppingCategoryItem;
import com.ps.jinja.utils.ImageHelper;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class Shopping extends Activity implements OnClickListener  {
	ImageView shImage;
	TextView shTitle;
	GridView shopCatGrid;
	ListView subCatListview;
	int shopCatId;
	String[] values = new String[] { "Mobile","Laptop","Desktop","Tablet","Ipod","Iphone","Accessories","Wires","Micro Oven" };
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.get_sh_categories);
		shopCatGrid=(GridView) findViewById(R.id.get_sh_cat_gridView);
		shImage=(ImageView) findViewById(R.id.get_sh_image_imv);
		shTitle=(TextView) findViewById(R.id.get_sh_title_tv);
		subCatListview=(ListView) findViewById(R.id.get_sh_sub_cat_listview);
		shImage.setOnClickListener(this);
		ShoppingCategoryAsyncTask runner=new ShoppingCategoryAsyncTask(this);
		runner.execute();
		ArrayAdapter<String> adapterList = new ArrayAdapter<String>(this,
				R.layout.example, R.id.textvey, values);

		subCatListview.setAdapter(adapterList);
		
	}
  public void loadShoppingCategory(String jsonResult){
	  
	  final List<ShoppingCategoryItem> shCatArrayList = new ArrayList<ShoppingCategoryItem>();
		JSONArray shopJsonArray;
		try {
			shopJsonArray = new JSONArray(jsonResult);
//			for (int i = 0; i < shopJsonArray.length(); i++) {
				JSONObject shCatJObj = (JSONObject) shopJsonArray.get(0);
				shopCatId=shCatJObj.getInt("category_id");
				String shopCatTitle = shCatJObj.getString("category_name");
				shTitle.setText(shopCatTitle);
				String shopCatImageUrl = shCatJObj.getString("image_url");
				ImageHelper.loadImage(shImage, shopCatImageUrl, true, true, 30);
//				shCatArrayList.add(new ShoppingCategoryItem(shopCatId,shopCatTitle,shopCatImageUrl));

//			}
				for(int i=1;i<shopJsonArray.length();i++){
					JSONObject shCatJobj1=shopJsonArray.getJSONObject(i);
					shCatArrayList.add(new ShoppingCategoryItem(shCatJobj1.getInt("category_id"), shCatJobj1.getString("category_name"), shCatJobj1.getString("image_url")));
					
				}
				ListAdapter shopCatAdapter = new ShopingCatAdapter(
						shCatArrayList, this);
				shopCatGrid.setAdapter(shopCatAdapter);
				shopCatGrid.setOnItemClickListener(new OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> arg0, View arg1,
							int position, long arg3) {
						// TODO Auto-generated method stub
						ShoppingCategoryItem item=shCatArrayList.get(position);
						Intent shoppingIntent=new Intent(Shopping.this, ShoppingSubCategory.class);
						int sendId=item.getsId();
						String sentTitle=item.getsTitle();
						shoppingIntent.putExtra("sendId", sendId);
						Log.i(String.valueOf(sendId), "id");
						shoppingIntent.putExtra("sentTitle", sentTitle);
						Log.i(sentTitle, "Title");
						startActivity(shoppingIntent);
						
						
					}
				});
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	  
  }

@Override
public void onClick(View v) {
	// TODO Auto-generated method stub
	switch (v.getId()) {
	case R.id.get_sh_image_imv:
//		if(subCatListview.getVisibility()==View.GONE){
//			subCatListview.setVisibility(View.VISIBLE);
//		}else{
//			subCatListview.setVisibility(View.GONE);
//		}
		Intent shoppingIntent=new Intent(Shopping.this, ShoppingSubCategory.class);
		shoppingIntent.putExtra("sendId", shopCatId);
		startActivity(shoppingIntent);
		break;

	default:
		break;
	}
	
}
}
