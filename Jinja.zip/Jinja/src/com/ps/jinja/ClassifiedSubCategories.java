package com.ps.jinja;

import java.io.IOException;
import java.io.ObjectOutputStream.PutField;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.ps.jinja.adapters.CategoryListAdapter;
import com.ps.jinja.adapters.ClassSubCatListAdapter;
import com.ps.jinja.constants.URLConstants;
import com.ps.jinja.listItems.ClassfiedSubCatItem;
import com.ps.jinja.listItems.ClassifiedSubCatListItem;
import com.ps.jinja.session.SessionHandler;
import com.ps.jinja.utils.ApiHelper;
import com.ps.jinja.utils.ImageHelper;
import com.ps.jinja.vo.UserVO;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class ClassifiedSubCategories extends Activity implements OnClickListener{
	String[] values = new String[] { "Post Ads", "Cancel",  };
	 ListView postAdd;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.classified_sub_categories);
		TextView userNameTxt=(TextView) findViewById(R.id.class_sub_cat_userName_tv);
		ImageView userImageView=(ImageView) findViewById(R.id.class_sub_cat_userimage_imv);
		TextView nameCategory=(TextView) findViewById(R.id.class_sub_cat_title_tv);
		GridView subCatList=(GridView) findViewById(R.id.class_sub_cat_grid_gv);
		ImageView backImageView=(ImageView) findViewById(R.id.class_sub_cat_back_imv);
		 postAdd=(ListView) findViewById(R.id.listView_post_ads_lv);
		ImageView menuImv=(ImageView) findViewById(R.id.class_sub_cat_menu_imv);
		menuImv.setOnClickListener(this);
		int catId=getIntent().getExtras().getInt("sendId");
		Toast.makeText(getApplicationContext(), String.valueOf(catId), Toast.LENGTH_LONG).show();
		String catName=getIntent().getExtras().getString("sentTitle");
		nameCategory.setText(catName);
		String clasSubJsonStringResult=ApiHelper.getHttpResponseAsString(URLConstants.CLASSIFIEDS_SUB_CATEGORIES+"&category_id="+catId);
		backImageView.setOnClickListener(this);
		backImageView.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
				
			}
		});
		UserVO userVo=SessionHandler.get().getUserVO();
		try {
			if(null!=userVo)
			{
			userNameTxt.setText(userVo.getfName()+" "+userVo.getlName());
		String userImage=userVo.getImageUrl();
		
		Log.i(userImage, "image");

		
		URL url = new URL(userImage);
	
		Bitmap bmp = BitmapFactory.decodeStream(url.openConnection()
				.getInputStream());
		Bitmap finalImg = ImageHelper.getRoundedCornerBitmap(bmp, 10);
		userImageView.setImageBitmap(finalImg);
	}else{
		userNameTxt.setText("Guest");				
		URL url = new URL(URLConstants.GUEST_IMAGE);
		Bitmap bmp = BitmapFactory.decodeStream(url.openConnection()
				.getInputStream());
		Bitmap finalImg = ImageHelper.getRoundedCornerBitmap(bmp, 10);
		userImageView.setImageBitmap(finalImg);
	}
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 if(clasSubJsonStringResult==null){
			 return;
		 }
		Log.i(URLConstants.CLASSIFIEDS_SUB_CATEGORIES+"&category_id="+catId, "Sub Classified Category");
		try {
			final JSONArray clasSubJsonArray=new JSONArray(clasSubJsonStringResult);
			final List<ClassfiedSubCatItem> classSubList=new ArrayList<ClassfiedSubCatItem>();
			for(int i=0;i<clasSubJsonArray.length();i++)
			{
				JSONObject newsJObj=(JSONObject)clasSubJsonArray.get(i);
				int catid=newsJObj.getInt("category_id");
				String ctitle=newsJObj.getString("category_name");
				String cimage=newsJObj.getString("image_url");
				classSubList.add(new ClassfiedSubCatItem(catid, ctitle,cimage));
			}
			ListAdapter adp1 = new ClassSubCatListAdapter(
					classSubList, this);
			subCatList.setAdapter(adp1);
			subCatList.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1,
						int position, long arg3) {
					// TODO Auto-generated method stub
					ClassfiedSubCatItem item=classSubList.get(position);
					Intent newIntent=new Intent(ClassifiedSubCategories.this, ClassifiedSubCatList.class);
					int catId=item.getcId();
					newIntent.putExtra("catId", catId);
					startActivity(newIntent);
					
				}
			});
			
			ArrayAdapter<String> adapterList = new ArrayAdapter<String>(this,
					R.layout.example, R.id.textvey, values);

			postAdd.setAdapter(adapterList);
			postAdd.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1,
						int position, long arg3) {
					// TODO Auto-generated method stub
					String itemvalue = (String) postAdd
							.getItemAtPosition(position);
					Toast.makeText(getApplicationContext(), "" + itemvalue,
							Toast.LENGTH_SHORT).show();
					if (itemvalue == "Post Ads") {
						Toast.makeText(getApplicationContext(), "Post Ads" ,
								Toast.LENGTH_SHORT).show();
						Intent newIntent=new Intent(ClassifiedSubCategories.this, PostAdds.class);
						startActivity(newIntent);
						postAdd.setVisibility(View.GONE);
					}else if(itemvalue == "Cancel")
					{
						Toast.makeText(getApplicationContext(), "Cancel" ,
								Toast.LENGTH_SHORT).show();
						postAdd.setVisibility(View.GONE);
						
					}
				}
			});
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.class_sub_cat_back_imv:
			finish();
			break;
		case R.id.class_sub_cat_menu_imv:
			if(postAdd.getVisibility()==View.VISIBLE)
			{
			postAdd.setVisibility(View.GONE);
			}else{
				postAdd.setVisibility(View.VISIBLE);
			}
			break;
		default:
			break;
		}
		
	}

}
