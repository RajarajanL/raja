package com.ps.jinja;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.ps.jinja.AsynTask.ShoppingSubCatAsyncTask;
import com.ps.jinja.adapters.ShoppingSubCatAdapter;
import com.ps.jinja.listItems.ShoppingSubCatListItem;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class ShoppingSubCategory extends Activity implements OnClickListener {
	
	ImageView backImv;
	GridView subCatGrid;
	TextView titleText;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.get_sh_sub_categories);
		int catId=getIntent().getExtras().getInt("sendId");
		Toast.makeText(getApplicationContext(), String.valueOf(catId), Toast.LENGTH_LONG).show();
		String catName=getIntent().getExtras().getString("sentTitle");
		Log.i(catName+""+String.valueOf(catId), "Getting Values On ShoppingSub Cat");
		backImv=(ImageView) findViewById(R.id.shopping_sub_cat_back_imv);
		backImv.setOnClickListener(this);
		subCatGrid=(GridView) findViewById(R.id.shopping_sub_cat_grid_gview);
		titleText=(TextView) findViewById(R.id.shopping_sub_cat_title_tv);
		titleText.setText(catName);
		ShoppingSubCatAsyncTask runner=new ShoppingSubCatAsyncTask(this);
		runner.execute(String.valueOf(catId));
		
		
	
	}
	public void loadShoppingSubCategories(String jsonResult){
		Log.i(jsonResult, "SubCatShopp jsonResult");
		final List<ShoppingSubCatListItem> shopSubcatList=new ArrayList<ShoppingSubCatListItem>();
		try {
			JSONArray shopSubJsonArray=new JSONArray(jsonResult);
			for(int i=0;i<shopSubJsonArray.length();i++){
				JSONObject shopSubJsonObj=shopSubJsonArray.getJSONObject(i);
				shopSubcatList.add(new ShoppingSubCatListItem(shopSubJsonObj.getInt("category_id"), shopSubJsonObj.getString("category_name"), shopSubJsonObj.getString("image_url")));
			}
			ListAdapter newAdapter=new ShoppingSubCatAdapter(shopSubcatList,this);
			subCatGrid.setAdapter(newAdapter);
			subCatGrid.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1,
						int arg2, long arg3) {
					// TODO Auto-generated method stub
					ShoppingSubCatListItem item=shopSubcatList.get(arg2);
					int sendId=item.getsSubId();
					String sendTitle=item.getsSubTitle();
					Toast.makeText(getApplicationContext(), "Hai"+item, Toast.LENGTH_SHORT).show();
					Intent newShopSubCatIntent=new Intent(ShoppingSubCategory.this, ProductsList.class);
					newShopSubCatIntent.putExtra("sendTitle", sendTitle);
					newShopSubCatIntent.putExtra("sendId", sendId);
					startActivity(newShopSubCatIntent);
					
					
					
				}
			});
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
		
		
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.shopping_sub_cat_back_imv:
			finish();
			
			break;

		default:
			break;
		}
		
	}

}
