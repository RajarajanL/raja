package com.ps.jinja.AsynTask;

import com.ps.jinja.JinjaMainActivityNew;
import com.ps.jinja.MenuOption;
import com.ps.jinja.constants.URLConstants;
import com.ps.jinja.session.SessionHandler;
import com.ps.jinja.utils.ApiHelper;
import com.ps.jinja.vo.UserVO;

import android.os.AsyncTask;

public class MenuSubscriptionAsyncTask extends AsyncTask<String, String, String>{
	private MenuOption mainActivity;
	public MenuSubscriptionAsyncTask(MenuOption mainActivity){
		this.mainActivity = mainActivity;
	}
	
	@Override
	protected void onPreExecute() {
		// TODO Auto-generated method stub
		super.onPreExecute();
		
	}
	@Override
	protected String doInBackground(String... params) {
		// TODO Auto-generated method stub
		UserVO userVO = SessionHandler.get().getUserVO();
		String getSubscription = ApiHelper
				.getHttpResponseAsString(URLConstants.GET_SUBSCRIPTIONS_URL
						+ "&user_id=" + userVO.getUserId());
		return getSubscription;
	}
	@Override
	  protected void onPostExecute(String result) {
	   // execution of result of Long time consuming operation
	    mainActivity.loadMenuSubcription(result);
//	    dialog.dismiss();
	  }

}
