package com.ps.jinja.AsynTask;

import com.ps.jinja.ShowingNews;
import com.ps.jinja.constants.URLConstants;
import com.ps.jinja.utils.ApiHelper;

import android.app.ProgressDialog;
import android.os.AsyncTask;

public class ShowingNewsAsynTask extends AsyncTask<String, String, String> {
	protected ShowingNews mainActivity;
	private ProgressDialog dialog;
	public ShowingNewsAsynTask(ShowingNews mainActivity){
		this.mainActivity=mainActivity;
	}
	@Override
	protected void onPreExecute() {
		// TODO Auto-generated method stub
		super.onPreExecute();
		dialog = new ProgressDialog(mainActivity);
		  dialog.setMessage("Loading....");
		  dialog.show();
		
	}
	@Override
	protected String doInBackground(String... params) {
		// TODO Auto-generated method stub
		String gridId=params[0];
		String newsJsonResult = ApiHelper.getHttpResponseAsString(URLConstants.GET_NEWS_BY_CATEGORY+"&category_id="+gridId);
		return newsJsonResult;
	}
	@Override
	  protected void onPostExecute(String result) {
	   // execution of result of Long time consuming operation
	    mainActivity.loadShowNewsFlip(result);
	    dialog.dismiss();
	  }

}
