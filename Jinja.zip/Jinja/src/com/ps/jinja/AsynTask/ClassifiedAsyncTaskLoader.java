package com.ps.jinja.AsynTask;
import com.ps.jinja.Classified;
import com.ps.jinja.constants.URLConstants;
import com.ps.jinja.utils.ApiHelper;
import android.app.ProgressDialog;
import android.os.AsyncTask;
public class ClassifiedAsyncTaskLoader extends AsyncTask<String, String, String>{
	private Classified mainActivity;
	private ProgressDialog dialog;
	public ClassifiedAsyncTaskLoader(Classified mainActivity){
		this.mainActivity = mainActivity;
	}
	@Override
	protected void onPreExecute() {
		// TODO Auto-generated method stub
		super.onPreExecute();
		dialog = new ProgressDialog(mainActivity);
		  dialog.setMessage("Welcome to JinJa");
		  dialog.show();
		
	}
	@Override
	protected String doInBackground(String... params) {
		// TODO Auto-generated method stub
		String classifiedCatString=ApiHelper.getHttpResponseAsString(URLConstants.CLASSIFIEDS_CATEGORIES);
		return classifiedCatString;
	}
	@Override
	  protected void onPostExecute(String result) {
	   // execution of result of Long time consuming operation
	    mainActivity.loadClassifiedCategory(result);
	    dialog.dismiss();
	  }
	

}
