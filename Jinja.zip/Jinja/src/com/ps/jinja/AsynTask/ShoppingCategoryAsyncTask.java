package com.ps.jinja.AsynTask;

import android.os.AsyncTask;

import com.ps.jinja.Shopping;
import com.ps.jinja.constants.URLConstants;
import com.ps.jinja.utils.ApiHelper;

public class ShoppingCategoryAsyncTask extends AsyncTask<String, String, String>{

	private Shopping mainActivity;
	public ShoppingCategoryAsyncTask(Shopping mainActivity){
		this.mainActivity = mainActivity;
	}
	
	@Override
	protected void onPreExecute() {
		// TODO Auto-generated method stub
		super.onPreExecute();
		
	}
	@Override
	protected String doInBackground(String... params) {
		// TODO Auto-generated method stub
		String getShoppingCat = ApiHelper
				.getHttpResponseAsString(URLConstants.GET_SH_CATEGORIES);
		return getShoppingCat;
	}
	@Override
	  protected void onPostExecute(String result) {
	   // execution of result of Long time consuming operation
	    mainActivity.loadShoppingCategory(result);
//	    dialog.dismiss();
	  }

}
