package com.ps.jinja.AsynTask;

import com.ps.jinja.Carts;
import com.ps.jinja.constants.URLConstants;
import com.ps.jinja.utils.ApiHelper;

import android.app.ProgressDialog;
import android.os.AsyncTask;

public class CartAsyncTask extends AsyncTask<String, String, String> {

	private Carts mainActivity;
	private ProgressDialog dialog;
	public CartAsyncTask(Carts mainActivity){
		this.mainActivity = mainActivity;
	}
	@Override
	protected void onPreExecute() {
		// TODO Auto-generated method stub
		super.onPreExecute();
		dialog = new ProgressDialog(mainActivity);
		  dialog.setMessage("cart...");
		  dialog.show();
		
	}
	@Override
	protected String doInBackground(String... params) {
		// TODO Auto-generated method stub
		String userId=params[0];
		String cartString=ApiHelper.getHttpResponseAsString(URLConstants.GET_CART+"&user_id="+userId);
		return cartString;
	}
	@Override
	  protected void onPostExecute(String result) {
	   // execution of result of Long time consuming operation
	    mainActivity.loadClassifiedCategory(result);
	    dialog.dismiss();
	  }
	

}
