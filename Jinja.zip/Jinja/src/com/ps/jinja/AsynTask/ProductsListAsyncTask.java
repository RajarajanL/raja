package com.ps.jinja.AsynTask;

import android.os.AsyncTask;

import com.ps.jinja.ProductsList;
import com.ps.jinja.constants.URLConstants;
import com.ps.jinja.utils.ApiHelper;

public class ProductsListAsyncTask extends AsyncTask<String, String, String>{

private ProductsList mainActivity;
	
	public ProductsListAsyncTask(ProductsList mainActivity){
		this.mainActivity = mainActivity;
	}
	
	@Override
	protected void onPreExecute() {
		// TODO Auto-generated method stub
		super.onPreExecute();
		
	}
	
	@Override
	protected String doInBackground(String... params) {
		// TODO Auto-generated method stub
		String catId=params[0];
		String newsJsonResult=ApiHelper.getHttpResponseAsString(URLConstants.GET_PRODUCTS_LIST+"&category_id="+catId);
		return newsJsonResult;
		
	}
	@Override
	  protected void onPostExecute(String result) {
	   // execution of result of Long time consuming operation
	    mainActivity.loadNewsSubCategoryList(result);
//	    dialog.dismiss();
	  }

}
