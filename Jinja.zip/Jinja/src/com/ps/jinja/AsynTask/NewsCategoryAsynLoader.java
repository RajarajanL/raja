package com.ps.jinja.AsynTask;

import com.ps.jinja.JinjaMainActivityNew;
import com.ps.jinja.constants.URLConstants;
import com.ps.jinja.utils.ApiHelper;

import android.os.AsyncTask;

public class NewsCategoryAsynLoader extends AsyncTask<String, String, String> {
	private JinjaMainActivityNew mainActivity;
	
	public NewsCategoryAsynLoader(JinjaMainActivityNew mainActivity){
		this.mainActivity = mainActivity;
	}
	

	@Override
	protected void onPreExecute() {
		// TODO Auto-generated method stub
		
		super.onPreExecute();
		
	}
	
	@Override
	protected String doInBackground(String... params) {
		String newsJsonResult=ApiHelper.getHttpResponseAsString(URLConstants.CATEGORIES_URL);
		return newsJsonResult;
	}
	@Override
	  protected void onPostExecute(String result) {
	   // execution of result of Long time consuming operation
	    mainActivity.loadNewsUrl(result);
	  }

}
