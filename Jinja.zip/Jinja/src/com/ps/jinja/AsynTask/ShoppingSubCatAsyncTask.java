package com.ps.jinja.AsynTask;

import com.ps.jinja.ShoppingSubCategory;
import com.ps.jinja.constants.URLConstants;
import com.ps.jinja.utils.ApiHelper;

import android.os.AsyncTask;

public class ShoppingSubCatAsyncTask extends AsyncTask<String, String, String>{

private ShoppingSubCategory mainActivity;
	
	public ShoppingSubCatAsyncTask(ShoppingSubCategory mainActivity){
		this.mainActivity = mainActivity;
	}
	
	@Override
	protected void onPreExecute() {
		// TODO Auto-generated method stub
		super.onPreExecute();
		
	}
	@Override
	protected String doInBackground(String... params) {
		// TODO Auto-generated method stub
		String catId=params[0];
		String newsJsonResult=ApiHelper.getHttpResponseAsString(URLConstants.GET_SH_SUB_CATEGORIES+"&category_id="+catId);
		return newsJsonResult;
	}
	@Override
	  protected void onPostExecute(String result) {
	   // execution of result of Long time consuming operation
	    mainActivity.loadShoppingSubCategories(result);
//	    dialog.dismiss();
	  }


}
