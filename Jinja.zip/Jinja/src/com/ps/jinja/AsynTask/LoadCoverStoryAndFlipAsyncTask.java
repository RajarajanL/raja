package com.ps.jinja.AsynTask;

import com.ps.jinja.SubCategoriesNewsPage;
import com.ps.jinja.constants.URLConstants;
import com.ps.jinja.utils.ApiHelper;

import android.app.ProgressDialog;
import android.os.AsyncTask;

public class LoadCoverStoryAndFlipAsyncTask extends AsyncTask<String, String, String>{
    private SubCategoriesNewsPage mainActivity;

	private ProgressDialog dialog;
	public LoadCoverStoryAndFlipAsyncTask(SubCategoriesNewsPage mainActivity){
		this.mainActivity = mainActivity;
	}
	
	@Override
	protected void onPreExecute() {
		// TODO Auto-generated method stub
		super.onPreExecute();
		dialog = new ProgressDialog(mainActivity);
		dialog.setMessage("Welcome to JinJa");
		dialog.show();
		
	}
	@Override
	protected String doInBackground(String... params) {
		// TODO Auto-generated method stub
		String catId=params[0];
		String newsJsonResult=ApiHelper.getHttpResponseAsString(URLConstants.GET_CATEGORIES_NEWS_PARENT+"&parent="+catId);
		return newsJsonResult;
		
	}
	@Override
	  protected void onPostExecute(String result) {
	   // execution of result of Long time consuming operation
	    mainActivity.loadCoverStoryAndFlip(result);
	    dialog.dismiss();
	  }

}
