package com.ps.jinja.AsynTask;

import com.ps.jinja.JinjaMainActivityNew;
import com.ps.jinja.constants.URLConstants;
import com.ps.jinja.utils.ApiHelper;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.util.Log;

public class CoverAsynTaskLoader extends AsyncTask<String, String, String> {

	private JinjaMainActivityNew mainActivity;
	private ProgressDialog dialog;
	
	public CoverAsynTaskLoader(JinjaMainActivityNew mainActivity){
		this.mainActivity = mainActivity;
	}
	
	@Override
	protected void onPreExecute() {
		// TODO Auto-generated method stub
		super.onPreExecute();
		dialog = new ProgressDialog(mainActivity);
		  dialog.setMessage("Welcome to JinJa");
		  dialog.show();
		
	}
	@Override
	protected String doInBackground(String... params) {
		String test=params[0];
		String tes1=params[1];
		Log.i(test, "Id");
		Log.i(tes1, "Name");
		String coversJsonResult=ApiHelper.getHttpResponseAsString(URLConstants.COVER_STORY);
		return coversJsonResult;
	}

	@Override
	  protected void onPostExecute(String result) {
	   // execution of result of Long time consuming operation
	    mainActivity.loadCoverStory(result);
	    dialog.dismiss();
	  }
	
}
