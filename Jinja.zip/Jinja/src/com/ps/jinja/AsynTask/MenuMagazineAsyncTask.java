package com.ps.jinja.AsynTask;

import com.ps.jinja.MenuOption;
import com.ps.jinja.constants.URLConstants;
import com.ps.jinja.session.SessionHandler;
import com.ps.jinja.utils.ApiHelper;
import com.ps.jinja.vo.UserVO;

import android.app.ProgressDialog;
import android.os.AsyncTask;

public class MenuMagazineAsyncTask extends AsyncTask<String, String, String> {
	private MenuOption mainActivity;
	private ProgressDialog dialog;
	
	public MenuMagazineAsyncTask(MenuOption mainActivity2) {
		// TODO Auto-generated constructor stub
		this.mainActivity=mainActivity2;
	}

	@Override
	protected void onPreExecute() {
		// TODO Auto-generated method stub
		super.onPreExecute();
		dialog = new ProgressDialog(mainActivity);
		dialog.setMessage("Welcome to JinJa");
		dialog.show();
		
		
	}
	@Override
	protected String doInBackground(String... params) {
		// TODO Auto-generated method stub
		UserVO userVO = SessionHandler.get().getUserVO();
		String newsDetailJsonResult = ApiHelper
				.getHttpResponseAsString(URLConstants.GET_MAGAZINES_URL
						+ "&user_id=" + userVO.getUserId());
		return newsDetailJsonResult;
	}
	protected void onPostExecute(String result) {
		   // execution of result of Long time consuming operation
		    mainActivity.loadMenuMagazine(result);
		    dialog.dismiss();
		  }
}
