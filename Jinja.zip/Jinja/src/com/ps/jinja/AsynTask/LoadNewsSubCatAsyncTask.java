package com.ps.jinja.AsynTask;

import com.ps.jinja.SubCategoriesNewsPage;
import com.ps.jinja.constants.URLConstants;
import com.ps.jinja.utils.ApiHelper;

import android.os.AsyncTask;

public class LoadNewsSubCatAsyncTask extends AsyncTask<String, String, String> {

	private SubCategoriesNewsPage mainActivity;
	
	public LoadNewsSubCatAsyncTask(SubCategoriesNewsPage mainActivity){
		this.mainActivity = mainActivity;
	}
	
	@Override
	protected void onPreExecute() {
		// TODO Auto-generated method stub
		super.onPreExecute();
		
	}
	
	@Override
	protected String doInBackground(String... params) {
		// TODO Auto-generated method stub
		String catId=params[0];
		String newsJsonResult=ApiHelper.getHttpResponseAsString(URLConstants.SUB_CATEGORIES_URL+"&category_id="+catId);
		return newsJsonResult;
		
	}
	@Override
	  protected void onPostExecute(String result) {
	   // execution of result of Long time consuming operation
	    mainActivity.loadNewsSubCategoryList(result);
//	    dialog.dismiss();
	  }

}
