package com.ps.jinja;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.aphidmobile.flip.FlipViewController;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ShowingNewsInFlip extends Activity {
	protected FlipViewController flipViewNews;
	String url1="http://mem01flux.fluxmachine.com/services/call.php?url=get-news&category_id=";
	String url;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.showing_news_flip);
		flipViewNews = (FlipViewController) findViewById(R.id.flipView_NewsWithFlip);
		int gridId=getIntent().getExtras().getInt("sendCatId");
		url=url1+gridId;
		HttpClient newsHttpclient = new DefaultHttpClient();
		HttpPost newsHttppost = new HttpPost(url);
		try {
			HttpResponse newsHttpResponse = newsHttpclient
					.execute(newsHttppost);
			String newsJsonResult = inputStreamToString(
			newsHttpResponse.getEntity().getContent()).toString();
			final JSONArray newsJsonArray = new JSONArray(newsJsonResult);
			flipViewNews.setAdapter(new BaseAdapter() {

				@Override
				public int getCount() {
					return newsJsonArray.length();
				}

				@Override
				public Object getItem(int position) {
					return position;
				}

				@Override
				public long getItemId(int position) {
					return position;
				}

				@Override
				public View getView(int position, View convertView,
						ViewGroup parent) {

					LinearLayout itemLayout = null;

					try {
						JSONObject newsJObj = (JSONObject) newsJsonArray
								.get(position);
						int newsCatId=newsJObj.getInt("category_id");
						int newsEntId=newsJObj.getInt("entry_id");
						String newsTitle=newsJObj.getString("title");
//						String newsDiscription=newsJObj.getString("description");
						final String imageUrl=newsJObj.getString("image_url");

						if (convertView == null) {
							final Context context = parent.getContext();
							itemLayout = (LinearLayout) LayoutInflater.from(context).inflate(R.layout.news_flip_list_item, parent,false);
							// Set the icon as defined in our list item
//							TextView txtcId = (TextView) itemLayout
//									.findViewById(R.id.newslist_title_tv);
//							txtcId.setText(String.valueOf(newsCatId));
//							TextView txteId = (TextView) itemLayout
//									.findViewById(R.id.newslist_title_tv);
//							txteId.setText(String.valueOf(newsEntId));

							// Set the text label as defined in our list item
							TextView txtTitle = (TextView) itemLayout
									.findViewById(R.id.newslist_title_tv);
							txtTitle.setText(newsTitle);
							ImageView txtImage = (ImageView) itemLayout
									.findViewById(R.id.newslist_image_imv);
							try {
								URL url = new URL(imageUrl);
								Bitmap bmp = BitmapFactory.decodeStream(url
										.openConnection().getInputStream());
								txtImage.setImageBitmap(bmp);
								txtImage.getLayoutParams().height = 600;
								txtImage.getLayoutParams().width = 600;
								txtImage.setOnClickListener(new OnClickListener() {
									
									@Override
									public void onClick(View v) {
										// TODO Auto-generated method stub
										Intent newintent=new Intent(ShowingNewsInFlip.this, Example.class);
										newintent.putExtra("imageUrl", imageUrl);
										startActivity(newintent);
										
									}
								});
//								Log.i("intent", item.getnPicture());
							} catch (Exception e) {
								e.printStackTrace();
							}

						} else {
							itemLayout = (LinearLayout) convertView;
							
							// Set the icon as defined in our list item
//							TextView txtcId = (TextView) itemLayout
//									.findViewById(R.id.newslist_cid_tv);
//							txtcId.setText(String.valueOf(newsCatId));
//							TextView txteId = (TextView) itemLayout
//									.findViewById(R.id.newslist_eid_tv);
//							txteId.setText(String.valueOf(newsEntId));

							// Set the text label as defined in our list item
							TextView txtTitle = (TextView) itemLayout
									.findViewById(R.id.newslist_title_tv);
							txtTitle.setText(newsTitle);
							ImageView txtImage = (ImageView) itemLayout
									.findViewById(R.id.newslist_image_imv);
							try {
								URL url = new URL(imageUrl);
								Bitmap bmp = BitmapFactory.decodeStream(url
										.openConnection().getInputStream());
								txtImage.setImageBitmap(bmp);
								txtImage.getLayoutParams().height = 600;
								txtImage.getLayoutParams().width = 600;
//								Log.i("intent", item.getnPicture());
							} catch (Exception e) {
								e.printStackTrace();
							}
							
						}
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					return itemLayout;
				}
			});
		}catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

}
	private StringBuilder inputStreamToString(InputStream is) {
		// TODO Auto-generated method stub
		String rLine = "";
		StringBuilder answer = new StringBuilder();

		InputStreamReader isr = new InputStreamReader(is);

		BufferedReader rd = new BufferedReader(isr);

		try {
			while ((rLine = rd.readLine()) != null) {
				answer.append(rLine);
			}
		}

		catch (IOException e) {
			e.printStackTrace();
		}
		return answer;

	}

}
