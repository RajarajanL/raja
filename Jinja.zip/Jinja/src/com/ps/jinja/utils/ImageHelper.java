package com.ps.jinja.utils;



import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;
import com.ps.jinja.cache.ImageCache;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

public class ImageHelper {
	
	public static Bitmap getBitmapFromURL(String src) {
	    return ImageCache.get().getBitmapFromCache(src);
	}
	
    public static Bitmap getRoundedCornerBitmap(Bitmap bitmap, int pixels) {
        Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap
                .getHeight(), Config.ARGB_8888);
        Canvas canvas = new Canvas(output);
        final int color = 0xff424242;
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
        final RectF rectF = new RectF(rect);
        final float roundPx = pixels;

        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        canvas.drawRoundRect(rectF, roundPx, roundPx, paint);

        paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);

        return output;
    }
    
    public static void loadImage(final ImageView imgView, String url , boolean isAsync , final boolean isRounded , Integer radius){
    	try{

			if(isAsync){
				if(isRounded){
					DisplayImageOptions options = new DisplayImageOptions.Builder().
														cacheInMemory(true).
														cacheOnDisk(true).
														displayer(new RoundedBitmapDisplayer(radius)).
														build();
					ImageLoader.getInstance().displayImage(url, imgView, options);
					Log.i(String.valueOf(url), "Is Rounded");
				}else{
					ImageLoader.getInstance().displayImage(url, imgView);
					Log.i(String.valueOf(url), "Is Not Rounded");
				}
//	            ImageLoader.getInstance().loadImage(url, new SimpleImageLoadingListener() {
//	                @Override
//	                public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
//	                	if(isRounded)loadedImage = ImageHelper.getRoundedCornerBitmap(loadedImage, 15);
//	                    imgView.setImageBitmap(loadedImage);
//	                    Log.i(String.valueOf(loadedImage), "image Loaded");
//	                }
//	            });
			}else{
				Bitmap bmp = ImageLoader.getInstance().loadImageSync(url);
				if(isRounded)bmp = ImageHelper.getRoundedCornerBitmap(bmp, 15);
                imgView.setImageBitmap(bmp);
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
    }
}