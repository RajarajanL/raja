package com.ps.jinja;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.ps.jinja.AsynTask.CartAsyncTask;
import com.ps.jinja.adapters.CartAdapter;
import com.ps.jinja.adapters.ProductsListAdapter;
import com.ps.jinja.listItems.CartListItem;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class Carts extends Activity implements OnClickListener{
	ImageView backImv;
	ListView cartListView;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.get_carts);
		backImv=(ImageView) findViewById(R.id.get_carts_back_imv);
		backImv.setOnClickListener(this);
		cartListView=(ListView) findViewById(R.id.get_carts_list_listview);
		int userId=0;
		CartAsyncTask runner=new CartAsyncTask(this);
		runner.execute(String.valueOf(userId));
		
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.get_carts_back_imv:
			finish();
			break;

		default:
			break;
		}
		
	}
	public void loadClassifiedCategory(String jsonResult) {
		// TODO Auto-generated method stub
		List<CartListItem> cartList=new ArrayList<CartListItem>();
		try {
			JSONArray cartJsonArray=new JSONArray(jsonResult);
			for(int i=0;i<cartJsonArray.length();i++){
				JSONObject cartJsonObject=cartJsonArray.getJSONObject(i);
//				int cartId=cartJsonObject.getInt("id");
//				int cartPrice=cartJsonObject.getInt("price_item");
//				int cartCount=cartJsonObject.getInt("count");
//				int carProductId=cartJsonObject.getInt("product_id");
//				cartList.add(new CartListItem(cartId, cartPrice, carProductId, cartCount));
				cartList.add(new CartListItem(cartJsonObject.getInt("id"), cartJsonObject.getInt("price_item"), cartJsonObject.getInt("count"), cartJsonObject.getInt("product_id")));
			}
			ListAdapter newAdapter=new CartAdapter(cartList,this);
			cartListView.setAdapter(newAdapter);
			cartListView.setOnItemLongClickListener(new OnItemLongClickListener() {


        @Override
        public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
                int arg2, long arg3) {
            AlertDialog.Builder alert = new AlertDialog.Builder(Carts.this);
            alert.setMessage("Are you sure you want to Remove this?");
            alert.setCancelable(false);
            alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    //Here I need the delete code
                	Toast.makeText(getApplicationContext(), "Whooooooo", Toast.LENGTH_LONG).show();
                }
            });
            alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();

                }
            });


            return false;

        }
});
			
			
			
			
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	@Override
	protected void onResume() {

		super.onResume();
		this.onCreate(null);
	}
	
	
}
