package com.ps.jinja;

import java.io.File;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import com.ps.jinja.constants.URLConstants;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.MediaStore.MediaColumns;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends Activity{
    Button siguUp;
	 ImageView imageView,buttonLoadImage ;
	 TextView tv;
   private static int RESULT_LOAD_IMAGE = 1;
   private String picturePath;
   EditText fName,sName,eMail,pNumber;
   HttpEntity resEntity;
   @Override
   public void onCreate(Bundle savedInstanceState) {
       super.onCreate(savedInstanceState);
       setContentView(R.layout.activity_register);
       fName=(EditText) findViewById(R.id.reg_FirstName_et);
		 sName=(EditText) findViewById(R.id.reg_SecondName_et);
		 eMail=(EditText) findViewById(R.id.reg_EmailId_et);
		 pNumber=(EditText) findViewById(R.id.reg_PhoneNumber_et);
      imageView = (ImageView) findViewById(R.id.reg_image_browse_imv);
      buttonLoadImage = (ImageView) findViewById(R.id.reg_image_signup_imbtn);
       imageView.setOnClickListener(new View.OnClickListener() {
            
           @Override
           public void onClick(View arg0) {
                
               Intent i = new Intent(
                       Intent.ACTION_PICK,
                       android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                
               startActivityForResult(i, RESULT_LOAD_IMAGE);
           }
       });
       buttonLoadImage.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
//			// TODO Auto-generated method stub
			final String fNAME=fName.getText().toString();
    		final String lNAME=sName.getText().toString();
    		final String eMAIL=eMail.getText().toString();
    		final String pNUMBER=String.valueOf(pNumber.getText().toString());
    		final String pPath=picturePath;
    		Log.i(pPath, "Picture Path");
    		if(fNAME==null||fNAME.equals("")||lNAME==null||lNAME.equals("")||eMAIL==null||eMAIL.equals("")||pNUMBER==null||pNUMBER.equals("")||pPath==null){
    			Toast.makeText(getApplicationContext(), "Please Fill All fields", Toast.LENGTH_LONG).show();
    			return;
    		}
            new Thread(new Runnable() {
                @Override
				public void run() {
                	uploadFile(pPath,fNAME,lNAME,eMAIL,pNUMBER); 
            	    
                                              
                }
 
            }).start();  
			
		}
	});
   }
   private void uploadFile(String selectedImagePath,
			String fNAME, String lNAME, String eMAIL,
			String pNUMBER) {
    	File file1 = new File(selectedImagePath);
//        String urlString = "http://mem01flux.fluxmachine.com/services/call.php?url=signup-user";
    	String a=selectedImagePath;
    	String b=fNAME;
    	String c=lNAME;
    	String d=eMAIL;
    	String e=pNUMBER;
    	Log.i(a, "path A");
    	Log.i(b, "fname B");
		Log.i(c, "lname C");
		Log.i(d, "email D");
		Log.i(String.valueOf(e), "Pass E");
		try
        {
             HttpClient client = new DefaultHttpClient();
             HttpPost post = new HttpPost(URLConstants.SIGNUP_USER);
             FileBody bin1 = new FileBody(file1);
             MultipartEntity reqEntity = new MultipartEntity();
             Log.i(String.valueOf(bin1), "File Body");
             reqEntity.addPart("user_image", bin1);
             reqEntity.addPart("fname", new StringBody(fNAME));
             reqEntity.addPart("lname", new StringBody(lNAME));
             reqEntity.addPart("email", new StringBody(eMAIL));
             reqEntity.addPart("password", new StringBody(String.valueOf(pNUMBER)));
             post.setEntity(reqEntity);
             
             HttpResponse response = client.execute(post);
             resEntity = response.getEntity();
             final String response_str = EntityUtils.toString(resEntity);
             if (resEntity != null) {
                 Log.i("RESPONSE",response_str);
                 runOnUiThread(new Runnable(){
                        @Override
						public void run() {
                             try {
                                //Toast.makeText(getApplicationContext(),"Upload Complete. Check the server uploads directory.", Toast.LENGTH_LONG).show();
                            } catch (Exception e) {
                                e.printStackTrace();
                                Toast.makeText(getApplicationContext(), "error:"+e.getMessage().toString(), Toast.LENGTH_LONG).show();
                            }
                           }
                    });
             }else{
            	 Toast.makeText(getApplicationContext(), "error:", Toast.LENGTH_LONG).show();
             }
        }
        catch (final Exception ex){
runOnUiThread(new Runnable() {
	
	@SuppressLint("ShowToast")
	@Override
	public void run() {
		// TODO Auto-generated method stub
		Toast.makeText(getApplicationContext(), "dddd"+ex.getMessage().toString(), Toast.LENGTH_LONG).show();
		
	}
});
        	
             Log.e("Debug", "error: " + ex.getMessage(), ex);
        }
		
	
    	
    }
    
   @Override
   protected void onActivityResult(int requestCode, int resultCode, Intent data) {
       super.onActivityResult(requestCode, resultCode, data);
        
       if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && null != data) {
           Uri selectedImage = data.getData();
           String[] filePathColumn = { MediaColumns.DATA };

           Cursor cursor = getContentResolver().query(selectedImage,
                   filePathColumn, null, null, null);
           cursor.moveToFirst();
           int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
           picturePath = cursor.getString(columnIndex);
           cursor.close();
            Log.i(picturePath, "path");
            
           
           imageView.setImageBitmap(BitmapFactory.decodeFile(picturePath));
           return;
        
       }
    
    
   }
}
