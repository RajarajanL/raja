package com.ps.jinja.sample;

import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.TextView;

public class NumberTextView extends TextView {

	  private String text;

	  public NumberTextView(Context context, String text) {
	    super(context);
	    setNumber(text);
	    setTextColor(Color.BLACK);
	    setBackgroundColor(Color.WHITE);
	    setGravity(Gravity.CENTER);
	  }

	  public String getNumber() {
	    return text;
	  }

	  public void setNumber(String text) {
	    this.text = text;
	    setText(String.valueOf(text));
	  }

	  @Override
	  public String toString() {
	    return "NumberTextView: " + text;
	  }
}
