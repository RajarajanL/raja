package com.ps.jinja;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.ps.jinja.constants.URLConstants;
import com.ps.jinja.utils.ApiHelper;
import com.ps.jinja.utils.ImageHelper;

public class Product extends Activity implements OnClickListener{
	ImageView backImv,cartImv,productImageImv;
	Button buyNow,cartIn;
	TextView productTitleTxt,productPriceTxt,productTotalTxt,newProductPriceTxt;
	int getId,productPrice,productId,productCount,totalPrice;
	
	String countEdit;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.get_product);
		backImv=(ImageView) findViewById(R.id.get_product_back_imv);
		backImv.setOnClickListener(this);
		cartImv=(ImageView) findViewById(R.id.get_product_cart_open_imv);
		cartImv.setOnClickListener(this);
		buyNow=(Button) findViewById(R.id.get_product_buyNow_btn);
		buyNow.setOnClickListener(this);
		cartIn=(Button) findViewById(R.id.get_product_cartIn_btn);
		cartIn.setOnClickListener(this);
		productTitleTxt=(TextView) findViewById(R.id.get_product_title_tv);
		productPriceTxt=(TextView) findViewById(R.id.get_product_price_tv);
		productImageImv=(ImageView) findViewById(R.id.get_product_image_imv);
		
		EditText countProduct=(EditText) findViewById(R.id.get_product_count_et);
		countEdit=countProduct.getText().toString();
		Log.i(countEdit, "Count Edit");
		productCount= 2;//Integer.parseInt(countEdit);//Integer.parseInt(countProduct.getText().toString());
		productTotalTxt=(TextView) findViewById(R.id.get_product_totol_tv);
		newProductPriceTxt=(TextView) findViewById(R.id.get_product_price_reley_tv);
		getId=getIntent().getExtras().getInt("sendId");
		
		loadProduct();
		
		
	}
	
	private void loadProduct() {
		// TODO Auto-generated method stub
		Log.i(String.valueOf(getId), "Hai Get Product Id");
		Toast.makeText(getApplicationContext(), "Id Get Product"+getId, Toast.LENGTH_LONG).show();
		String productApiString=ApiHelper.getHttpResponseAsString(URLConstants.GET_PRODUCT+"&product_id="+getId);
		
		try {
			JSONObject jsonProductObject=new JSONObject(productApiString);
			productId=jsonProductObject.getInt("product_id");
			String productName=jsonProductObject.getString("product_name");
			productTitleTxt.setText(productName);
			String productImage=jsonProductObject.getString("image_url");
			ImageHelper.loadImage(productImageImv, productImage, true, true, 30);
			productPrice=jsonProductObject.getInt("price");
			productPriceTxt.setText("Rs."+String.valueOf(productPrice));
			newProductPriceTxt.setText("Rs."+String.valueOf(productPrice)+"X");
			totalPrice=productPrice*productCount;
			productTotalTxt.setText("="+String.valueOf(totalPrice));
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.get_product_back_imv:
			finish();
			break;
		case R.id.get_product_buyNow_btn:
			
			break;
			
		case R.id.get_product_cart_open_imv:
			Intent newCartIntent=new Intent(Product.this, Carts.class);
			startActivity(newCartIntent);
			break;
		case R.id.get_product_cartIn_btn:
//			if(null!=userVO){
//				int userId=userVO.getUserId();
//				Log.i(String.valueOf(userId), "User In");
//				Log.i(addSub, "Appended Id user");
				try {
				HttpClient mClient= new DefaultHttpClient();

				HttpGet get = new HttpGet(URLConstants.ADD_CARTS
						+ "&user_id=" + 0 + "&product_id="
						+ productId+"&count="+productCount+"&price_item="+productPrice);
				Log.i(String.valueOf(get), "HTTP URL");
				mClient.execute(get);
				
					Toast.makeText(getApplicationContext(), "Added to cart", Toast.LENGTH_LONG).show();
//					finish();
				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				 
				
		
		
			break;
		default:
			break;
		}
		
	}

}
