package com.ps.jinja;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.aphidmobile.flip.FlipViewController;
import com.ps.jinja.adapters.CategoryListAdapter;
import com.ps.jinja.constants.URLConstants;
import com.ps.jinja.utils.ApiHelper;
import com.ps.jinja.utils.ImageHelper;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class SubCategoriesTwo extends Activity {
	TextView catTitleTxtView,topNewsTitleTv,newsNewsDescTv,newsNewsTitleTv;
	ImageView topNewsimage,newsNewsImage,backImage,menuImageView;
	ListView selectionList;
	protected FlipViewController flipViewNews;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.new_example);
		
		flipViewNews = (FlipViewController) findViewById(R.id.flipView_NewsWithFlip_tttd);
		
		
		
		catTitleTxtView=(TextView) findViewById(R.id.top_news_top_lay_title_tv);
		topNewsTitleTv=(TextView) findViewById(R.id.top_news_top_tv);
		topNewsimage=(ImageView) findViewById(R.id.top_news_top_imv);
		backImage=(ImageView) findViewById(R.id.top_news_top_lay_back_imv);
		selectionList=(ListView) findViewById(R.id.top_news_news_selection_listview);
		menuImageView=(ImageView) findViewById(R.id.top_news_top_lay_menu_imv);
		String catTitle=getIntent().getStringExtra("sendTitle");
		catTitleTxtView.setText(catTitle+" | Top News");
		final int catId=getIntent().getExtras().getInt("sendId");
		Log.i(String.valueOf(catId), "cid");
		Log.i(URLConstants.SUB_CATEGORIES_URL+"&cat_id="+catId, "Full URL");
		
		try{
			
			String newsJsonResult=ApiHelper.getHttpResponseAsString(URLConstants.SUB_CATEGORIES_URL+"&category_id="+catId);
			JSONArray newsJsonArray=new JSONArray(newsJsonResult);

			
			String url1=URLConstants.GET_CATEGORIES_NEWS_PARENT+"&parent="+1;
			
			String flipAAAB=ApiHelper.getHttpResponseAsString(url1);
			
			JSONArray newsJsonArrayFlip = new JSONArray(flipAAAB);
			JSONObject coverNewsObject = newsJsonArrayFlip.getJSONObject(0);
			final int topNewsEid = coverNewsObject.getInt("entry_id");
			String topNewsTitle = coverNewsObject.getString("title");
			String topStringNewsImage = coverNewsObject.getString("image_url");
			ImageHelper.loadImage(topNewsimage, topStringNewsImage, true, true, 50);
			topNewsTitleTv.setText(topNewsTitle);
			topNewsimage.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					Intent newIntentCover=new Intent(SubCategoriesTwo.this, DisplayListDetails.class);
					newIntentCover.putExtra("sendeId", topNewsEid);
					startActivity(newIntentCover);
				}
			});
			
			final List<JSONObject> newsFlipList = new ArrayList<JSONObject>();
			for(int i=0;i<newsJsonArrayFlip.length();i++){
				if(i != 0)
					newsFlipList.add(newsJsonArrayFlip.getJSONObject(i));
			}
			flipViewNews.setAdapter(new BaseAdapter() {

				@Override
				public int getCount() {
					return newsFlipList.size();
				}

				@Override
				public Object getItem(int position) {
					return position;
				}

				@Override
				public long getItemId(int position) {
					return position;
				}

				@Override
				public View getView(int position, View convertView,
						ViewGroup parent) {

					LinearLayout itemLayout = null;

					try {
						JSONObject newsJObj = (JSONObject) newsFlipList
								.get(position);
						String newsTitle=newsJObj.getString("title");
						String newsDesc=newsJObj.getString("description");
						final String imageUrl=newsJObj.getString("image_url");
							final Context context = parent.getContext();
							itemLayout = (LinearLayout) LayoutInflater.from(context).inflate(R.layout.news_flip_list_item, parent,false);
							TextView txteId = (TextView) itemLayout
									.findViewById(R.id.newslist_description_tv);
							txteId.setText(newsDesc);

							// Set the text label as defined in our list item
							TextView txtTitle = (TextView) itemLayout
									.findViewById(R.id.newslist_title_tv);
							txtTitle.setText(newsTitle);
							ImageView txtImage = (ImageView) itemLayout
									.findViewById(R.id.newslist_image_imv);
							try {
								URL url = new URL(imageUrl);
								Bitmap bmp = BitmapFactory.decodeStream(url
										.openConnection().getInputStream());
								txtImage.setImageBitmap(bmp);
								txtImage.setOnClickListener(new OnClickListener() {
									
									@Override
									public void onClick(View v) {
										// TODO Auto-generated method stub
										Intent newintent=new Intent(SubCategoriesTwo.this, Example.class);
										newintent.putExtra("imageUrl", imageUrl);
										startActivity(newintent);
										
									}
								});
//								Log.i("intent", item.getnPicture());
							} catch (Exception e) {
								e.printStackTrace();
							}

//						} 
//						else {
//							itemLayout = (LinearLayout) convertView;
//							
//							// Set the icon as defined in our list item
////							TextView txtcId = (TextView) itemLayout
////									.findViewById(R.id.newslist_cid_tv);
////							txtcId.setText(String.valueOf(newsCatId));
//							TextView txteId = (TextView) itemLayout
//									.findViewById(R.id.newslist_description_tv);
//							txteId.setText(newsDesc);
//
//							// Set the text label as defined in our list item
//							TextView txtTitle = (TextView) itemLayout
//									.findViewById(R.id.newslist_title_tv);
//							txtTitle.setText(newsTitle);
//							ImageView txtImage = (ImageView) itemLayout
//									.findViewById(R.id.newslist_image_imv);
//							try {
//								URL url = new URL(imageUrl);
//								Bitmap bmp = BitmapFactory.decodeStream(url
//										.openConnection().getInputStream());
//								txtImage.setImageBitmap(bmp);
////								Log.i("intent", item.getnPicture());
//							} catch (Exception e) {
//								e.printStackTrace();
//							}
//							
//						}
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					return itemLayout;
				}
			});
			
			
			
			
			
//			if(topNewsArray.length()>1){
//				JSONObject topObj2=(JSONObject) topNewsArray.get(1);
//				final int newsNewsEid = topObj2.getInt("entry_id");
//				String newsNewsTitle = topObj2.getString("title");
//				newsNewsTitleTv.setText(newsNewsTitle);
//				String newsNewsDesc = topObj2.getString("description");
//				newsNewsDescTv.setText(newsNewsDesc);
//				String newsStringNewsImage = topObj2.getString("image_url");
//				ImageHelper.loadImage(newsNewsImage, newsStringNewsImage, true, true, 50);
//				newsNewsImage.setOnClickListener(new OnClickListener() {
//					
//					@Override
//					public void onClick(View v) {
//						// TODO Auto-generated method stub
//						Intent newIntentCover=new Intent(SubCategoriesTwo.this, DisplayListDetails.class);
//						newIntentCover.putExtra("sendeId", newsNewsEid);
//						startActivity(newIntentCover);
//						
//					}
//				});
//			}

			backImage.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					finish();
					
				}
			});
			final List<CatListItem> myJsonArrayList=new ArrayList<CatListItem>(2);
			for(int i=0;i<newsJsonArray.length();i++)
			{
				JSONObject newsJObj=(JSONObject)newsJsonArray.get(i);
				int catid=newsJObj.getInt("category_id");
				String ctitle=newsJObj.getString("category_name");
				myJsonArrayList.add(new CatListItem(catid, ctitle));
			}
			ListAdapter adp1 = new CategoryListAdapter(
					myJsonArrayList, this);
			selectionList.setAdapter(adp1);
			selectionList.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1,
						int position, long arg3) {
					// TODO Auto-generated method stub
					CatListItem catitem = myJsonArrayList.get(position);
					Intent newCatIntent = new Intent(SubCategoriesTwo.this,
							ShowingNews.class);
					int sendCatId = catitem.getcId();
					String sendCatTitle = catitem.getcTitle();
					Log.i(String.valueOf(sendCatId), "fhfgj");
					newCatIntent.putExtra("sendCatId", sendCatId);
					newCatIntent.putExtra("sendCatTitle", sendCatTitle);
					
					
					
					startActivity(newCatIntent);
					
				}
			});
			menuImageView.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent newIntent=new Intent(SubCategoriesTwo.this, MenuOption.class);
					startActivity(newIntent);
					
				}
			});
	} catch (JSONException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

}
	@Override
	protected void onResume() {

	   super.onResume();
	   this.onCreate(null);
	}
		
	}

