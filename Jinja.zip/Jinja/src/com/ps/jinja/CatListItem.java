package com.ps.jinja;

public class CatListItem {
	private String cTitle;
    private int cId;
    
    public CatListItem(int cid,String ctitle)
    {
    	cId=cid;
     	cTitle=ctitle;
    	
    }
    public int getcId() {
        return cId;
    }
  
    public String getcTitle() {
        return cTitle;
    }
    


}
