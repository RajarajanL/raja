package com.ps.jinja;

import java.io.File;

import org.acra.ACRA;
import org.acra.ErrorReporter;
import org.acra.ReportingInteractionMode;
import org.acra.annotation.ReportsCrashes;

import com.nostra13.universalimageloader.cache.disc.impl.UnlimitedDiscCache;
import com.nostra13.universalimageloader.cache.disc.naming.HashCodeFileNameGenerator;
import com.nostra13.universalimageloader.cache.memory.impl.LruMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;
import com.nostra13.universalimageloader.core.decode.BaseImageDecoder;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;
import com.nostra13.universalimageloader.core.download.BaseImageDownloader;
import com.nostra13.universalimageloader.utils.StorageUtils;
import com.ps.jinja.reports.ErrorReportSender;
import com.ps.jinja.session.SessionHandler;
import com.ps.jinja.utils.DetectNetworkConnection;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;



public class SplashLogActivity extends Activity implements OnClickListener{
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
        
        
		super.onCreate(savedInstanceState);
		setContentView(R.layout.log);
		Button logRegister=(Button) findViewById(R.id.log_register_login_btn);
		logRegister.setOnClickListener(this);
		Button logGuest=(Button) findViewById(R.id.log_guest_btn);
		logGuest.setOnClickListener(this);
		
		DisplayImageOptions options = new DisplayImageOptions.Builder().cacheInMemory(true).cacheOnDisk(true).build();
		Context context = getApplicationContext();
		File cacheDir = StorageUtils.getCacheDirectory(context);
		ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(context)
		        .memoryCacheExtraOptions(480, 800)
		        .diskCacheExtraOptions(480, 800, null)
		        .threadPoolSize(3) 
		        .threadPriority(Thread.NORM_PRIORITY - 1) 
		        .tasksProcessingOrder(QueueProcessingType.FIFO) 
		        .denyCacheImageMultipleSizesInMemory()
		        .memoryCache(new LruMemoryCache(2 * 1024 * 1024))
		        .memoryCacheSize(2 * 1024 * 1024)
		        .memoryCacheSizePercentage(13) 
		        .diskCache(new UnlimitedDiscCache(cacheDir)) 
		        .diskCacheSize(50 * 1024 * 1024)
		        .diskCacheFileCount(100)
		        .diskCacheFileNameGenerator(new HashCodeFileNameGenerator()) 
		        .imageDownloader(new BaseImageDownloader(context)) 
		        .imageDecoder(new BaseImageDecoder(false)) 
		        .defaultDisplayImageOptions(options) 
		        .writeDebugLogs()
		        .build();
		ImageLoader.getInstance().init(config);
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		if (id == R.id.log_register_login_btn) {
			Intent logRegIntent=new Intent(SplashLogActivity.this, LogRegisterActivity.class);
			startActivity(logRegIntent);
		} else if (id == R.id.log_guest_btn) {
			
//			
			
			
			if (DetectNetworkConnection.checkInternetConnection(SplashLogActivity.this)) {
//				     Toast.makeText(SplashLogActivity.this,
//				       "You have Internet Connection", Toast.LENGTH_LONG)
//				       .show();
				     Intent logGuestIntent=new Intent(SplashLogActivity.this, JinjaMainActivityNew.class);
						String sendGuest = "Guest";
						SessionHandler.get().removeUser();
						logGuestIntent.putExtra(sendGuest, "sendGuest");
						startActivity(logGuestIntent);
				    } else {
				    	
				    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
				        builder.setMessage("Do You Want To Connect To Internet Now? Click Yes To Open Network Setting Page").setPositiveButton("Yes", dialogClickListener)
				            .setNegativeButton("No", dialogClickListener).show();
				       
				    }	
			
		}
	}
	 DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {

         //@Override
         public void onClick(DialogInterface dialog, int which) {
             switch (which){
             case DialogInterface.BUTTON_POSITIVE:
                 //Yes button clicked
            	 startActivity(new Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS));
                 break;

             case DialogInterface.BUTTON_NEGATIVE:
                 //No button clicked
            	 Toast.makeText(SplashLogActivity.this,"You Do not have Internet Connection",Toast.LENGTH_LONG).show();
                 break;
             }
         }
     };
	
	@Override
	public void onBackPressed() {
		Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
        startActivity(intent);
        
	}
	
}
