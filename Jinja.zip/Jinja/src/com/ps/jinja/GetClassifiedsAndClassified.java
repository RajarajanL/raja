package com.ps.jinja;

import org.json.JSONException;
import org.json.JSONObject;

import com.ps.jinja.constants.URLConstants;
import com.ps.jinja.utils.ApiHelper;
import com.ps.jinja.utils.ImageHelper;

import android.app.Activity;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class GetClassifiedsAndClassified extends Activity implements OnClickListener{
	ImageView produImv,backImv;
	TextView prodName,milage,cost,address;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.get_classifieds_and_classified);
		produImv=(ImageView) findViewById(R.id.get_classifieds_and_classified_product_image_imv);
		backImv=(ImageView) findViewById(R.id.get_classifieds_and_classified_back_imv);
		backImv.setOnClickListener(this);
		prodName=(TextView) findViewById(R.id.get_classifieds_and_classified_product_name_tv);
		milage=(TextView) findViewById(R.id.get_classifieds_and_classified_product_milage_tv);
		cost=(TextView) findViewById(R.id.get_classifieds_and_classified_product_cost_tv);
		address=(TextView) findViewById(R.id.get_classifieds_and_classified_product_address_tv);
		int id=getIntent().getExtras().getInt("id");
		Toast.makeText(getApplicationContext(), "Ha"+id, Toast.LENGTH_LONG).show();
		try{
			String classDetailJsonResult=ApiHelper.getHttpResponseAsString(URLConstants.CLASSIFIED_GET_CLASSIFIEDS_BY_CLASSIFIED_ID+"&classified_id="+id);
			JSONObject classJObj=new JSONObject(classDetailJsonResult);
			String classDetTitle=classJObj.getString("title");
			prodName.setText(classDetTitle);
			String classAddres=classJObj.getString("address");
			address.setText("Address :"+classAddres);
			String classPosted=classJObj.getString("posted_date");
			milage.setText("Posted :"+classPosted);
			int classPrice=classJObj.getInt("price");
			cost.setText("Cost :Rs."+classPrice);
			String classDetimageUrl=classJObj.getString("image_url");
			Log.i(classDetimageUrl, "ImageUrl Detailed");
			ImageHelper.loadImage(produImv, classDetimageUrl, true, true, 30);

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.get_classifieds_and_classified_back_imv:
			finish();
			break;
			

		default:
			break;
		}
		
	}
}
