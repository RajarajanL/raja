package com.ps.jinja;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.aphidmobile.flip.FlipViewController;
import com.ps.jinja.AsynTask.CoverAsynTaskLoader;
import com.ps.jinja.AsynTask.LoadCoverStoryAndFlipAsyncTask;
import com.ps.jinja.AsynTask.LoadNewsSubCatAsyncTask;
import com.ps.jinja.AsynTask.NewsCategoryAsynLoader;
import com.ps.jinja.adapters.CategoryListAdapter;
import com.ps.jinja.constants.URLConstants;
import com.ps.jinja.utils.ApiHelper;
import com.ps.jinja.utils.ImageHelper;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class SubCategoriesNewsPage extends Activity implements OnClickListener {
	TextView catTitleTxtView,topNewsTitleTv,newsNewsDescTv,newsNewsTitleTv;
	ImageView topNewsimage,newsNewsImage,backImage,menuImageView;
	ListView selectionList;
	protected FlipViewController flipViewNews;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.new_example);
		flipViewNews = (FlipViewController) findViewById(R.id.flipView_NewsWithFlip_tttd);
		
		catTitleTxtView=(TextView) findViewById(R.id.top_news_top_lay_title_tv);
		topNewsTitleTv=(TextView) findViewById(R.id.top_news_top_tv);
		topNewsimage=(ImageView) findViewById(R.id.top_news_top_imv);
		backImage=(ImageView) findViewById(R.id.top_news_top_lay_back_imv);
		backImage.setOnClickListener(this);
		selectionList=(ListView) findViewById(R.id.top_news_news_selection_listview);
		menuImageView=(ImageView) findViewById(R.id.top_news_top_lay_menu_imv);
		menuImageView.setOnClickListener(this);
		String catTitle=getIntent().getStringExtra("sendTitle");
		catTitleTxtView.setText(catTitle+" | Top News");
		loadAsyncTaskSpinner();
		
		
		
	}
	private void loadAsyncTaskSpinner() {
		// TODO Auto-generated method stub
		final int catId=getIntent().getExtras().getInt("sendId");
		
	            LoadCoverStoryAndFlipAsyncTask runner1=new LoadCoverStoryAndFlipAsyncTask(this);
	            runner1.execute(String.valueOf(catId));
	            LoadNewsSubCatAsyncTask runner = new LoadNewsSubCatAsyncTask(this);
	            runner.execute(String.valueOf(catId));
		
	}
	
	public void loadNewsSubCategoryList(String jsonResult){
		
		JSONArray newsJsonArray;
		try {
			newsJsonArray = new JSONArray(jsonResult);
		
		final List<CatListItem> myJsonArrayList=new ArrayList<CatListItem>(2);
		for(int i=0;i<newsJsonArray.length();i++)
		{
			JSONObject newsJObj=(JSONObject)newsJsonArray.get(i);
			int catid=newsJObj.getInt("category_id");
			String ctitle=newsJObj.getString("category_name");
			myJsonArrayList.add(new CatListItem(catid, ctitle));
		}
		ListAdapter adp1 = new CategoryListAdapter(
				myJsonArrayList, this);
		selectionList.setAdapter(adp1);
		selectionList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1,
					int position, long arg3) {
				// TODO Auto-generated method stub
				CatListItem catitem = myJsonArrayList.get(position);
				Intent newCatIntent = new Intent(SubCategoriesNewsPage.this,
						ShowingNews.class);
				int sendCatId = catitem.getcId();
				String sendCatTitle = catitem.getcTitle();
				Log.i(String.valueOf(sendCatId), "fhfgj");
				newCatIntent.putExtra("sendCatId", sendCatId);
				newCatIntent.putExtra("sendCatTitle", sendCatTitle);
				startActivity(newCatIntent);
				
			}
		});
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	
	public void loadCoverStoryAndFlip(String jsonResult){
			try{
			
			JSONArray newsJsonArrayFlip = new JSONArray(jsonResult);
			JSONObject coverNewsObject = newsJsonArrayFlip.getJSONObject(0);
			final int topNewsEid = coverNewsObject.getInt("entry_id");
			String topNewsTitle = coverNewsObject.getString("title");
			String topStringNewsImage = coverNewsObject.getString("image_url");
			ImageHelper.loadImage(topNewsimage, topStringNewsImage, true, true, 50);
			topNewsTitleTv.setText(topNewsTitle);
			topNewsimage.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					Intent newIntentCover=new Intent(SubCategoriesNewsPage.this, DisplayListDetails.class);
					newIntentCover.putExtra("sendeId", topNewsEid);
					startActivity(newIntentCover);
				}
			});
			
			final List<JSONObject> newsFlipList = new ArrayList<JSONObject>();
			for(int i=0;i<newsJsonArrayFlip.length();i++){
				if(i != 0)
					newsFlipList.add(newsJsonArrayFlip.getJSONObject(i));
			}
			flipViewNews.setAdapter(new BaseAdapter() {

				@Override
				public int getCount() {
					return newsFlipList.size();
				}

				@Override
				public Object getItem(int position) {
					return position;
				}

				@Override
				public long getItemId(int position) {
					return position;
				}

				@Override
				public View getView(int position, View convertView,
						ViewGroup parent) {

					LinearLayout itemLayout = null;

					try {
						JSONObject newsJObj = (JSONObject) newsFlipList
								.get(position);
						final int newsId=newsJObj.getInt("entry_id");
						String newsTitle=newsJObj.getString("title");
						String newsDesc=newsJObj.getString("description");
						final String imageUrl=newsJObj.getString("image_url");
							final Context context = parent.getContext();
							itemLayout = (LinearLayout) LayoutInflater.from(context).inflate(R.layout.news_flip_list_item, parent,false);
							TextView txteId = (TextView) itemLayout
									.findViewById(R.id.newslist_description_tv);
							txteId.setText(newsDesc);

							// Set the text label as defined in our list item
							TextView txtTitle = (TextView) itemLayout
									.findViewById(R.id.newslist_title_tv);
							txtTitle.setText(newsTitle);
							ImageView txtImage = (ImageView) itemLayout
									.findViewById(R.id.newslist_image_imv);
							try {
								URL url = new URL(imageUrl);
								Bitmap bmp = BitmapFactory.decodeStream(url
										.openConnection().getInputStream());
								txtImage.setImageBitmap(bmp);
								txtImage.setOnClickListener(new OnClickListener() {
									
									@Override
									public void onClick(View v) {
										// TODO Auto-generated method stub
										Intent newintent=new Intent(SubCategoriesNewsPage.this, DisplayListDetails.class);
										newintent.putExtra("sendeId", newsId);
										startActivity(newintent);
										
									}
								});
							} catch (Exception e) {
								e.printStackTrace();
							}


					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					return itemLayout;
				}
			});
			
	}catch (JSONException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

}
	@Override
	protected void onResume() {

	   super.onResume();
	   this.onCreate(null);
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.top_news_top_lay_menu_imv:
			Intent newIntent=new Intent(SubCategoriesNewsPage.this, MenuOption.class);
			startActivity(newIntent);
			break;
		case R.id.top_news_top_lay_back_imv:
			finish();
			break;
		
		default:
			break;
		}
		
	}
}
