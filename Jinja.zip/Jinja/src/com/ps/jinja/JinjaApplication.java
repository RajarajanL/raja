package com.ps.jinja;

import org.acra.ACRA;
import org.acra.ReportingInteractionMode;
import org.acra.annotation.ReportsCrashes;

import com.ps.jinja.reports.ErrorReportSender;

import android.app.Application;
import android.util.Log;


@ReportsCrashes(formKey="",
mailTo="arunn@fluxmachine.com",
mode = ReportingInteractionMode.TOAST,
resToastText = R.string.crash_toast_text)


public class JinjaApplication extends Application{
	@Override
    public void onCreate() {
		 ACRA.init(this);
	        ErrorReportSender yourSender = new ErrorReportSender();
	       
//	        ACRA.getErrorReporter().setReportSender(yourSender);
	        Log.i("fjfj", "Initial ");
		super.onCreate();
		
        
    }
}
