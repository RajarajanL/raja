package com.ps.jinja;

public class SubscriptionItems {
	private String cTitle;
    private int cId;
    private Boolean iSelected;
    
    public SubscriptionItems(int cid,String ctitle,boolean iselected)
    {
    	cId=cid;
     	cTitle=ctitle;
     	iSelected=iselected;
    	
    }
    public int getcId() {
        return cId;
    }
  
    public String getcTitle() {
        return cTitle;
    }
    public Boolean getiSelected(){
    	return iSelected;
    }
}
