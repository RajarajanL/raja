package com.ps.jinja.reports;

import org.acra.collector.CrashReportData;
import org.acra.sender.ReportSender;
import org.acra.sender.ReportSenderException;

import android.util.Log;

public class ErrorReportSender implements ReportSender {

    public ErrorReportSender(){
        // initialize your sender with needed parameters
    }

    @Override
    public void send(CrashReportData report) throws ReportSenderException {
        // Iterate over the CrashReportData instance and do whatever
        // you need with each pair of ReportField key / String value
    	Log.i("Reporting------------------------>", "report");
    }
}