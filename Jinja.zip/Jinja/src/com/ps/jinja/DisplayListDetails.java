package com.ps.jinja;
import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;
import com.ps.jinja.constants.URLConstants;
import com.ps.jinja.session.SessionHandler;
import com.ps.jinja.utils.ApiHelper;
import com.ps.jinja.utils.ImageHelper;
import com.ps.jinja.vo.UserVO;

import android.app.Activity;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;

public class DisplayListDetails extends Activity {
	TextView gTitle,gDesc;
	ImageView gImage;
	HttpEntity resEntity;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.display_full_data);
		final int eId=getIntent().getExtras().getInt("sendeId");
		ImageView gBack=(ImageView) findViewById(R.id.display_full_data_back_imbtn);
		gTitle=(TextView) findViewById(R.id.display_full_data_title_tv);
		gDesc=(TextView) findViewById(R.id.display_full_data_desc_tv);
		gImage=(ImageView) findViewById(R.id.display_full_data_picture_imv);
		
	    TextView addMagazine = (TextView) findViewById(R.id.display_full_data_load_magazine_tv);
	    final UserVO userVO = SessionHandler.get().getUserVO();
	    
		try{
			String newsDetailJsonResult=ApiHelper.getHttpResponseAsString(URLConstants.GET_FULL_DETAILS_BY_EID+"&news_id="+eId);
			JSONObject newsJObj=new JSONObject(newsDetailJsonResult);
			String newsDetTitle=newsJObj.getString("title");
			Log.i(newsDetTitle, "detTitle");
			gTitle.setText(newsDetTitle);
			String newsDetHtml=newsJObj.getString("html");
			gDesc.setText(Html.fromHtml(newsDetHtml));
			Log.i(newsDetHtml, "detht");
			String newsDetimageUrl=newsJObj.getString("image_url");
			ImageHelper.loadImage(gImage, newsDetimageUrl, true, true, 30);

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		gBack.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
				
			}
		});
		UserVO userVo=SessionHandler.get().getUserVO();
			
			if(userVO!=null){
		    	addMagazine.setVisibility(View.VISIBLE);
		    addMagazine.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					int userId=userVO.getUserId();
					HttpClient mClient= new DefaultHttpClient();
					HttpGet get = new HttpGet(URLConstants.UPLOAD_MAGAZINE
							+ "&user_id=" + userId + "&news_id="
							+ eId);
					
						try {
							mClient.execute(get);
						} catch (ClientProtocolException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
						
					
				}
			});
		    }
		    else{
		    	addMagazine.setVisibility(View.GONE);
		    }
		   
		}


	}


