package com.ps.jinja.constants;

public class URLConstants {
	public static final String BASE_DOMAIN =		"http://mem01flux.fluxmachine.com/services/call.php?url=";
	public static final String COVER_STORY="http://mem01flux.fluxmachine.com/services/call.php?url=get-top-news";
	public static final String CATEGORIES_URL = 		BASE_DOMAIN+"get-categories";
	public static final String SUB_CATEGORIES_URL=		BASE_DOMAIN+"get-sub-categories";
	public static final String GET_TOP_NEWS=			BASE_DOMAIN+"get-top-news";
	public static final String GET_NEWS_BY_CATEGORY=    BASE_DOMAIN+"get-news";
	public static final String GET_FULL_DETAILS_BY_EID= BASE_DOMAIN+"get-news-det";
	public static final String GET_CATEGORIES_NEWS_PARENT=BASE_DOMAIN+"get-c-news";
	public static final String GUEST_IMAGE="http://thecontentwrangler.com/wp-content/uploads/2011/08/User.png";
	public static final String SIGNUP_USER=BASE_DOMAIN+"signup-user";
	public static final String UPLOAD_SUBSCRIPTION=BASE_DOMAIN+"add-subscriptions";//cat_id& user_id
	public static final String UPLOAD_MAGAZINE=BASE_DOMAIN+"add-magazine";//user_id& entry_id
	public static final String CLASSIFIEDS_CATEGORIES=BASE_DOMAIN+"get-cl-categories";
	public static final String CLASSIFIEDS_SUB_CATEGORIES=BASE_DOMAIN+"get-cl-sub-categories";
	public static final String CLASSIFIED_GET_CLASSIFIEDS_BY_CAT_ID=BASE_DOMAIN+"get-classifieds";
	public static final String CLASSIFIED_GET_CLASSIFIEDS_BY_CLASSIFIED_ID=BASE_DOMAIN+"get-classified";
	public static final String GET_SUBSCRIPTIONS_URL=BASE_DOMAIN+"get-subscriptions";
	public static final String GET_MAGAZINES_URL=BASE_DOMAIN+"get-magazines";
	public static final String GET_SH_CATEGORIES=BASE_DOMAIN+"get-sh-categories";
	public static final String GET_SH_SUB_CATEGORIES=BASE_DOMAIN+"get-sh-sub-categories"; //&category_id=1
	public static final String GET_PRODUCTS_LIST=BASE_DOMAIN+"get-products";//&category_id=7
	public static final String GET_PRODUCT=BASE_DOMAIN+"get-product";//&product_id=1
	public static final String ADD_CARTS=BASE_DOMAIN+"add-cart";//&user_id=137&product_id=3&count=4&price_item=4000
	public static final String GET_CART=BASE_DOMAIN+"get-carts";//get-carts&user_id=137
	public static final String REMOVE_CART=BASE_DOMAIN+"remove-cart";//remove-cart&cart_id=1
}
//http://mem01flux.fluxmachine.com/services/call.php?url=get-sub-categories&cat_id=1
//http://mem01flux.fluxmachine.com/services/call.php?url=get-news-det&news_id=84
//http://mem01flux.fluxmachine.com/services/call.php?url=get-top-news
//http://mem01flux.fluxmachine.com/services/call.php?url=get-news&category_id=5
//http://mem01flux.fluxmachine.com/services/call.php?url=get-c-news&parent=1
//http://mem01flux.fluxmachine.com/services/call.php?url=add-subscription
//http://mem01flux.fluxmachine.com/services/call.php?url=get-categories
//http://mem01flux.fluxmachine.com/services/call.php?url=get-cl-categories
//http://mem01flux.fluxmachine.com/services/call.php?url=get-cl-sub-categories&category_id=3
//http://mem01flux.fluxmachine.com/services/call.php?url=get-subscriptions&user_id=1
//http://mem01flux.fluxmachine.com/services/call.php?url=get-classifieds&category_id=7
//http://mem01flux.fluxmachine.com/services/call.php?url=get-sh-sub-categories&category_id=2