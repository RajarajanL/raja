package com.ps.jinja.constants;

public class FAILConstants {
	public static final String POOR_CONNECTIONS =		"Poor Connections";

}
