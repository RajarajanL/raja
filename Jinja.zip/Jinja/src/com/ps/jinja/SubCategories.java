package com.ps.jinja;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.ps.jinja.adapters.CategoryListAdapter;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.ListAdapter;
import android.widget.TextView;

public class SubCategories extends Activity {

	String url1 = "http://mem01flux.fluxmachine.com/services/call.php?url=get-sub-categories&cat_id=";
	String url = null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sub_cat_list);
		TextView catNameSub = (TextView) findViewById(R.id.subCat_CatName_tv);
		GridView SubCatnameSub = (GridView) findViewById(R.id.subCat_SubCatName_gv);
		String catTitle = getIntent().getStringExtra("sendTitle");
		catNameSub.setText(catTitle);
		final int catId = getIntent().getExtras().getInt("sendId");
		Log.i(String.valueOf(catId), "cid");
		url = url1 + catId;
		HttpClient newsHttpclient = new DefaultHttpClient();
		HttpPost newsHttppost = new HttpPost(url);
		try {
			HttpResponse newsHttpResponse = newsHttpclient
					.execute(newsHttppost);
			String newsJsonResult = inputStreamToString(
					newsHttpResponse.getEntity().getContent()).toString();
			JSONArray newsJsonArray = new JSONArray(newsJsonResult);
			final List<CatListItem> myJsonArrayList = new ArrayList<CatListItem>(
					2);
			for (int i = 0; i < newsJsonArray.length(); i++) {
				JSONObject newsJObj = (JSONObject) newsJsonArray.get(i);
				int catid = newsJObj.getInt("category_id");
				String ctitle = newsJObj.getString("category_name");
				myJsonArrayList.add(new CatListItem(catid, ctitle));
			}
			ListAdapter adapter11 = new CategoryListAdapter(
					myJsonArrayList, this);
			SubCatnameSub.setAdapter(adapter11);
			SubCatnameSub.setTextFilterEnabled(true);
			SubCatnameSub.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1,
						int position, long id) {
					// TODO Auto-generated method stub
					CatListItem catitem = myJsonArrayList.get(position);
					Intent newCatIntent = new Intent(SubCategories.this,
							ShowingNewsInFlip.class);
					int sendCatId = catitem.getcId();
					String sendCatTitle = catitem.getcTitle();
					Log.i(String.valueOf(sendCatId), "fhfgj");
					newCatIntent.putExtra("sendCatId", sendCatId);
					newCatIntent.putExtra("sendCatTitle", sendCatTitle);
					startActivity(newCatIntent);
					// final CatListItem item = myJsonArrayList.get(position);
					// Intent newIntent=new Intent(SubCategories.this,
					// MailListView.class);
					// String sendcTitle=item.getcTitle();
					// int sentcId=item.getcId();
					// Log.i(String.valueOf(sentcId), "fhfgj");
					// newIntent.putExtra("sendcTitle",sendcTitle);
					// newIntent.putExtra("senctId", sentcId);
					// startActivity(newIntent);

				}
			});
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private StringBuilder inputStreamToString(InputStream is) {
		// TODO Auto-generated method stub
		String rLine = "";
		StringBuilder answer = new StringBuilder();

		InputStreamReader isr = new InputStreamReader(is);

		BufferedReader rd = new BufferedReader(isr);

		try {
			while ((rLine = rd.readLine()) != null) {
				answer.append(rLine);
			}
		}

		catch (IOException e) {
			e.printStackTrace();
		}
		return answer;

	}
}
