package com.ps.jinja;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore.MediaColumns;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Toast;

import com.ps.jinja.adapters.PostClassCategoryAdapterForSpinner;
import com.ps.jinja.constants.URLConstants;
import com.ps.jinja.listItems.ClassifiedSpinnerItem;
import com.ps.jinja.utils.ApiHelper;

public class PostAdds extends Activity implements OnClickListener{
	LinearLayout firstLin,secondLin,thirdLin,fourthLin;
	Button nextFirst,nextSecond,nextThird,postFourth,pagOne,pagTwo,pagThree,pagFour;
    ImageView backImv,browse1,browse2,browse3,browse4;
    EditText enterPostTitle,enterPostDesc,enterPostPno,enterPostEmail,enterPostPrice;
    private static int RESULT_LOAD_IMAGE = 1;
    private String picturePath1,picturePath2,picturePath3,picturePath4;
    private String imageBrowseKey=null;
    
@Override
protected void onCreate(Bundle savedInstanceState) {
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	setContentView(R.layout.post_adds);
	firstLin=(LinearLayout) findViewById(R.id.postadd_first_linear_layout);
	secondLin=(LinearLayout) findViewById(R.id.postadd_second_linear_layout);
	thirdLin=(LinearLayout) findViewById(R.id.postadd_third_linear_layout);
	fourthLin=(LinearLayout) findViewById(R.id.postadd_four_linear_layout);
	
	nextFirst=(Button) findViewById(R.id.postadd_first_linear_layout_next_btn);
	nextFirst.setOnClickListener(this);
	nextSecond=(Button) findViewById(R.id.postadd_second_linear_layout_next_btn);
	nextSecond.setOnClickListener(this);
	nextThird=(Button) findViewById(R.id.postadd_third_linear_layout_next_btn);
	nextThird.setOnClickListener(this);
	postFourth=(Button) findViewById(R.id.postadd_fourth_linear_layout_post_btn);
	postFourth.setOnClickListener(this);
	
	
	
	pagOne=(Button) findViewById(R.id.button111);
	pagTwo=(Button) findViewById(R.id.button222);
	pagThree=(Button) findViewById(R.id.button333);
	pagFour=(Button) findViewById(R.id.button444);
	
	
	
	backImv=(ImageView) findViewById(R.id.postAdd_back_imv);
	backImv.setOnClickListener(this);
	browse1=(ImageView) findViewById(R.id.image_browse1);
	browse1.setOnClickListener(this);
	browse2=(ImageView) findViewById(R.id.image_browse2);
	browse2.setOnClickListener(this);
	browse3=(ImageView) findViewById(R.id.image_browse3);
	browse3.setOnClickListener(this);
	browse4=(ImageView) findViewById(R.id.image_browse4);
	browse4.setOnClickListener(this);
	
	Spinner spinner1=(Spinner) findViewById(R.id.post_current_location_spin);
	Spinner spinner2=(Spinner) findViewById(R.id.post_ad_location_ad_spin);
	Spinner classifiedCategorySpin=(Spinner) findViewById(R.id.post_select_classi_category_spin);
	final Spinner classifiedSubCatSpin=(Spinner) findViewById(R.id.post_select_classi_sub_cat_spin);
	
	
	enterPostTitle=(EditText) findViewById(R.id.post_enter_title_et);
	enterPostDesc=(EditText) findViewById(R.id.post_enter_description_et);
	enterPostPno=(EditText) findViewById(R.id.post_enter_phone_no_et);
	enterPostEmail=(EditText) findViewById(R.id.post_enter_email_et);
	enterPostPrice=(EditText) findViewById(R.id.post_enter_price_et);
	
	
	List<String> loaction=new ArrayList<String>();
	loaction.add("Chennai");
	loaction.add("Bangalore");
	loaction.add("Kolkatta");
	loaction.add("Mumbai");
	loaction.add("Varanasi");
	loaction.add("Delhi");
	loaction.add("Lucknow");
	Log.i(String.valueOf(loaction), "hgdjha");
	ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
	        android.R.layout.simple_spinner_item, loaction);
	    dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	    spinner1.setAdapter(dataAdapter);
	    spinner2.setAdapter(dataAdapter);

	    
	    
	    String classifiedCatString=ApiHelper.getHttpResponseAsString(URLConstants.CLASSIFIEDS_CATEGORIES);
		 if(classifiedCatString==null){
			 return;
		 }
		 try {
			 boolean is=false;
			JSONArray classifiedJsonArray=new JSONArray(classifiedCatString);
			final List<ClassifiedSpinnerItem> classifiedCatList=new ArrayList<ClassifiedSpinnerItem>();
			if(is==false){
				classifiedCatList.add(new ClassifiedSpinnerItem(1111111,"-----Select-----"));
				is=true;
			}
			for(int i=0;i<classifiedJsonArray.length();i++){
				JSONObject jsonObject=classifiedJsonArray.getJSONObject(i);
				int classifiedId=jsonObject.getInt("category_id");
				String classCatName=jsonObject.getString("category_name");
				
				classifiedCatList.add(new ClassifiedSpinnerItem(classifiedId, classCatName));
			}
			ListAdapter adp1 = new PostClassCategoryAdapterForSpinner(
					classifiedCatList, this);
			    classifiedCategorySpin.setAdapter((SpinnerAdapter) adp1);
			    
			    
			    
			    classifiedCategorySpin.setOnItemSelectedListener(new OnItemSelectedListener() {
			    	 
		          
					@Override
					public void onItemSelected(AdapterView<?> arg0, View arg1,
							int position, long arg3) {
						// TODO Auto-generated method stub
						ClassifiedSpinnerItem catitem = classifiedCatList.get(position);
						 int id=catitem.getclassifiedId();
		              
		                String clasSubJsonStringResult=ApiHelper.getHttpResponseAsString(URLConstants.CLASSIFIEDS_SUB_CATEGORIES+"&category_id="+id);
		                JSONArray clasSubJsonArray;
						try {
							clasSubJsonArray = new JSONArray(clasSubJsonStringResult);
							final List<String> classSubList=new ArrayList<String>();
			    			for(int i=0;i<clasSubJsonArray.length();i++)
			    			{
			    				JSONObject newsJObj=(JSONObject)clasSubJsonArray.get(i);
			    				int catid=newsJObj.getInt("category_id");
			    				String ctitle=newsJObj.getString("category_name");
			    				classSubList.add(ctitle);
			    			}
			    			ArrayAdapter<String> dataAdapter1 = new ArrayAdapter<String>(PostAdds.this,android.R.layout.simple_list_item_1,classSubList);
			    			    dataAdapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			    			    classifiedSubCatSpin.setAdapter(dataAdapter1);
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
		    			
					}

					@Override
					public void onNothingSelected(AdapterView<?> arg0) {
						// TODO Auto-generated method stub
						
					}
		        });
			    
			    
			    
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
}
@Override
public void onClick(View v) {
	// TODO Auto-generated method stub
	switch (v.getId()) {
	case R.id.postadd_first_linear_layout_next_btn:
		if(firstLin.getVisibility()==View.VISIBLE)
		{
			firstLin.setVisibility(View.GONE);
			secondLin.setVisibility(View.VISIBLE);
			thirdLin.setVisibility(View.GONE);
			fourthLin.setVisibility(View.GONE);
			pagOne.setBackgroundResource(R.drawable.round_new_button);
			pagOne.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					
					firstLin.setVisibility(View.VISIBLE);
					secondLin.setVisibility(View.GONE);
					thirdLin.setVisibility(View.GONE);
					fourthLin.setVisibility(View.GONE);
					pagTwo.setOnClickListener(null);
					pagTwo.setBackgroundResource(R.drawable.round_image);
					pagThree.setOnClickListener(null);
					pagThree.setBackgroundResource(R.drawable.round_image);
					pagFour.setOnClickListener(null);
					pagFour.setBackgroundResource(R.drawable.round_image);
				}
			});
		}
		break;
	case R.id.postadd_second_linear_layout_next_btn:
		if(secondLin.getVisibility()==View.VISIBLE){
			firstLin.setVisibility(View.GONE);
			secondLin.setVisibility(View.GONE);
			thirdLin.setVisibility(View.VISIBLE);
			fourthLin.setVisibility(View.GONE);
			pagTwo.setBackgroundResource(R.drawable.round_new_button);
			pagTwo.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					
					firstLin.setVisibility(View.GONE);
					secondLin.setVisibility(View.VISIBLE);
					thirdLin.setVisibility(View.GONE);
					fourthLin.setVisibility(View.GONE);
					pagThree.setOnClickListener(null);
					pagThree.setBackgroundResource(R.drawable.round_image);
					pagFour.setOnClickListener(null);
					pagFour.setBackgroundResource(R.drawable.round_image);
				}
			});
		}
		break;
		
	case R.id.postadd_third_linear_layout_next_btn:
		if(thirdLin.getVisibility()==View.VISIBLE){
			firstLin.setVisibility(View.GONE);
			secondLin.setVisibility(View.GONE);
			thirdLin.setVisibility(View.GONE);
			fourthLin.setVisibility(View.VISIBLE);
			pagThree.setBackgroundResource(R.drawable.round_new_button);
			pagThree.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					
					firstLin.setVisibility(View.GONE);
					secondLin.setVisibility(View.GONE);
					thirdLin.setVisibility(View.VISIBLE);
					fourthLin.setVisibility(View.GONE);
					pagFour.setOnClickListener(null);
					pagFour.setBackgroundResource(R.drawable.round_image);
				}
			});
		}
		break;
		
	case R.id.postadd_fourth_linear_layout_post_btn:
		Toast.makeText(getApplicationContext(), "Posting....", Toast.LENGTH_LONG).show();
		

		break;
		
	case R.id.image_browse1:
		Toast.makeText(getApplicationContext(), "image1", Toast.LENGTH_LONG).show();
		 Intent i = new Intent(
                 Intent.ACTION_PICK,
                 android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
		 imageBrowseKey="Raja";
		 
         startActivityForResult(i, RESULT_LOAD_IMAGE);
		break;
	case R.id.postAdd_back_imv:
		finish();
		break;
	case R.id.image_browse2:
		 Intent i1 = new Intent(
                Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
		  imageBrowseKey="Raj";
        startActivityForResult(i1, RESULT_LOAD_IMAGE);
		break;
	case R.id.image_browse3:
		Intent i2 = new Intent(
                Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
		  imageBrowseKey="Ra";
        startActivityForResult(i2, RESULT_LOAD_IMAGE);;
		break;
	case R.id.image_browse4:
		Intent i3 = new Intent(
                Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
		  imageBrowseKey="R";
        startActivityForResult(i3, RESULT_LOAD_IMAGE);
		break;

	default:
		break;
	}
	
}

@Override
protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
     
    if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && null != data) {
        Uri selectedImage = data.getData();
        String[] filePathColumn = { MediaColumns.DATA };

        Cursor cursor = getContentResolver().query(selectedImage,
                filePathColumn, null, null, null);
        cursor.moveToFirst();
        int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
         String img=imageBrowseKey;
         
         
        Log.i(img, "Browseimage");
        if(img.equals("Raja")){
        	picturePath1 = cursor.getString(columnIndex);
            cursor.close();
            Log.i(picturePath1, "path1");
        browse1.setImageBitmap(BitmapFactory.decodeFile(picturePath1));
        }
        else if(img.equals("Raj"))
        {
        	picturePath2 = cursor.getString(columnIndex);
            cursor.close();
            Log.i(picturePath2, "path2");
        	browse2.setImageBitmap(BitmapFactory.decodeFile(picturePath2));
        }
        else if(img.equals("Ra"))
        {
        	picturePath3 = cursor.getString(columnIndex);
            cursor.close();
            Log.i(picturePath3, "path3");
        	browse3.setImageBitmap(BitmapFactory.decodeFile(picturePath3));
        }
        else if(img.equals("R"))
        {
        	picturePath4 = cursor.getString(columnIndex);
            cursor.close();
            Log.i(picturePath4, "path4");
        	browse4.setImageBitmap(BitmapFactory.decodeFile(picturePath4));
        }
        return;
     
    }
 
 
}
}
