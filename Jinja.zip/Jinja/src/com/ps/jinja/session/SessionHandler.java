package com.ps.jinja.session;

import com.ps.jinja.vo.UserVO;

public class SessionHandler {
	private static SessionHandler singleton = new SessionHandler();
	private static UserVO userVO;
//	private static String classifiedImageId;
	

	private SessionHandler(){
		
	}
	
	public static SessionHandler get(){
		return singleton;
	}
	
	public void setUserVO(UserVO userVO){
		SessionHandler.userVO = userVO;
	}
	
	public UserVO getUserVO(){
		return SessionHandler.userVO;
	}
	
	
	public void removeUser(){
		SessionHandler.userVO = null;
	}
//
//	public String getClassifiedImageId() {
//		return classifiedImageId;
//	}
//
//	public void setClassifiedImageId(String classifiedImageId) {
//		SessionHandler.classifiedImageId = classifiedImageId;
//	}
	
}
