package com.ps.jinja;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Debug;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.TextView;

import com.aphidmobile.flip.FlipViewController;
import com.ps.jinja.AsynTask.CoverAsynTaskLoader;
import com.ps.jinja.AsynTask.NewsCategoryAsynLoader;
import com.ps.jinja.adapters.MyGridListItemAdapter;
import com.ps.jinja.constants.URLConstants;
import com.ps.jinja.session.SessionHandler;
import com.ps.jinja.utils.ImageHelper;
import com.ps.jinja.vo.UserVO;

public class JinjaMainActivityNew extends Activity implements OnClickListener{
	int coverNewsEid; 
	protected FlipViewController flipview;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_mail_main);
//		Debug.startMethodTracing("JINJA APPLICTAION");
		TextView userNameTxt = (TextView) findViewById(R.id.mail_main_displayCatTitle_userName_tv);
		ImageView userImageView = (ImageView) findViewById(R.id.mail_main_displayCatTitle_userPic_imv);
		ImageView menuImage=(ImageView) findViewById(R.id.mail_main_displayCatTitle_option_imv);
		menuImage.setOnClickListener(this);
		final UserVO userVO = SessionHandler.get().getUserVO();
		try {
			// tests
			if(null != userVO){
				userNameTxt.setText(userVO.getfName()+" "+userVO.getlName());
				String userImage=userVO.getImageUrl();
				if(userImage.equals("")||userImage==null){
					Log.i(userImage, "User Image Empty");

				}else{
					Log.i(userImage, "image");

				}
				URL url = new URL(userImage);
				Bitmap bmp = BitmapFactory.decodeStream(url.openConnection()
						.getInputStream());
				Bitmap finalImg = ImageHelper.getRoundedCornerBitmap(bmp, 10);
				userImageView.setImageBitmap(finalImg);
			}else{
				userNameTxt.setText("Guest");				
				URL url = new URL(URLConstants.GUEST_IMAGE);
				Bitmap bmp = BitmapFactory.decodeStream(url.openConnection()
						.getInputStream());
				Bitmap finalImg = ImageHelper.getRoundedCornerBitmap(bmp, 10);
				userImageView.setImageBitmap(finalImg);
			}

		}catch (IOException e) {

			Log.e("Debug", "error: " + e.getMessage(), e);
			e.printStackTrace();
		}
		
		coverNewsLoadSpinner();
		
		
		
	}

	private void coverNewsLoadSpinner() {
		// TODO Auto-generated method stub
		int test=1;
		String tes1="Sweety";
	            CoverAsynTaskLoader runner = new CoverAsynTaskLoader(this);
	            runner.execute(String.valueOf(test),tes1);
	            NewsCategoryAsynLoader runner1=new NewsCategoryAsynLoader(this);
	            runner1.execute("");
		
	}

	
	public void loadCoverStory(String coversJsonResult){
		

		Debug.startMethodTracing("Cover News");
		TextView coverTitle = (TextView) findViewById(R.id.mail_main_displayCatTitle_coverTitle_tv);
		ImageView coverImage = (ImageView) findViewById(R.id.mail_main_displayCatTitle_cover_imv);
		coverImage.setOnClickListener(this);
		JSONObject coversJObj;
		try {
			coversJObj = new JSONObject(coversJsonResult);
			coverNewsEid = coversJObj.getInt("entry_id");
			String coverNewsTitle = coversJObj.getString("title");
			coverTitle.setText(coverNewsTitle);
			
			String coversNewsImage = coversJObj.getString("image_url");
			ImageHelper.loadImage(coverImage, coversNewsImage, true, true, 50);
			
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Debug.stopMethodTracing();
	}
	

	public void loadNewsUrl(String newsJsonResult){
		Debug.startMethodTracing("Categories On flip view");
		flipview=(FlipViewController) findViewById(R.id.mail_main_displayCatTitle_FlipView);
		int no_Of_part=6;
		List<MyGridCustomListItem> partitionList=new ArrayList<MyGridCustomListItem>();
		final List<List<MyGridCustomListItem>> flipList=new ArrayList<List<MyGridCustomListItem>>();

		
		try{		
		final TextView page=(TextView) findViewById(R.id.pagea_text);
		final TextView no_page=(TextView) findViewById(R.id.total_pages);
		int counter=0;
		final JSONArray flipJsonArray=new JSONArray(newsJsonResult);

		for (int i = 0; i < flipJsonArray.length(); i++) {
			JSONObject flipJObj = (JSONObject) flipJsonArray.get(i);
			int newsCatId = flipJObj.getInt("category_id");
			String newsTitle = flipJObj.getString("category_name");
			String newsImage = flipJObj.getString("image_url");
			Log.i(newsImage, "Categories Image In Grid");
			partitionList.add(new MyGridCustomListItem(newsCatId, newsTitle, newsImage));
			counter++;
			if(counter%no_Of_part==0||counter==flipJsonArray.length()){
				flipList.add(partitionList);
				partitionList=new ArrayList<MyGridCustomListItem>();
			}
			Log.i(String.valueOf(flipList), "Partition List");
		}
		flipview.setAdapter(new BaseAdapter() {

			@Override
			public int getCount() {
				return flipList.size();
			}

			@Override
			public Object getItem(int position) {
				return position;
			}

			@Override
			public long getItemId(int position) {
				return position;
			}

			@Override
			public View getView(int position, View convertView,
					ViewGroup parent) {

				LinearLayout itemLayout = null;
				final Context context = parent.getContext();
				final List<MyGridCustomListItem> items = flipList.get(position);
					
				ListAdapter adapter = new MyGridListItemAdapter(items, context);

				
				itemLayout = (LinearLayout) LayoutInflater.from(context)
						.inflate(R.layout.jinja_main_flip_list_item,
								parent, false);
				// Set the icon as defined in our list item
				GridView flipGrid = (GridView) itemLayout
						.findViewById(R.id.jinja_main_flip_grid_view);
				page.setText(String.valueOf(position));
				no_page.setText(String.valueOf(flipList.size()));
				Log.i(String.valueOf(adapter), "Adapter Values Of grid");
				flipGrid.setAdapter(adapter);
				flipGrid.setTextFilterEnabled(true);
				flipGrid.setOnItemClickListener(new OnItemClickListener() {
	
					@Override
					public void onItemClick(AdapterView<?> arg0, View arg1,
							int position, long arg3) {
						final MyGridCustomListItem item =items.get(position);
								
						Intent newIntent = new Intent(JinjaMainActivityNew.this,
								SubCategoriesNewsPage.class);
	
						int sendId = item.getgId();
						String sendTitle = item.getgTitle();
						newIntent.putExtra("sendTitle", sendTitle);
						newIntent.putExtra("sendId", sendId);
						startActivity(newIntent);
	
					}
				});
				
				return itemLayout;
			}
		});
		


		Debug.stopMethodTracing();
	} catch (JSONException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		Log.e("JSON Parser", "Error parsing data " + e.toString());
	}

		
		
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.mail_main_displayCatTitle_cover_imv:
			Intent newIntentCover=new Intent(JinjaMainActivityNew.this, DisplayListDetails.class);
			newIntentCover.putExtra("sendeId", coverNewsEid);
			startActivity(newIntentCover);
			break;
		case R.id.mail_main_displayCatTitle_option_imv:
			Intent newIntent=new Intent(JinjaMainActivityNew.this, MenuOption.class);
			startActivity(newIntent);
			break;
		default:
			break;
		}
		
	}
	@Override
	public void onBackPressed() {
		UserVO userVO = SessionHandler.get().getUserVO();
		if(userVO==null){
			super.onBackPressed();
		}
		else{
			Intent intent = new Intent(Intent.ACTION_MAIN);
			intent.addCategory(Intent.CATEGORY_HOME);
			intent.setFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);

			startActivity(intent);

		}

	}
	@Override
	protected void onResume() {

		super.onResume();
		this.onCreate(null);
	}


}
