package com.ps.jinja;

public class MyGridCustomListItem {
	private String gTitle;
    private int gId;
    private String gImage;
   
    public MyGridCustomListItem(int gid,String gtitle,String gimage)
    {
    	gId=gid;
    	gTitle=gtitle;
    	gImage=gimage;
    	
    }
    public int getgId() {
        return gId;
    }
    
    public String getgTitle() {
        return gTitle;
    }
    public String getgImage(){
		return gImage;
    	
    }


}
