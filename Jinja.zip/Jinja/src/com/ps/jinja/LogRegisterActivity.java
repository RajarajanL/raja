package com.ps.jinja;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;

import com.ps.jinja.session.SessionHandler;
import com.ps.jinja.vo.UserVO;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LogRegisterActivity extends Activity {
	Button logIn, register;
	EditText emailId, password;
	String loginUrl = "http://mem01flux.fluxmachine.com/services/call.php?url=login-user";

	@TargetApi(Build.VERSION_CODES.FROYO)
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_loging);
		logIn = (Button) findViewById(R.id.login_btn);
		register =  (Button) findViewById(R.id.register_btn);
		register.setOnClickListener(new OnClickListener() {
	
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent regisIntent = new Intent(LogRegisterActivity.this,
						RegisterActivity.class);
				startActivity(regisIntent);

			}
		});
		emailId = (EditText) findViewById(R.id.mailid);
		password = (EditText) findViewById(R.id.password);
		
		logIn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String email = emailId.getText().toString();
				String pass = password.getText().toString();
				if (email.length() == 0) {
					emailId.setError("Please enter the login email address");
					emailId.setFocusable(true);
				} else if (pass.length() == 0) {
					password.setError("Please enter the password");
					password.setFocusable(true);
				} else {
					try {
						HttpClient loginHttpclient = new DefaultHttpClient();
						HttpPost loginHttppost = new HttpPost(loginUrl
								+ "&email=" + emailId.getText() + "&password="
								+ password.getText());
						HttpResponse loginHttpResponse = loginHttpclient
								.execute(loginHttppost);
						String loginJsonResult = inputStreamToString(
								loginHttpResponse.getEntity().getContent())
								.toString();
						JSONObject loginJObj = new JSONObject(loginJsonResult);
						Integer status = loginJObj.getInt("status");
						if(status == 1){
							String firstName = loginJObj.getString("f_name");
							String loginEmail = loginJObj.getString("email");
							String lastName = loginJObj.getString("l_name");
							String password = loginJObj.getString("password");
							String userImage = loginJObj.getString("user_img");
							
							UserVO user = new UserVO(1, firstName, lastName, loginEmail, password, userImage);
							SessionHandler.get().setUserVO(user);
	
							Intent logInIntent = new Intent(
									LogRegisterActivity.this,
									JinjaMainActivityNew.class);
							startActivity(logInIntent);
						}else{
							Toast.makeText(getApplicationContext(), "Wrong",
									Toast.LENGTH_SHORT).show();
						}

					} catch (final ClientProtocolException e) {
						e.printStackTrace();
						runOnUiThread(new Runnable() {
							
							@SuppressLint("ShowToast")
							@Override
							public void run() {
								// TODO Auto-generated method stub
								
								Toast.makeText(getApplicationContext(), "Please Enable It", Toast.LENGTH_LONG).show();
								
							}
						});
					} catch (final IOException e) {
						e.printStackTrace();
						runOnUiThread(new Runnable() {
							
							@SuppressLint("ShowToast")
							@Override
							public void run() {
								// TODO Auto-generated method stub
//								INput Ouput Excepton
								Toast.makeText(getApplicationContext(), "No Internet Service Please Enable It", Toast.LENGTH_LONG).show();
	
							}
						});
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

			}
		});

	}
	
	
	private StringBuilder inputStreamToString(InputStream is) {
		// TODO Auto-generated method stub
		String rLine = "";
		StringBuilder answer = new StringBuilder();

		InputStreamReader isr = new InputStreamReader(is);

		BufferedReader rd = new BufferedReader(isr);

		try {
			while ((rLine = rd.readLine()) != null) {
				answer.append(rLine);
			}
		}

		catch (IOException e) {
			e.printStackTrace();
		}
		return answer;

	}
	

}
