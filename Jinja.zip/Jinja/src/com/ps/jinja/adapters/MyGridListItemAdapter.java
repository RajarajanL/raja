package com.ps.jinja.adapters;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.ps.jinja.MyGridCustomListItem;
import com.ps.jinja.R;
import com.ps.jinja.utils.ImageHelper;

public class MyGridListItemAdapter extends BaseAdapter {


	private List<MyGridCustomListItem> items;
	    private Context context;
	    private int numItems = 0;
	    public MyGridListItemAdapter(final List<MyGridCustomListItem> items, Context context) {
	        this.items = items;
	        this.context = context;
	        this.numItems = items.size();
	    }
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return numItems;
	}
	@Override
	public MyGridCustomListItem getItem(int position) {
        return items.get(position);
    }
	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
        final MyGridCustomListItem item = items.get(position);
        final RelativeLayout itemLayout = (RelativeLayout) LayoutInflater.from(context).inflate(R.layout.preparing_title_grid_data, parent, false);
         TextView txtLabel = (TextView) itemLayout.findViewById(R.id.grid_title_tv);
        txtLabel.setText(item.getgTitle());
        ImageView txtImage=(ImageView) itemLayout.findViewById(R.id.grid_imageview);

        ImageHelper.loadImage(txtImage, item.getgImage(), true, true, 15);

            	
        return itemLayout;
    }

}
