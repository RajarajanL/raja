package com.ps.jinja.adapters;

import java.util.List;

import com.ps.jinja.NewsListItem;
import com.ps.jinja.R;
import com.ps.jinja.listItems.ClassifiedListItem;
import com.ps.jinja.utils.ImageHelper;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class ClassifiedListAdapter extends BaseAdapter {

	private List<ClassifiedListItem> items;
	private Context context;
	private int numItems=0;
	public ClassifiedListAdapter(List<ClassifiedListItem> items,Context context)
	{
		this.items = items;
        this.context = context;
        this.numItems = items.size();
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return numItems;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return items.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	 @Override
	public View getView(int position, View convertView, ViewGroup parent) {
	       
	        final ClassifiedListItem item = items.get(position);
	        final RelativeLayout itemLayout = (RelativeLayout) LayoutInflater.from(context).inflate(R.layout.classified_adapter_for_categories, parent, false);
	      
	        TextView txtTitle = (TextView) itemLayout.findViewById(R.id.classified_adapter_name_tv);
	        txtTitle.setText(item.getcTitle());
//	        String alterImage="http://4.bp.blogspot.com/-44trijSlV2Y/UgU0J6RU87I/AAAAAAAAASU/Nppm2hzUboU/s1600/no_image.jpg";
	        ImageView txtImage=(ImageView) itemLayout.findViewById(R.id.classified_adapter_image_imv);
	        Log.i(item.getcPicture(), "Image Get");
//	        Log.i(alterImage, "Image desh Get");
//	        if(null==item.getcPicture()){
//	        	ImageHelper.loadImage(txtImage, alterImage, true, true, 30);
//	        
//	        }else{
	        	ImageHelper.loadImage(txtImage, item.getcPicture(), true, true, 30);
//	        }
	        

	        return itemLayout;
	    }
}
