package com.ps.jinja.adapters;

import java.util.List;

import com.ps.jinja.NewsListItem;
import com.ps.jinja.R;
import com.ps.jinja.utils.ImageHelper;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class NewsListItemAdapter extends BaseAdapter {

	private List<NewsListItem> items;
	private Context context;
	private int numItems=0;
	public NewsListItemAdapter(List<NewsListItem> items,Context context)
	{
		this.items = items;
        this.context = context;
        this.numItems = items.size();
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return numItems;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return items.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	 @Override
	public View getView(int position, View convertView, ViewGroup parent) {
	       
	        final NewsListItem item = items.get(position);
	        final RelativeLayout itemLayout = (RelativeLayout) LayoutInflater.from(context).inflate(R.layout.news_list_grid_title_item, parent, false);
	      
	        TextView txtTitle = (TextView) itemLayout.findViewById(R.id.list_grid_title_tv);
	        txtTitle.setText(item.getnTitle());
	        TextView txtDesc=(TextView) itemLayout.findViewById(R.id.list_grid_title_desc_tv);
	        txtDesc.setText(item.getnDesc());
	        ImageView txtImage=(ImageView) itemLayout.findViewById(R.id.list_grid_title_image_imv);
	        ImageHelper.loadImage(txtImage, item.getnPicture(), true, true, 30);
	       
	        

	        return itemLayout;
	    }

}
