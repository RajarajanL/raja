package com.ps.jinja.adapters;

import java.io.IOException;
import java.util.List;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.ps.jinja.Carts;
import com.ps.jinja.R;
import com.ps.jinja.constants.URLConstants;
import com.ps.jinja.listItems.CartListItem;

public class CartAdapter extends BaseAdapter {

	private List<CartListItem> items;
	private Context context;
	private int numItems = 0;

	public CartAdapter(List<CartListItem> items, Context context) {
		this.items = items;
		this.context = context;
		this.numItems = items.size();
	}

	@Override
	public int getCount() {
		return numItems;
	}

	@Override
	public Object getItem(int position) {
		return items.get(position);
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		// Get the current list item
		final CartListItem item = items.get(position);
		// Get the layout for the list item
		final RelativeLayout itemLayout = (RelativeLayout) LayoutInflater.from(
				context).inflate(R.layout.cart_adapter, parent, false);
		TextView txtCartId = (TextView) itemLayout
				.findViewById(R.id.cart_id_tv);
		txtCartId.setText("Cart Id:"+String.valueOf(item.getCartId()));
		TextView txtCartPrice = (TextView) itemLayout
				.findViewById(R.id.cart_price_tv);
		txtCartPrice.setText("Price: Rs."+String.valueOf(item.getcPrice()));

		TextView txtCartCount = (TextView) itemLayout
				.findViewById(R.id.cart_count_tv);
		txtCartCount.setText("Quantity:"+String.valueOf(item.getcCount()));

		TextView txtCartProductId = (TextView) itemLayout
				.findViewById(R.id.cart_productid_tv);
		txtCartProductId.setText("Product Id:"+String.valueOf(item.getcProductId()));
		
		ImageButton btnImg=(ImageButton) itemLayout.findViewById(R.id.cart_delete_btn);
		btnImg.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Toast.makeText(context, "Deleted", Toast.LENGTH_LONG).show();
				
				try {
					HttpClient mClient= new DefaultHttpClient();

					HttpGet get = new HttpGet(URLConstants.REMOVE_CART+"&cart_id="+item.getCartId());
					Log.i(String.valueOf(get), "HTTP URL");
					mClient.execute(get);
					notifyDataSetChanged();
//					 ((Carts)context).finish();
					 Intent newIntent=new Intent(context, Carts.class);
					 ((Carts)context).startActivity(newIntent);
					
					} catch (ClientProtocolException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
			}
		});


		return itemLayout;
	}
	
}
