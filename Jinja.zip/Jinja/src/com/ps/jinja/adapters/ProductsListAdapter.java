package com.ps.jinja.adapters;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.ps.jinja.R;
import com.ps.jinja.listItems.ProductsListItem;
import com.ps.jinja.utils.ImageHelper;

public class ProductsListAdapter extends BaseAdapter {
	
	private List<ProductsListItem> items;
	private Context context;
	private int numItems = 0;

	public ProductsListAdapter(List<ProductsListItem> items, Context context) {
		this.items = items;
		this.context = context;
		this.numItems = items.size();
	}

	@Override
	public int getCount() {
		return numItems;
	}

	@Override
	public Object getItem(int position) {
		return items.get(position);
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		// Get the current list item
		final ProductsListItem item = items.get(position);
		// Get the layout for the list item
		final RelativeLayout itemLayout = (RelativeLayout) LayoutInflater.from(
				context).inflate(R.layout.products_list_adapter, parent, false);
		TextView txtTitle = (TextView) itemLayout
				.findViewById(R.id.products_list_adap_title_tv);
		txtTitle.setText(item.getpTitle());
		ImageView txtImage=(ImageView) itemLayout.findViewById(R.id.products_list_adap_imv);
		ImageHelper.loadImage(txtImage, item.getpImage(), true, true, 30);
		TextView txtPrice = (TextView) itemLayout
				.findViewById(R.id.products_list_adap_price_tv);
		txtPrice.setText("Rs."+String.valueOf(item.getpPrice()));
		return itemLayout;

	}

}
