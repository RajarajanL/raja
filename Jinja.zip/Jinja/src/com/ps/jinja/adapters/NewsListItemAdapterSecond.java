package com.ps.jinja.adapters;

import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.ps.jinja.NewsListItem;
import com.ps.jinja.R;
import com.ps.jinja.utils.ImageHelper;

public class NewsListItemAdapterSecond extends BaseAdapter{
	private List<NewsListItem> items;
	private Context context;
	private int numItems=0;
	public NewsListItemAdapterSecond(List<NewsListItem> items,Context context)
	{
		this.items = items;
        this.context = context;
        this.numItems = items.size();
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return numItems;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return items.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	 @Override
	public View getView(int position, View convertView, ViewGroup parent) {
	       
	        // Get the current list item
	        final NewsListItem item = items.get(position);
	        // Get the layout for the list item
	        final RelativeLayout itemLayout = (RelativeLayout) LayoutInflater.from(context).inflate(R.layout.news_list_grid_title_item_second, parent, false);
	        TextView txtTitle = (TextView) itemLayout.findViewById(R.id.list_grid_title_second_tv);
	        txtTitle.setText(item.getnTitle());
	        TextView txtDesc=(TextView) itemLayout.findViewById(R.id.list_grid_title_desc_second_tv);
	        txtDesc.setText(item.getnDesc());
	        ImageView txtImage=(ImageView) itemLayout.findViewById(R.id.list_grid_title_image_second_imv);
	       ImageHelper.loadImage(txtImage, item.getnPicture(), true, false, 50);
//	       Bitmap bmp = ImageHelper.getBitmapFromURL(item.getnPicture());
//	       txtImage.setImageBitmap(ImageHelper.getRoundedCornerBitmap(bmp,50));
	        

	        return itemLayout;
	    }


}
