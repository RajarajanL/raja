package com.ps.jinja.adapters;

import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.ps.jinja.MagListItem;
import com.ps.jinja.R;
import com.ps.jinja.utils.ImageHelper;

public class MagazineGridAdap extends BaseAdapter {
	private List<MagListItem> items;
    private Context context;
    private int numItems = 0;
    public MagazineGridAdap(final List<MagListItem> items, Context context) {
        this.items = items;
        this.context = context;
        this.numItems = items.size();
    }
@Override
public int getCount() {
	// TODO Auto-generated method stub
	return numItems;
}
@Override
public MagListItem getItem(int position) {
    return items.get(position);
}
@Override
public long getItemId(int position) {
	// TODO Auto-generated method stub
	return 0;
}

@Override
public View getView(int position, View convertView, ViewGroup parent) {
       
    // Get the current list item
    final MagListItem item = items.get(position);
    // Get the layout for the list item
    final RelativeLayout itemLayout = (RelativeLayout) LayoutInflater.from(context).inflate(R.layout.preparing_magazine_title_grid_data, parent, false);
    // Set the icon as defined in our list item
   
 
    // Set the text label as defined in our list item
    TextView txtLabel = (TextView) itemLayout.findViewById(R.id.magazine_grid_title_tv);
    txtLabel.setText(item.getcTitle());
    ImageView txtImage=(ImageView) itemLayout.findViewById(R.id.magazine_grid_imageview);
    
    ImageHelper.loadImage(txtImage, item.getcImage(), true, false, 30);
        	
    return itemLayout;
}

}


