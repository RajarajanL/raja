package com.ps.jinja.adapters;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.ps.jinja.ClassfiedSubCatListItem;
import com.ps.jinja.R;
import com.ps.jinja.utils.ImageHelper;

public class ClassSubCatListAdaAdapter extends BaseAdapter {
	private List<ClassfiedSubCatListItem> items;
	private Context context;
	private int numItems = 0;

	public ClassSubCatListAdaAdapter(List<ClassfiedSubCatListItem> items, Context context) {
		this.items = items;
		this.context = context;
		this.numItems = items.size();
	}

	@Override
	public int getCount() {
		return numItems;
	}

	@Override
	public Object getItem(int position) {
		return items.get(position);
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		// Get the current list item
		final ClassfiedSubCatListItem item = items.get(position);
		// Get the layout for the list item
		final RelativeLayout itemLayout = (RelativeLayout) LayoutInflater.from(
				context).inflate(R.layout.clas_sub_cat_list_list_adapter, parent, false);
		TextView txtTitle = (TextView) itemLayout
				.findViewById(R.id.class_sub_list_list_adpter_title_tv);
		txtTitle.setText(item.getcTitle());
		TextView txtAdress = (TextView) itemLayout
				.findViewById(R.id.class_sub_list_list_adpter_address_tv);
		txtAdress.setText(item.getcAddress());
		TextView txtPrice = (TextView) itemLayout
				.findViewById(R.id.class_sub_list_list_adpter_price_tv);
		txtPrice.setText("Cost:$"+item.getcPrice()+"|"+item.getcPostDate());
		ImageView txtImage=(ImageView) itemLayout.findViewById(R.id.class_sub_list_list_adpter_imageview);
		ImageHelper.loadImage(txtImage, item.getcImage(), true, true, 30);

		return itemLayout;
	}

}

