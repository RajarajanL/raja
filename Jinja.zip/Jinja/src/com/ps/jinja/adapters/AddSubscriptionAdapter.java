package com.ps.jinja.adapters;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.CompoundButton.OnCheckedChangeListener;

import com.ps.jinja.CatListItem;
import com.ps.jinja.R;
import com.ps.jinja.SubscriptionItems;

public class AddSubscriptionAdapter<T> extends BaseAdapter {
	private List<SubscriptionItems> items;
	ArrayList<T> mList;
	private Context context;
	private int numItems = 0;
	SparseBooleanArray mSparseBooleanArray;
	LayoutInflater mInflater;

	public AddSubscriptionAdapter(List<SubscriptionItems> items, Context context) {
		this.items = items;
		this.context = context;
		this.numItems = items.size();
		mSparseBooleanArray = new SparseBooleanArray();
	}

	public List<SubscriptionItems> getCheckedItems() {
		List<SubscriptionItems> mTempArry = new ArrayList<SubscriptionItems>();
		for (int i = 0; i < items.size(); i++) {
			if (mSparseBooleanArray.get(i)) {
				mTempArry.add(items.get(i));
			}
		}
		return mTempArry;
	}

	@Override
	public int getCount() {
		return items.size();
	}

	@Override
	public Object getItem(int position) {
		return items.get(position);
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		// Get the current list item
		final SubscriptionItems item = items.get(position);
		final LinearLayout itemLayout = (LinearLayout) LayoutInflater.from(
				context).inflate(R.layout.subscription_row, parent, false);
		TextView tvTitle = (TextView) itemLayout
				.findViewById(R.id.subscription_row_title_tv);
		tvTitle.setText(item.getcTitle());
		CheckBox cBox = (CheckBox) itemLayout
				.findViewById(R.id.subscription_row_checkbox);
		cBox.setTag(position);
		cBox.setChecked(item.getiSelected());
		// cBox.setTag(position);
		// cBox.setChecked(mSparseBooleanArray.get(position));
		mSparseBooleanArray.put(position, item.getiSelected());
		cBox.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {
				// TODO Auto-generated method stub
				mSparseBooleanArray.put((Integer) buttonView.getTag(),
						isChecked);
			}
		});
		return itemLayout;
	}

}