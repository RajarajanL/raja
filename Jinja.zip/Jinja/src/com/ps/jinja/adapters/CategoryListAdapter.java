package com.ps.jinja.adapters;

import java.util.List;

import com.ps.jinja.CatListItem;
import com.ps.jinja.R;


import android.content.Context;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class CategoryListAdapter extends BaseAdapter {

	private List<CatListItem> items;
	private Context context;
	private int numItems = 0;

	public CategoryListAdapter(List<CatListItem> items, Context context) {
		this.items = items;
		this.context = context;
		this.numItems = items.size();
	}

	@Override
	public int getCount() {
		return numItems;
	}

	@Override
	public Object getItem(int position) {
		return items.get(position);
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		// Get the current list item
		final CatListItem item = items.get(position);
		// Get the layout for the list item
		final RelativeLayout itemLayout = (RelativeLayout) LayoutInflater.from(
				context).inflate(R.layout.sub_cat_list_adapter, parent, false);
		TextView txtTitle = (TextView) itemLayout
				.findViewById(R.id.sub_list_adap_tv);
		txtTitle.setText(item.getcTitle());

		return itemLayout;
	}
}
