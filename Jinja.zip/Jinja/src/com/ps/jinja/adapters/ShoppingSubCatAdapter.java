package com.ps.jinja.adapters;

import java.util.List;

import com.ps.jinja.R;
import com.ps.jinja.listItems.ShoppingSubCatListItem;
import com.ps.jinja.utils.ImageHelper;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class ShoppingSubCatAdapter extends BaseAdapter {
	
	private List<ShoppingSubCatListItem> items;
	private Context context;
	private int numItems = 0;

	public ShoppingSubCatAdapter(List<ShoppingSubCatListItem> items, Context context) {
		this.items = items;
		this.context = context;
		this.numItems = items.size();
	}

	@Override
	public int getCount() {
		return numItems;
	}

	@Override
	public Object getItem(int position) {
		return items.get(position);
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		// Get the current list item
		final ShoppingSubCatListItem item = items.get(position);
		// Get the layout for the list item
		final RelativeLayout itemLayout = (RelativeLayout) LayoutInflater.from(
				context).inflate(R.layout.shop_sub_category_adapter, parent, false);
		TextView txtTitle = (TextView) itemLayout
				.findViewById(R.id.shop_sub_cat_adap_title_tv);
		txtTitle.setText(item.getsSubTitle());
		ImageView txtImage=(ImageView) itemLayout.findViewById(R.id.shop_sub_cat_adap_image_imv);
		ImageHelper.loadImage(txtImage, item.getsSubImage(), true, true, 30);

		return itemLayout;
	}

}
