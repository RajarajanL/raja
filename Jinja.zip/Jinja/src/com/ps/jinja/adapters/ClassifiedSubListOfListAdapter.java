package com.ps.jinja.adapters;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.ps.jinja.R;
import com.ps.jinja.listItems.ClassifiedSubCatListItem;
import com.ps.jinja.utils.ImageHelper;

public class ClassifiedSubListOfListAdapter extends BaseAdapter {
	private List<ClassifiedSubCatListItem> items;
	private Context context;
	private int numItems=0;
	public ClassifiedSubListOfListAdapter(List<ClassifiedSubCatListItem> items,Context context)
	{
		this.items = items;
        this.context = context;
        this.numItems = items.size();
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return numItems;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return items.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	 @Override
	public View getView(int position, View convertView, ViewGroup parent) {
	       
	        final ClassifiedSubCatListItem item = items.get(position);
	        final RelativeLayout itemLayout = (RelativeLayout) LayoutInflater.from(context).inflate(R.layout.classified_subcat_list_adapter_for_categories, parent, false);
	      
	        TextView txtTitle = (TextView) itemLayout.findViewById(R.id.classified_subcat_adapter_name_tv);
	        txtTitle.setText(item.getcTitle());
	        ImageView txtImage=(ImageView) itemLayout.findViewById(R.id.classified_subcat_adapter_image_imv);
	        ImageHelper.loadImage(txtImage, item.getcPicture(), true, true, 30);
	       
	        

	        return itemLayout;
	    }

}
