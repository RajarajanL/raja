package com.ps.jinja.listItems;

public class ShoppingSubCatListItem {
	private String sSubTitle;
    private int sSubId;
    private String sSubImage;
    
    public ShoppingSubCatListItem(int sSubid,String sSubtitle,String sSubimage)
    {
    	sSubId=sSubid;
    	sSubTitle=sSubtitle;
    	sSubImage=sSubimage;
    	
    }

	public String getsSubTitle() {
		return sSubTitle;
	}

	public void setsSubTitle(String sSubTitle) {
		this.sSubTitle = sSubTitle;
	}

	public int getsSubId() {
		return sSubId;
	}

	public void setsSubId(int sSubId) {
		this.sSubId = sSubId;
	}

	public String getsSubImage() {
		return sSubImage;
	}

	public void setsSubImage(String sSubImage) {
		this.sSubImage = sSubImage;
	}
}
