package com.ps.jinja.listItems;

public class ClassifiedSubCatListItem {
	private String cTitle;
    private int cId;
    private String cPicture;
    public ClassifiedSubCatListItem(int cid,String ctitle,String cpicture)
    {
    	cId=cid;
    	cTitle=ctitle;
    	cPicture=cpicture;
    }
    public int getcId() {
        return cId;
    }
    public String getcTitle() {
        return cTitle;
    }
    public String getcPicture(){
    	return cPicture;
    }

}
