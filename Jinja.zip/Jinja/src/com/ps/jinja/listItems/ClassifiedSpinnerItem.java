package com.ps.jinja.listItems;

public class ClassifiedSpinnerItem {
	private String classifiedTitle;
    private int classifiedId;
    public ClassifiedSpinnerItem(int cid,String ctitle)
    {
    	classifiedId=cid;
    	classifiedTitle=ctitle;
    }
    public int getclassifiedId() {
        return classifiedId;
    }
    public String getclassifiedTitle() {
        return classifiedTitle;
    }

}
