package com.ps.jinja.listItems;

public class CartListItem {
	
    private int cartId;
    private int cPrice;
    private int cProductId;
    private int cCount;
    
    public CartListItem(int cartid,int cprice,int cproductid,int ccount)
    {
    	cartId=cartid;
    	cPrice=cprice;
    	cCount=ccount;
    	cProductId=cproductid;
    	
    	
     	
    
    	
    }

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public int getcPrice() {
		return cPrice;
	}

	public void setcPrice(int cPrice) {
		this.cPrice = cPrice;
	}

	public int getcProductId() {
		return cProductId;
	}

	public void setcProductId(int cProductId) {
		this.cProductId = cProductId;
	}

	public int getcCount() {
		return cCount;
	}

	public void setcCount(int cCount) {
		this.cCount = cCount;
	}
}
