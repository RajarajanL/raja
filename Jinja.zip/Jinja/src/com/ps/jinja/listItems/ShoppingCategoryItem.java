package com.ps.jinja.listItems;

public class ShoppingCategoryItem {
	private String sTitle;
    private int sId;
    private String sPicture;
    public ShoppingCategoryItem(int sid,String stitle,String spicture)
    {
    	sId=sid;
    	sTitle=stitle;
    	sPicture=spicture;
    }
    public int getsId() {
        return sId;
    }
    public String getsTitle() {
        return sTitle;
    }
    public String getsPicture(){
    	return sPicture;
    }

}
