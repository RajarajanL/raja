package com.ps.jinja.listItems;

public class ProductsListItem {
	private String pTitle;
    private int pId;
    private String pImage;
    private int pCatId;
    private int pStatus;
    private int pPrice;
    
    public ProductsListItem(int pid,String ptitle,String pimage,int pcatid,int pstatus,int pprice)
    {
    	pId=pid;
    	pTitle=ptitle;
    	pImage=pimage;
    	pCatId=pcatid;
    	pStatus=pstatus;
    	pPrice=pprice;
    	
    }

	public String getpTitle() {
		return pTitle;
	}

	public void setpTitle(String pTitle) {
		this.pTitle = pTitle;
	}

	public int getpId() {
		return pId;
	}

	public void setpId(int pId) {
		this.pId = pId;
	}

	public String getpImage() {
		return pImage;
	}

	public void setpImage(String pImage) {
		this.pImage = pImage;
	}

	public int getpCatId() {
		return pCatId;
	}

	public void setpCatId(int pCatId) {
		this.pCatId = pCatId;
	}

	public int getpStatus() {
		return pStatus;
	}

	public void setpStatus(int pStatus) {
		this.pStatus = pStatus;
	}

	public int getpPrice() {
		return pPrice;
	}

	public void setpPrice(int pPrice) {
		this.pPrice = pPrice;
	}

}
