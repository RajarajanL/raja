package com.ps.jinja.listItems;

public class ClassifiedListItem {
	private String cTitle;
    private int cId;
    private String cPicture;
    public ClassifiedListItem(int cid,String ctitle,String cpicture)
    {
    	cId=cid;
    	cTitle=ctitle;
    	cPicture=cpicture;
    }
    public int getcId() {
        return cId;
    }
    public String getcTitle() {
        return cTitle;
    }
    public String getcPicture(){
    	return cPicture;
    }

}
