package com.ps.jinja.listItems;

public class ClassfiedSubCatItem {
	private String cTitle;
    private int cId;
    private String cImage;
    
    public ClassfiedSubCatItem(int cid,String ctitle,String cimage)
    {
    	cId=cid;
     	cTitle=ctitle;
     	cImage=cimage;
    	
    }
    public int getcId() {
        return cId;
    }
  
    public String getcTitle() {
        return cTitle;
    }
    public String getcImage() {
        return cImage;
    }
    
    

}
