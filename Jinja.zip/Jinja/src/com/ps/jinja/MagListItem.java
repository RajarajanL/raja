package com.ps.jinja;

public class MagListItem {
	private String cTitle;
    private String cImage;
    private int cEid;
    
    public MagListItem(String cimage,String ctitle,int ceid)
    {
    	cImage=cimage;
     	cTitle=ctitle;
    	cEid=ceid;
    }
    public String getcImage() {
        return cImage;
    }
  
    public String getcTitle() {
        return cTitle;
    }
    public int getcEid() {
        return cEid;
    }
    

}
