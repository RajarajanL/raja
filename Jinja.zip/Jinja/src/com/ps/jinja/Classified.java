package com.ps.jinja;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;

import com.ps.jinja.AsynTask.ClassifiedAsyncTaskLoader;
import com.ps.jinja.adapters.ClassifiedListAdapter;
import com.ps.jinja.constants.URLConstants;
import com.ps.jinja.listItems.ClassifiedListItem;
import com.ps.jinja.session.SessionHandler;
import com.ps.jinja.utils.ImageHelper;
import com.ps.jinja.vo.UserVO;

public class Classified extends Activity{
	GridView classifiedGrid;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.classifieds);
		TextView userNameTxt=(TextView) findViewById(R.id.classified_user_name_tv);
		ImageView userImageView=(ImageView) findViewById(R.id.classified_user_imv);
		classifiedGrid=(GridView) findViewById(R.id.classified_grid_view);
		ImageView menuView=(ImageView) findViewById(R.id.classified_option_imv);
		ImageView backImage=(ImageView) findViewById(R.id.classified_logo_imv);
		backImage.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
				
			}
		});
		UserVO userVo=SessionHandler.get().getUserVO();
		
		
		try {
			if(null!=userVo)
			{
			userNameTxt.setText(userVo.getfName()+" "+userVo.getlName());
		String userImage=userVo.getImageUrl();
		
		Log.i(userImage, "image");

		
		URL url = new URL(userImage);
	
		Bitmap bmp = BitmapFactory.decodeStream(url.openConnection()
				.getInputStream());
		Bitmap finalImg = ImageHelper.getRoundedCornerBitmap(bmp, 10);
		userImageView.setImageBitmap(finalImg);
	}else{
		userNameTxt.setText("Guest");				
		URL url = new URL(URLConstants.GUEST_IMAGE);
		Bitmap bmp = BitmapFactory.decodeStream(url.openConnection()
				.getInputStream());
		Bitmap finalImg = ImageHelper.getRoundedCornerBitmap(bmp, 10);
		userImageView.setImageBitmap(finalImg);
	}
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			menuView.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent menuIntent=new Intent(Classified.this, MenuOption.class);
					startActivity(menuIntent);
					
				}
			});
			ClassifiedAsyncTaskLoader runner=new ClassifiedAsyncTaskLoader(this);
			runner.execute();

	}

	public void loadClassifiedCategory(String jsonResult) {
		// TODO Auto-generated method stub
		try{
			 if(jsonResult==null){
				 return;
			 }
			 JSONArray classifiedJsonArray=new JSONArray(jsonResult);
			 final List<ClassifiedListItem> classifiedList=new ArrayList<ClassifiedListItem>();
			 for(int i=0;i<classifiedJsonArray.length();i++){
				 JSONObject classifiedJsonObject=(JSONObject) classifiedJsonArray.get(i);
				 int classifiedId=classifiedJsonObject.getInt("category_id");
				 String classifiedName=classifiedJsonObject.getString("category_name");
				 String classifiedImage=classifiedJsonObject.getString("image_url");
				 Log.i(classifiedImage, "Null Or Not Null");
				 if(classifiedImage==null || classifiedImage.equals("null")){
					 String alterImageId="http://img2.wikia.nocookie.net/__cb20120417110152/hunterxhunter/images/6/6d/No_image.png";
					 classifiedList.add(new ClassifiedListItem(classifiedId, classifiedName, alterImageId));
				 }else{
					 Log.i(classifiedImage, "Else");
					 classifiedList.add(new ClassifiedListItem(classifiedId, classifiedName, classifiedImage)); 
				 }
			 }
			 ListAdapter classAdapter=new ClassifiedListAdapter(classifiedList,this);
			 classifiedGrid.setAdapter(classAdapter);
			 classifiedGrid.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1,
						int position, long arg3) {
					// TODO Auto-generated method stub
					ClassifiedListItem item=classifiedList.get(position);
					Intent newIntent=new Intent(Classified.this, ClassifiedSubCategories.class);
					int sendId=item.getcId();
					String sentTitle=item.getcTitle();
					newIntent.putExtra("sendId", sendId);
					newIntent.putExtra("sentTitle", sentTitle);
					startActivity(newIntent);
					
				}
			});
			
			} 
		 catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
}
