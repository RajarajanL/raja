package com.ps.jinja;

import android.app.Activity;
import android.os.Bundle;

public class Example extends Activity{
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.example);
		String getimage=getIntent().getStringExtra("imageUrl");
		
	}

}
