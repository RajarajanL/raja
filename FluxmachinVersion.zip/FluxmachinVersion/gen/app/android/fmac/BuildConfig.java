/** Automatically generated file. DO NOT MODIFY */
package app.android.fmac;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}