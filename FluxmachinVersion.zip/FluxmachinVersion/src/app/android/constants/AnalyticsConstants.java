package app.android.constants;

public class AnalyticsConstants {
	public static final String BOARDS_ANALYTIC = "BoardScreen";
	public static final String UNITS_ANALYTIC = "UnitsScreen";
	public static final String TEST_ANALYTIC = "TestScreen";
	public static final String SUBJECTS_ANALYTIC = "SubjectsScreen";
	public static final String RESULTS_ANALYTIC = "ResultScreen";
	public static final String LOGIN_ANALYTIC = "LoginScreen";
}
