package app.android.fmac.session;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import app.android.fmac.vo.UserVO;

public class SessionHandler {
	private static SessionHandler singleton = new SessionHandler();
	private static UserVO userVO;

	private SessionHandler() {

	}

	public static SessionHandler get() {
		return singleton;
	}

	public void setUserVO(UserVO userVO, SharedPreferences sharedpreferences) {
		SessionHandler.userVO = userVO;
		Editor editor = sharedpreferences.edit();
		editor.putInt("user_id", userVO.getUserId());
		editor.putString("user_mail", userVO.getEmail());
		editor.putString("user_fname", userVO.getfName());
		editor.putString("user_lname", userVO.getlName());
		editor.putString("user_image", userVO.getImageUrl());

		editor.commit();

	}

	public UserVO getUserVO() {
		return SessionHandler.userVO;
	}

	public void removeUser(SharedPreferences sharedpreferences) {
		Editor editor = sharedpreferences.edit();
		editor.remove("user_id");
		editor.remove("user_mail");
		editor.remove("user_fname");
		editor.remove("user_lname");
		editor.remove("user_image");
		editor.commit();
		SessionHandler.userVO = null;
	}

	public Boolean hasSession(SharedPreferences sharedpreferences) {
		if (userVO != null) {
			return true;
		}
		if (sharedpreferences.contains("user_id")) {
			int userId = sharedpreferences.getInt("user_id", 0);
			String fName = sharedpreferences.getString("user_fname", "");
			String lName = sharedpreferences.getString("user_lname", "");
			String email = sharedpreferences.getString("user_mail", "");
			String imageUrl = sharedpreferences.getString("user_image", "");

			userVO = new UserVO(userId, fName, lName, email, imageUrl);

			return true;
		}

		return false;
	}
}
