package app.android.fmac;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.ActionBar.LayoutParams;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import app.android.constants.AnalyticsConstants;
import app.android.constants.Constans;
import app.android.fmac.adapters.UnitsListViewAdapter;
import app.android.fmac.items.UnitsItem;
import app.android.fmac.utils.ApiHelper;
import app.android.fmac.utils.DetectNetworkConnection;

@SuppressLint("ResourceAsColor")
public class UnitFluxMachineNew extends Activity {
	GridView list;
	String unitsComma = " ";
	String unitIds = "";
	int getSubId;
	UnitsListViewAdapter unitsAdapter;
	List<UnitsItem> unitItem = new ArrayList<UnitsItem>();
	HashSet<String> unit = new HashSet<String>();
	int unitIdSend;
	String sendSlug, sentTitle;
	Button b;
	ScrollView scrollview;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.units_fluxmachine);
		FluxmachineApplication application = (FluxmachineApplication) getApplication();
		application.trackScreen(AnalyticsConstants.UNITS_ANALYTIC);
		sentTitle = getIntent().getExtras().getString("sentTitle");
		sendSlug = getIntent().getExtras().getString("sendSlug");
		getSubId = getIntent().getExtras().getInt("subjectId");
		String getSubName = getIntent().getExtras().getString("subjectName");
		TextView titleUnit = (TextView) findViewById(R.id.units_flux_title_tv);
		titleUnit.setText(getSubName);
		ImageView menuImage = (ImageView) findViewById(R.id.units_flux_menu_imv);
		menuImage.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent newIntent = new Intent(getApplicationContext(),
						FluxmachineMenu.class);
				startActivity(newIntent);
			}
		});
		ImageView backimage = (ImageView) findViewById(R.id.units_flux_back_imv);
		backimage.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (DetectNetworkConnection
						.checkInternetConnection(UnitFluxMachineNew.this)) {
					finish();
				} else {
					Toast.makeText(getApplicationContext(),
							"Please check your Internet Connection",
							Toast.LENGTH_LONG).show();
				}

			}
		});
		Button startBtn = (Button) findViewById(R.id.units_flux_units_start_btn);
		try {
			String unitString = ApiHelper
					.getHttpResponseAsString(Constans.GET_UNITS
							+ "&sub_link_id=" + getSubId);
			JSONArray unitsJsonArray = new JSONArray(unitString);

			for (int i = 0; i < unitsJsonArray.length(); i++) {
				JSONObject catJOBj = (JSONObject) unitsJsonArray.get(i);
				int unitId = catJOBj.getInt("unit_id");
				String unitName = catJOBj.getString("unit_name");
				unitItem.add(new UnitsItem(unitId, unitName));
			}

		} catch (JSONException e) {
			e.printStackTrace();
		}

		scrollview = (ScrollView) findViewById(R.id.unit_flux_scroll_sv);
		// scrollview = new ScrollView(this);
		LinearLayout linearlayout = new LinearLayout(this);
		linearlayout.setOrientation(LinearLayout.VERTICAL);
		scrollview.addView(linearlayout);

		for (int i = 0; i < unitItem.size(); i++) {
			UnitsItem item = unitItem.get(i);
			LinearLayout linear1 = new LinearLayout(this);
			linear1.setOrientation(LinearLayout.HORIZONTAL);

			linearlayout.addView(linear1);
			LinearLayout.LayoutParams btnParam = new LinearLayout.LayoutParams(
					LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
			btnParam.setMargins(5, 8, 5, 8);
			b = new Button(this);
			b.setText("" + item.getunitTitle());
			b.setTag("unit_id_btn_" + String.valueOf(item.getunitId()));
			b.setTextSize(10);
			b.setPadding(8, 3, 8, 3);
			b.setBackgroundResource(android.R.drawable.btn_default);
			b.setTypeface(Typeface.SERIF, Typeface.BOLD_ITALIC);
			/*
			 * b.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
			 * LayoutParams.WRAP_CONTENT));
			 */
			b.setLayoutParams(btnParam);

			linear1.addView(b);

			b.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					String replace = String.valueOf(v.getTag()).replace(
							"unit_id_btn_", "");
					if (unit.contains(replace)) {
						unit.remove(replace);
						v.setBackgroundResource(android.R.drawable.btn_default);
					} else {
						unit.add(replace);
						v.setBackgroundResource(R.drawable.highlight);
					}
					// for (String s : unit) {
					// // if (!unitIds.equals("")) {
					// // unitIds += ",";
					// // } else {
					// // unitIds += s;
					// // }
					//
					// unitIds += (unitIds.equals("") ? "" : ",") + s;
					//
					// }
					// Log.i(String.valueOf(unit), "Hash Set valus");

				}
			});
		}
		for (String s : unit) {
			// if (!unitIds.equals("")) {
			// unitIds += ",";
			// } else {
			// unitIds += s;
			// }

			unitIds += (unitIds.equals("") ? "" : ",") + s;

		}

		startBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				for (String s : unit) {
					// if (!unitIds.equals("")) {
					// unitIds += ",";
					// } else {
					// unitIds += s;
					// }

					unitIds += (unitIds.equals("") ? "" : ",") + s;

				}
				// Log.i(String.valueOf(unitIds), "Unit Id");

				Intent newIntent = new Intent(getApplicationContext(),
						TestPageFluxmachine.class);
				newIntent.putExtra("sendSlug", sendSlug);
				newIntent.putExtra("unitIds", unitIds);
				newIntent.putExtra("getSubId", getSubId);
				newIntent.putExtra("sentTitle", sentTitle);
				// Log.i(sentTitle, "Board Title in Units Fluxmachine");
				if (DetectNetworkConnection
						.checkInternetConnection(UnitFluxMachineNew.this)) {
					startActivity(newIntent);
				} else {
					Toast.makeText(getApplicationContext(),
							"Please check your Internet Connection",
							Toast.LENGTH_LONG).show();
				}

			}
		});
		// list = (GridView) findViewById(R.id.units_flux_units_grid_gv);
		// unitsAdapter = new UnitsListViewAdapter(this,
		// R.layout.unit_listview_item, unitItem);
		//
		// list.setAdapter(unitsAdapter);
		// list.setOnItemClickListener(new OnItemClickListener() {
		//
		// @Override
		// public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
		// long arg3) {
		// TextView unitIdName = (TextView) arg1
		// .findViewById(R.id.unit__idname_tv);
		// unitIdName.getText().toString();
		// Intent newIntent = new Intent(getApplicationContext(),
		// TestPageFluxmachine.class);
		// newIntent.putExtra("sendSlug", sendSlug);
		// newIntent.putExtra("unitIds", unitIdName.getText().toString());
		// newIntent.putExtra("getSubId", getSubId);
		// newIntent.putExtra("sentTitle", sentTitle);
		// Log.i(sentTitle, "Board Title in Units Fluxmachine");
		// if (DetectNetworkConnection
		// .checkInternetConnection(UnitFluxMachineNew.this)) {
		// startActivity(newIntent);
		// } else {
		// Toast.makeText(getApplicationContext(),
		// "Please check your Internet Connection",
		// Toast.LENGTH_LONG).show();
		// }
		//
		// }
		// });

	}

	@Override
	public void onBackPressed() {
		finish();

	}
}
