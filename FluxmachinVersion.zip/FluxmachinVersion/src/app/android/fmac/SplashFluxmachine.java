package app.android.fmac;

import java.io.File;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import app.android.fmac.session.SessionHandler;
import app.android.fmac.utils.DetectNetworkConnection;

import com.nostra13.universalimageloader.cache.disc.impl.UnlimitedDiscCache;
import com.nostra13.universalimageloader.cache.disc.naming.HashCodeFileNameGenerator;
import com.nostra13.universalimageloader.cache.memory.impl.LruMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;
import com.nostra13.universalimageloader.core.decode.BaseImageDecoder;
import com.nostra13.universalimageloader.core.download.BaseImageDownloader;
import com.nostra13.universalimageloader.utils.StorageUtils;

public class SplashFluxmachine extends Activity {
	private static final int TIME = 4 * 1000;
	Animation animFadein;
	TextView fluxSplash;
	public static final String My_USER_DATA = "my_user_data";
	SharedPreferences sharedpreferences;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		sharedpreferences = getSharedPreferences(My_USER_DATA,
				Context.MODE_PRIVATE);
		super.onCreate(savedInstanceState);

		DisplayImageOptions options = new DisplayImageOptions.Builder()
				.cacheInMemory(true).cacheOnDisk(true).build();
		Context context = getApplicationContext();
		File cacheDir = StorageUtils.getCacheDirectory(context);

		ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(
				context).memoryCacheExtraOptions(480, 800)
				.diskCacheExtraOptions(480, 800, null).threadPoolSize(3)
				.threadPriority(Thread.NORM_PRIORITY - 1)
				.tasksProcessingOrder(QueueProcessingType.FIFO)
				.denyCacheImageMultipleSizesInMemory()
				.memoryCache(new LruMemoryCache(2 * 1024 * 1024))
				.memoryCacheSize(2 * 1024 * 1024).memoryCacheSizePercentage(13)
				.diskCache(new UnlimitedDiscCache(cacheDir))
				.diskCacheSize(50 * 1024 * 1024).diskCacheFileCount(100)
				.diskCacheFileNameGenerator(new HashCodeFileNameGenerator())
				.imageDownloader(new BaseImageDownloader(context))
				.imageDecoder(new BaseImageDecoder(false))
				.defaultDisplayImageOptions(options).writeDebugLogs().build();
		ImageLoader.getInstance().init(config);

		if (SessionHandler.get().hasSession(sharedpreferences)) {
			if (DetectNetworkConnection
					.checkInternetConnection(SplashFluxmachine.this)) {
				Intent homeActivity = new Intent(getApplicationContext(),
						BoardsFluxmachine.class);
				startActivity(homeActivity);
			} else {

				AlertDialog.Builder builder = new AlertDialog.Builder(this);
				builder.setMessage(
						"Looks like you do not have connectivity. Turn on your internet connection")
						.setPositiveButton("Ok", dialogClickListener)
						.setNegativeButton("Cancel", dialogClickListener)
						.show();

			}

		} else {

			setContentView(R.layout.splash_fluxmachine);

			fluxSplash = (TextView) findViewById(R.id.splash_flux_tv);

			animFadein = AnimationUtils.loadAnimation(getApplicationContext(),
					R.anim.blink);
			fluxSplash.setAnimation(animFadein);

			new Handler().postDelayed(new Runnable() {
				@Override
				public void run() {
					Intent intent = new Intent(SplashFluxmachine.this,
							FluxmachineMainActivity.class);
					startActivity(intent);
					SplashFluxmachine.this.finish();
					overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
				}
			}, TIME);
			new Handler().postDelayed(new Runnable() {
				@Override
				public void run() {

				}
			}, TIME);
		}
	}

	DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {

		@Override
		public void onClick(DialogInterface dialog, int which) {
			switch (which) {
			case DialogInterface.BUTTON_POSITIVE:
				// Yes button clicked
				startActivity(new Intent(
						android.provider.Settings.ACTION_WIRELESS_SETTINGS));
				Intent intent = new Intent(Intent.ACTION_MAIN);
				intent.addCategory(Intent.CATEGORY_HOME);
				intent.setFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);

				startActivity(intent);

				break;

			case DialogInterface.BUTTON_NEGATIVE:
				Intent intentq = new Intent(Intent.ACTION_MAIN);
				intentq.addCategory(Intent.CATEGORY_HOME);
				intentq.setFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);

				startActivity(intentq);
				break;
			}
		}
	};

	@Override
	public void onBackPressed() {
		this.finish();
		super.onBackPressed();
	}
}
