package app.android.fmac;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import app.android.constants.AnalyticsConstants;
import app.android.constants.Constans;
import app.android.fmac.adapters.UnitsSubscribedAdapter;
import app.android.fmac.items.SubscribeUnitItems;

public class UnitsFluxmachine extends Activity implements OnClickListener {
	Button startBtn;
	ImageView unitsBack, unitsMenu;
	GridView unitsGrid;
	ArrayAdapter<String> adapter;
	UnitsSubscribedAdapter<SubscribeUnitItems> unitsAdapter;
	String[] units = new String[] { "Quantitative Aptitude",
			"Logical Reasoning", "Verbal Ability", "Verbal Resoning",
			"Quantitative Aptitude", "Logical Reasoning", "Verbal Ability",
			"Verbal Resoning", };
	ArrayList<SubscribeUnitItems> unitsArrayList;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@SuppressLint({ "NewApi", "InlinedApi" })
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.units_fluxmachine);
		FluxmachineApplication application = (FluxmachineApplication) getApplication();
		application.trackScreen(AnalyticsConstants.UNITS_ANALYTIC);
		startBtn = (Button) findViewById(R.id.units_flux_units_start_btn);
		// startBtn.setOnClickListener(this);
		unitsBack = (ImageView) findViewById(R.id.units_flux_back_imv);
		unitsBack.setOnClickListener(this);
		unitsMenu = (ImageView) findViewById(R.id.units_flux_menu_imv);
		unitsMenu.setOnClickListener(this);
		// unitsGrid = (GridView) findViewById(R.id.units_flux_units_grid_gv);

		// adapter = new ArrayAdapter<String>(this,
		// android.R.layout.simple_list_item_multiple_choice, units);
		// unitsGrid.setChoiceMode(GridView.CHOICE_MODE_MULTIPLE);
		// unitsGrid.setAdapter(adapter);
		try {
			JSONArray unitsJsonArray = new JSONArray(Constans.EXAMPLE_UNITS);
			unitsArrayList = new ArrayList<SubscribeUnitItems>();

			// @@@@@@@@@@@@@
			// String catIds=getIntent().getExtras().getString("commaValu");
			// String[] subArray = catIds.split(",");
			// HashSet<String> subsCatSet = new
			// HashSet<String>(Arrays.asList(subArray));
			for (int i = 0; i < unitsJsonArray.length(); i++) {
				JSONObject catJOBj = (JSONObject) unitsJsonArray.get(i);
				int unitId = catJOBj.getInt("unit_id");
				String unitName = catJOBj.getString("unit_name");
				boolean isSubscribed = false;
				unitsArrayList.add(new SubscribeUnitItems(unitId, unitName,
						isSubscribed));
			}
			unitsAdapter = new UnitsSubscribedAdapter(unitsArrayList, this);
			// unitsGrid.setChoiceMode(GridView.CHOICE_MODE_MULTIPLE);
			unitsGrid.setAdapter(unitsAdapter);

			startBtn.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					if (unitsAdapter != null) {

						List<SubscribeUnitItems> mArrayProducts = unitsAdapter
								.getCheckedItems();
						// Log.d(AddSubscription.class.getSimpleName(),
						// "Selected Items: " + mArrayProducts.toString());
						String addSub = "";
						Boolean is = false;
						for (SubscribeUnitItems si : mArrayProducts) {
							// Toast.makeText(getApplicationContext(),
							// si.getcTitle(), Toast.LENGTH_SHORT).show();
							if (is == false) {
								addSub += String.valueOf(si.getunitId());
								is = true;
							} else {
								addSub += "," + String.valueOf(si.getunitId());
							}
						}
						// Log.i(addSub, "Appended Id With comma");
						Intent intent = new Intent(getApplicationContext(),
								TestPageFluxmachine.class);
						startActivity(intent);

					}

				}
			});

			// @@@@@@@@
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@SuppressLint("NewApi")
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.units_flux_units_start_btn:

			// SparseBooleanArray checked = unitsGrid.getCheckedItemPositions();
			// ArrayList<String> selectedItems = new ArrayList<String>();
			// for (int i = 0; i < checked.size(); i++) {
			// // Item position in adapter
			// int position = checked.keyAt(i);
			// // Add sport if it is checked i.e.) == TRUE!
			// if (checked.valueAt(i))
			// selectedItems.add(adapter.getItem(position));
			// }
			//
			// String[] outputStrArr = new String[selectedItems.size()];
			//
			// for (int i = 0; i < selectedItems.size(); i++) {
			// outputStrArr[i] = selectedItems.get(i);
			// }
			//
			// Intent intent = new Intent(getApplicationContext(),
			// TestPageFluxmachine.class);
			//
			// // Create a bundle object
			// Bundle b = new Bundle();
			// b.putStringArray("selectedItems", outputStrArr);
			//
			// // Add the bundle to the intent.
			// intent.putExtras(b);
			//
			// // start the ResultActivity
			// startActivity(intent);

			break;
		case R.id.units_flux_back_imv:
			finish();
			break;
		case R.id.units_flux_menu_imv:

			break;

		default:
			break;
		}

	}
}
