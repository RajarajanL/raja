package app.android.fmac;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.widget.ImageView;

@SuppressLint("SetJavaScriptEnabled")
public class WebViewSignUp extends Activity {
	private WebView webView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.web_view_sign_in_flux);
		webView = (WebView) findViewById(R.id.web_view_sign_in_wv);
		webView.getSettings().setJavaScriptEnabled(true);
		webView.loadUrl("http://www.fluxmachine.com");
		ImageView backIna = (ImageView) findViewById(R.id.web_view_back_imv);
		backIna.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				finish();
			}
		});
	}

}
