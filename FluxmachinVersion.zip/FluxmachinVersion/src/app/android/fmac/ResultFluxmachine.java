package app.android.fmac;

import java.util.Date;
import java.util.List;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import app.android.constants.AnalyticsConstants;

import com.facebook.AppEventsLogger;
import com.facebook.FacebookAuthorizationException;
import com.facebook.FacebookOperationCanceledException;
import com.facebook.FacebookRequestError;
import com.facebook.Request;
import com.facebook.Response;
import com.facebook.Session;
import com.facebook.SessionState;
import com.facebook.UiLifecycleHelper;
import com.facebook.model.GraphObject;
import com.facebook.model.GraphPlace;
import com.facebook.model.GraphUser;
import com.facebook.widget.FacebookDialog;

public class ResultFluxmachine extends FragmentActivity implements
		OnClickListener {
	Button mainMenuBtn, playAgainBtn;

	ImageView statusUpdate;

	TextView scoretext, congratText;
	String getUnits;
	int getSubjectId;
	int highScore, score;
	String sendSlug, sentTitle;
	LinearLayout congratHigh;
	private PendingAction pendingAction = PendingAction.NONE;
	private boolean canPresentShareDialog;

	private static final String PERMISSION = "publish_actions";

	private final String PENDING_ACTION_BUNDLE_KEY = "app.android.fmac";

	private GraphUser user;

	private GraphPlace place;

	private List<GraphUser> tags;

	private enum PendingAction {
		NONE, POST_PHOTO, POST_STATUS_UPDATE
	}

	private UiLifecycleHelper uiHelper;

	private final Session.StatusCallback callback = new Session.StatusCallback() {
		@Override
		public void call(Session session, SessionState state,
				Exception exception) {
			onSessionStateChange(session, state, exception);
		}
	};

	private final FacebookDialog.Callback dialogCallback = new FacebookDialog.Callback() {
		@Override
		public void onError(FacebookDialog.PendingCall pendingCall,
				Exception error, Bundle data) {
			Log.d("HelloFacebook", String.format("Error: %s", error.toString()));
		}

		@Override
		public void onComplete(FacebookDialog.PendingCall pendingCall,
				Bundle data) {
			Log.d("HelloFacebook", "Success!");
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		uiHelper = new UiLifecycleHelper(this, callback);
		uiHelper.onCreate(savedInstanceState);
		if (savedInstanceState != null) {
			String name = savedInstanceState
					.getString(PENDING_ACTION_BUNDLE_KEY);
			pendingAction = PendingAction.valueOf(name);
		}
		setContentView(R.layout.result_flux);
		FluxmachineApplication application = (FluxmachineApplication) getApplication();
		application.trackScreen(AnalyticsConstants.RESULTS_ANALYTIC);

		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
				.permitAll().build();

		StrictMode.setThreadPolicy(policy);

		sentTitle = getIntent().getExtras().getString("sentTitle");
		sendSlug = getIntent().getExtras().getString("sendSlug");
		score = getIntent().getExtras().getInt("scoreResult");
		highScore = getIntent().getExtras().getInt("userHighScore");
		getSubjectId = getIntent().getExtras().getInt("subId");
		getUnits = getIntent().getExtras().getString("getUnits");
		mainMenuBtn = (Button) findViewById(R.id.result_flux_main_menu_btn);
		mainMenuBtn.setOnClickListener(this);
		playAgainBtn = (Button) findViewById(R.id.result_flux_play_again_btn);
		playAgainBtn.setOnClickListener(this);
		congratHigh = (LinearLayout) findViewById(R.id.congrats_lv);
		scoretext = (TextView) findViewById(R.id.score_text_tv);
		scoretext.setText("You Have Scored " + String.valueOf(score)
				+ " Points.");
		congratText = (TextView) findViewById(R.id.congrats_high_sc_tv);

		Animation anim = new AlphaAnimation(0.0f, 1.0f);
		anim.setDuration(500);
		anim.setStartOffset(20);
		anim.setRepeatMode(Animation.REVERSE);
		anim.setRepeatCount(Animation.INFINITE);
		congratText.startAnimation(anim);

		if (score > 2) {
			congratHigh.setVisibility(View.VISIBLE);
		}

		statusUpdate = (ImageView) findViewById(R.id.status_fb);
		if (hasFaceBook() == true) {
			statusUpdate.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {

					onClickPostStatusUpdate();
				}
			});
		} else {
			statusUpdate.setVisibility(View.GONE);
		}
		canPresentShareDialog = FacebookDialog.canPresentShareDialog(this,
				FacebookDialog.ShareDialogFeature.SHARE_DIALOG);
	}

	private boolean hasFaceBook() {
		try {
			@SuppressWarnings("unused")
			ApplicationInfo info = getPackageManager().getApplicationInfo(
					"com.facebook.katana", 0);
			return true;
		} catch (PackageManager.NameNotFoundException e) {
			return false;
		}
	}

	@Override
	protected void onResume() {
		super.onResume();
		uiHelper.onResume();

		AppEventsLogger.activateApp(this);

		updateUI();
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		uiHelper.onSaveInstanceState(outState);

		outState.putString(PENDING_ACTION_BUNDLE_KEY, pendingAction.name());
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		uiHelper.onActivityResult(requestCode, resultCode, data, dialogCallback);
	}

	@Override
	public void onPause() {
		super.onPause();
		uiHelper.onPause();

		AppEventsLogger.deactivateApp(this);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		uiHelper.onDestroy();
	}

	private void onSessionStateChange(Session session, SessionState state,
			Exception exception) {
		if (pendingAction != PendingAction.NONE
				&& (exception instanceof FacebookOperationCanceledException || exception instanceof FacebookAuthorizationException)) {
			new AlertDialog.Builder(ResultFluxmachine.this)
					.setTitle(R.string.cancelled)
					.setMessage(R.string.permission_not_granted)
					.setPositiveButton(R.string.ok, null).show();
			pendingAction = PendingAction.NONE;
		} else if (state == SessionState.OPENED_TOKEN_UPDATED) {
			handlePendingAction();
		}
		updateUI();
	}

	private void updateUI() {
		Session session = Session.getActiveSession();
		boolean enableButtons = (session != null && session.isOpened());

		statusUpdate.setEnabled(enableButtons || canPresentShareDialog);

		if (enableButtons && user != null) {
			// greeting.setText(getString(R.string.hello_user,
			// user.getFirstName()));
		} else {
			// greeting.setText(null);
		}
	}

	@SuppressWarnings("incomplete-switch")
	private void handlePendingAction() {
		PendingAction previouslyPendingAction = pendingAction;
		pendingAction = PendingAction.NONE;

		switch (previouslyPendingAction) {

		case POST_STATUS_UPDATE:
			postStatusUpdate();
			break;
		}
	}

	private interface GraphObjectWithId extends GraphObject {
		String getId();
	}

	private void showPublishResult(String message, GraphObject result,
			FacebookRequestError error) {
		String title = null;
		String alertMessage = null;
		if (error == null) {
			title = getString(R.string.success);
			String id = result.cast(GraphObjectWithId.class).getId();
			alertMessage = getString(R.string.successfully_posted_post,
					message, id);
		} else {
			title = getString(R.string.error);
			alertMessage = error.getErrorMessage();
		}

		new AlertDialog.Builder(this).setTitle(title).setMessage(alertMessage)
				.setPositiveButton(R.string.ok, null).show();
	}

	private void onClickPostStatusUpdate() {
		performPublish(PendingAction.POST_STATUS_UPDATE, canPresentShareDialog);

	}

	private FacebookDialog.ShareDialogBuilder createShareDialogBuilderForLink() {
		return new FacebookDialog.ShareDialogBuilder(this)
				.setName("User:" + highScore + "Score" + score)
				.setDescription("This User Have Score More Points")
				.setPicture("http://image.fluxmachine.com/images/logo.png")
				.setLink("http://www.fluxmachine.com/");
	}

	private void postStatusUpdate() {
		if (canPresentShareDialog) {
			FacebookDialog shareDialog = createShareDialogBuilderForLink()
					.build();
			uiHelper.trackPendingDialogCall(shareDialog.present());
		} else if (user != null && hasPublishPermission()) {
			final String message = getString(R.string.status_update,
					user.getFirstName(), (new Date().toString()));
			Request request = Request.newStatusUpdateRequest(
					Session.getActiveSession(), message, place, tags,
					new Request.Callback() {
						@Override
						public void onCompleted(Response response) {
							showPublishResult(message,
									response.getGraphObject(),
									response.getError());
						}
					});
			request.executeAsync();
		} else {
			pendingAction = PendingAction.POST_STATUS_UPDATE;
		}
	}

	private boolean hasPublishPermission() {
		Session session = Session.getActiveSession();
		return session != null
				&& session.getPermissions().contains("publish_actions");
	}

	private void performPublish(PendingAction action, boolean allowNoSession) {
		Session session = Session.getActiveSession();
		if (session != null) {
			pendingAction = action;
			if (hasPublishPermission()) {
				handlePendingAction();
				return;
			} else if (session.isOpened()) {
				session.requestNewPublishPermissions(new Session.NewPermissionsRequest(
						this, PERMISSION));
				return;
			}
		}

		if (allowNoSession) {
			pendingAction = action;
			handlePendingAction();
		}
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.result_flux_main_menu_btn:
			Intent mainMenuIntent = new Intent(ResultFluxmachine.this,
					SubjectsFluxmachine.class);
			mainMenuIntent.putExtra("sendSlug", sendSlug);
			mainMenuIntent.putExtra("sentTitle", sentTitle);
			startActivity(mainMenuIntent);

			break;
		case R.id.result_flux_play_again_btn:
			Intent newIntent = new Intent(ResultFluxmachine.this,
					TestPageFluxmachine.class);
			newIntent.putExtra("unitIds", getUnits);
			newIntent.putExtra("getSubId", getSubjectId);
			newIntent.putExtra("sentTitle", sentTitle);
			newIntent.putExtra("sendSlug", sendSlug);
			startActivity(newIntent);
			finish();
			break;

		default:
			break;
		}

	}

	@Override
	public void onBackPressed() {
		// UserVO userVO = SessionHandler.get().getUserVO();
		// if (userVO == null) {
		// super.onBackPressed();
		// } else {
		// Intent intent = new Intent(Intent.ACTION_MAIN);
		// intent.addCategory(Intent.CATEGORY_HOME);
		// intent.setFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
		//
		// startActivity(intent);
		//
		// }

	}

}
