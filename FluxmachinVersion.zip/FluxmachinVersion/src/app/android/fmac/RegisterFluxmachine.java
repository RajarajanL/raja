package app.android.fmac;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import app.android.constants.Constans;

public class RegisterFluxmachine extends Activity implements OnClickListener {
	EditText fname, lname, email, password, conpassword;
	Button registerBtn, cancel;
	HttpEntity resEntity;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.flux_register);
		fname = (EditText) findViewById(R.id.flux_register_fname_et);
		lname = (EditText) findViewById(R.id.flux_register_lname_et);
		email = (EditText) findViewById(R.id.flux_register_email_et);
		password = (EditText) findViewById(R.id.flux_register_pass_et);
		conpassword = (EditText) findViewById(R.id.flux_register_confirm_pass_et);
		registerBtn = (Button) findViewById(R.id.flux_register_rgister_btn);
		registerBtn.setOnClickListener(this);
		cancel = (Button) findViewById(R.id.flux_register_cancel_btn);
		cancel.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.flux_register_rgister_btn:
			final String fNAME = fname.getText().toString();
			final String lNAME = lname.getText().toString();
			final String eMAIL = email.getText().toString();
			final String passWORD = password.getText().toString();
			final String conPASSWORD = conpassword.getText().toString();
			if (passWORD != conPASSWORD) {
				conpassword.setHint("retype password");
			}
			if (fNAME == null || fNAME.equals("") || lNAME == null
					|| lNAME.equals("") || eMAIL == null || eMAIL.equals("")
					|| passWORD == null || passWORD.equals("")
					|| conPASSWORD == null || conPASSWORD.equals("")) {
				return;
			} else {
				uploadFile(fNAME, lNAME, eMAIL, passWORD);
			}
			// new Thread(new Runnable() {
			// @Override
			// public void run() {
			// uploadFile(fNAME, lNAME, eMAIL, passWORD);
			//
			// }
			//
			// }).start();
			break;
		case R.id.flux_register_cancel_btn:
			finish();

			break;
		default:
			break;
		}
	}

	private void uploadFile(String fNAME2, String lNAME2, String eMAIL2,
			String passWORD2) {
		// Log.i(Constans.REGISTER_USER + "&fname=" + fNAME2 + "&lname=" +
		// lNAME2
		// + "&su_email=" + eMAIL2 + "&su_password=" + passWORD2, "dfadf");
		HttpClient loginHttpclient = new DefaultHttpClient();

		HttpPost loginHttppost = new HttpPost(Constans.REGISTER_USER
				+ "&fname=" + fNAME2 + "&lname=" + lNAME2 + "&su_email="
				+ eMAIL2 + "&su_password=" + passWORD2);

		try {
			HttpResponse loginHttpResponse = loginHttpclient
					.execute(loginHttppost);
			String loginJsonResult = inputStreamToString(
					loginHttpResponse.getEntity().getContent()).toString();
			// JSONObject loginJObj = new JSONObject(loginJsonResult);
			// Integer status = loginJObj.getInt("status");
			// Integer status = 1;
			if (loginJsonResult.equals("1") || loginJsonResult == "1") {
				Toast.makeText(getApplicationContext(),
						"Please check the email and Activate ",
						Toast.LENGTH_SHORT).show();
			} else {
				Toast.makeText(getApplicationContext(), "NOt Registered",
						Toast.LENGTH_SHORT).show();
			}

		} catch (ClientProtocolException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

		// try {
		// HttpClient client = new DefaultHttpClient();
		// HttpPost post = new HttpPost(Constans.REGISTER_USER);
		// MultipartEntity reqEntity = new MultipartEntity();
		// reqEntity.addPart("fname", new StringBody(fNAME2));
		// reqEntity.addPart("lname", new StringBody(lNAME2));
		// reqEntity.addPart("email", new StringBody(eMAIL2));
		// reqEntity.addPart("password", new StringBody(passWORD2));
		// // reqEntity.addPart("conpassword", new StringBody(conPASSWORD2));
		// post.setEntity(reqEntity);
		//
		// HttpResponse response = client.execute(post);
		// resEntity = response.getEntity();
		// final String response_str = EntityUtils.toString(resEntity);
		// if (resEntity != null) {
		// Log.i("RESPONSE", response_str);
		// runOnUiThread(new Runnable() {
		// @Override
		// public void run() {
		// try {
		//
		// } catch (Exception e) {
		// e.printStackTrace();
		// Toast.makeText(getApplicationContext(),
		// "error:" + e.getMessage().toString(),
		// Toast.LENGTH_LONG).show();
		// }
		// }
		// });
		// } else {
		// Toast.makeText(getApplicationContext(), "error:",
		// Toast.LENGTH_LONG).show();
		// }
		// } catch (final Exception ex) {
		// runOnUiThread(new Runnable() {
		//
		// @Override
		// public void run() {
		// // TODO Auto-generated method stub
		// Toast.makeText(getApplicationContext(),
		// "dddd" + ex.getMessage().toString(),
		// Toast.LENGTH_LONG).show();
		//
		// }
		// });
		//
		// Log.e("Debug", "error: " + ex.getMessage(), ex);
		// }

	}

	private StringBuilder inputStreamToString(InputStream is) {

		String rLine = "";
		StringBuilder answer = new StringBuilder();

		InputStreamReader isr = new InputStreamReader(is);

		BufferedReader rd = new BufferedReader(isr);

		try {
			while ((rLine = rd.readLine()) != null) {
				answer.append(rLine);
			}
		}

		catch (IOException e) {
			e.printStackTrace();
		}
		return answer;

	}
}
