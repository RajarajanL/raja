package app.android.fmac.items;

public class FriensItem {
	private String friendName;
	private int userId;
	private int scoRe;
	private String friendImage;

	public FriensItem(int userid, String friendname, String friendimage,
			int score) {
		friendName = friendname;
		userId = userid;
		scoRe = score;
		friendImage = friendimage;
	}

	public String getfriendName() {
		return friendName;
	}

	public int getuserId() {
		return userId;
	}

	public int getscoRe() {
		return scoRe;
	}

	public String getfriendImage() {
		return friendImage;
	}

}