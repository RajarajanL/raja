package app.android.fmac.items;

public class SubjectsItem {
	private String subjectTitle;
	private int subjectId;

	public SubjectsItem(int subjectid, String subjecttitle) {
		subjectId = subjectid;
		subjectTitle = subjecttitle;
	}

	public int getsubjectId() {
		return subjectId;
	}

	public String getsubjectTitle() {
		return subjectTitle;
	}

}