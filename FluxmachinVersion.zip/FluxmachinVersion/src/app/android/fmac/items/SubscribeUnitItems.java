package app.android.fmac.items;

public class SubscribeUnitItems {
	private String unitTitle;
	private int unitId;
	private Boolean unitSelected;

	public SubscribeUnitItems(int unitid, String unittitle,
			boolean unnitselected) {
		unitId = unitid;
		unitTitle = unittitle;
		unitSelected = unnitselected;
	}

	public int getunitId() {
		return unitId;
	}

	public String getunitTitle() {
		return unitTitle;
	}

	public Boolean getunitSelected() {
		return unitSelected;
	}

}
