package app.android.fmac.items;

public class UnitsItem {
	private String unitTitle;
	private int unitId;

	public UnitsItem(int unitid, String unittitle) {
		unitId = unitid;
		unitTitle = unittitle;
	}

	public int getunitId() {
		return unitId;
	}

	public String getunitTitle() {
		return unitTitle;
	}

}