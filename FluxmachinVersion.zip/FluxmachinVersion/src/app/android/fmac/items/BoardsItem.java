package app.android.fmac.items;

public class BoardsItem {
	private final String boardTitle;
	private final int boardId;
	private final String boardSlug;

	public BoardsItem(int boardid, String boardtitle, String boardslug) {
		boardId = boardid;
		boardTitle = boardtitle;
		boardSlug = boardslug;
	}

	public int getboardId() {
		return boardId;
	}

	public String getboardTitle() {
		return boardTitle;
	}

	public String getboardSlug() {
		return boardSlug;
	}

}