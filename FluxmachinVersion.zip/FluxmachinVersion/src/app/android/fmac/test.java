package app.android.fmac;

import android.app.Activity;

public class test extends Activity {

	//
	// public static void main(String[] args) {
	// calculateHashKey("app.android.fmac");
	// }
}
