package app.android.fmac;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import app.android.constants.Constans;
import app.android.fmac.utils.ApiHelper;

public class TestPage extends Activity {
	int guestionPodsition = 0;
	TextView question;
	Button ans1, ans2, ans3, ans4, next;
	String getUnits;
	JSONArray testJsonArray;
	String questionString;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.flux_flip_test_page);
		question = (TextView) findViewById(R.id.flux_flip_test_quest_tv);
		ans1 = (Button) findViewById(R.id.flux_flip_test_answer1_btn);
		ans2 = (Button) findViewById(R.id.flux_flip_test_answer2_btn);
		ans3 = (Button) findViewById(R.id.flux_flip_test_answer3_btn);
		ans4 = (Button) findViewById(R.id.flux_flip_test_answer4_btn);
		next = (Button) findViewById(R.id.flux_flip_test_next_btn);
		getUnits = getIntent().getExtras().getString("unitIds");
		questionString = ApiHelper
				.getHttpResponseAsString(Constans.GET_QUESTIONS + "&unit_ids="
						+ getUnits);
		try {
			testJsonArray = new JSONArray(questionString);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		LoadQuestion(guestionPodsition);
		next.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				LoadQuestion(guestionPodsition);

			}
		});
		// Bundle b = getIntent().getExtras();
		// String[] resultArr = b.getStringArray("selectedItems");
		// // ListView lv = (ListView) findViewById(R.id.test_page_listView);
		//
		// ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
		// android.R.layout.simple_list_item_1, resultArr);
		// // lv.setAdapter(adapter);
	}

	private void LoadQuestion(int guestionPodsition2) {
		// TODO Auto-generated method stub
		try {
			JSONObject testObject = testJsonArray
					.getJSONObject(guestionPodsition2);
			String questText = testObject.getString("question");
			String answe1 = testObject.getString("opt_1");
			String answe2 = testObject.getString("opt_2");
			String answe3 = testObject.getString("opt_3");
			String answe4 = testObject.getString("opt_4");
			final int correctAnswer = testObject.getInt("ans");
			question.setText(questText);
			ans1.setText(answe1);
			ans2.setText(answe2);
			ans3.setText(answe3);
			ans4.setText(answe4);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		guestionPodsition++;

	}

}
