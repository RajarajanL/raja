package app.android.fmac;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Html;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import app.android.constants.AnalyticsConstants;
import app.android.constants.Constans;
import app.android.fmac.adapters.FriendsAdapter;
import app.android.fmac.items.FriensItem;
import app.android.fmac.session.SessionHandler;
import app.android.fmac.utils.ApiHelper;
import app.android.fmac.utils.DetectNetworkConnection;
import app.android.fmac.vo.UserVO;
import app.android.horizontallist.HorizontalListview;

public class TestPageFluxmachine extends Activity {
	Button answer1Btn, answer2Btn, answer3Btn, answer4Btn, nextBtn, passBtn;
	ImageView backImv;
	TextView question, correctTxtView, wrongTxtView, timeLeftTxtView,
			scoreTxtView, highScoreTxtView, daySteakTxtView,
			userOneNameTxtView, userTwoNameTxtView, userThreeNameTxtView,
			userFourNameTxtView, userOneScoreTxtView, userTwoScoreTxtView,
			userThreeScoreTxtView, userFourScoreTxtView, outOfQuestions;
	ScrollView newScroll;
	JSONArray userFriends;
	List<JSONObject> fluxTestFlip;
	List<JSONObject> fluxTest;
	List<FriensItem> friendsList;
	Boolean canAnswer = false;
	String getUnits;
	int getSubjectId;
	UserVO userVo = SessionHandler.get().getUserVO();
	Integer userId = userVo.getUserId();
	HorizontalListview friendScrollListView;
	// GridView friendScrollListView;
	int lastPossition = 0;
	int score = 0;
	int j = 0;
	int questionIndex = 0;
	int userHighScore;
	JSONArray testJsonArray;
	String questionString, sendSlug, sentTitle;
	boolean testComplete = false;
	int correctAnswer;
	final CounterClass timerclass = new CounterClass(61000, 5000);

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.test_page);

		FluxmachineApplication application = (FluxmachineApplication) getApplication();
		application.trackScreen(AnalyticsConstants.TEST_ANALYTIC);
		sentTitle = getIntent().getExtras().getString("sentTitle");
		sendSlug = getIntent().getExtras().getString("sendSlug");
		getSubjectId = getIntent().getExtras().getInt("getSubId");
		getUnits = getIntent().getExtras().getString("unitIds");
		// Log.i(String.valueOf(getSubjectId), "Subkect Id");
		// Log.i(String.valueOf(getUnits).trim(), "GetUnits");
		// Log.i(Constans.GET_BLINKS + "&user_id=" + userId + "&sub_link_id="
		// + getSubjectId + "&unit_ids=" + getUnits, "Blinks Url");
		// Log.i(Constans.GET_QUESTIONS + "&unit_ids=" + getUnits, "Questions");

		questionString = ApiHelper
				.getHttpResponseAsString(Constans.GET_QUESTIONS + "&unit_ids="
						+ getUnits);
		try {
			testJsonArray = new JSONArray(questionString);
		} catch (JSONException e) {

			e.printStackTrace();
		}
		FindViewById();
		LoadQuestionActivity(questionIndex);
		nextBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				timerclass.stopThread();
				LoadQuestionActivity(questionIndex);

			}
		});
		passBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				timerclass.stopThread();
				LoadQuestionActivity(questionIndex);
			}
		});
		// LoadTestPage();
		// LoadTestOnFlip();
		LoadFriendsScore();
	}

	private void LoadQuestionActivity(int questionPosition2) {

		timerclass.start();
		newScroll.pageScroll(View.FOCUS_UP);
		if (testComplete != true) {
			outOfQuestions.setText("Questions "
					+ String.valueOf(questionIndex + 1) + " Of "
					+ testJsonArray.length());
			answer1Btn.setBackgroundResource(R.drawable.flx_button);
			answer2Btn.setBackgroundResource(R.drawable.flx_button);
			answer3Btn.setBackgroundResource(R.drawable.flx_button);
			answer4Btn.setBackgroundResource(R.drawable.flx_button);
			nextBtn.setVisibility(View.GONE);
			passBtn.setVisibility(View.VISIBLE);
			try {
				JSONObject testObject = testJsonArray
						.getJSONObject(questionPosition2);

				int questId = testObject.getInt("q_id");
				String questText = testObject.getString("question");

				String answe1 = testObject.getString("opt_1");
				String answe2 = testObject.getString("opt_2");
				String answe3 = testObject.getString("opt_3");
				String answe4 = testObject.getString("opt_4");
				correctAnswer = testObject.getInt("ans");
				// Log.i(String.valueOf(correctAnswer), "Correct answer");
				canAnswer = true;
				question.setText(Html.fromHtml(Html.fromHtml(questText)
						.toString()));
				question.setTextSize(30);
				answer1Btn.setText(Html.fromHtml(Html.fromHtml(answe1)
						.toString()));
				answer2Btn.setText(Html.fromHtml(Html.fromHtml(answe2)
						.toString()));
				answer3Btn.setText(Html.fromHtml(Html.fromHtml(answe3)
						.toString()));
				answer4Btn.setText(Html.fromHtml(Html.fromHtml(answe4)
						.toString()));

				answer1Btn.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {

						timerclass.stopThread();
						if (canAnswer == true) {
							canAnswer = false;

							if (correctAnswer == 1) {

								answer1Btn
										.setBackgroundResource(R.drawable.correct);
								score++;
								scoreTxtView.setText("score : "
										+ String.valueOf(score));
								passBtn.setVisibility(View.GONE);
								nextBtn.setVisibility(View.VISIBLE);

							} else if (correctAnswer == 2) {
								testComplete = true;
								answer1Btn
										.setBackgroundResource(R.drawable.wrong_wrong);
								answer2Btn
										.setBackgroundResource(R.drawable.correct);
								passBtn.setVisibility(View.GONE);
								nextBtn.setVisibility(View.VISIBLE);
							} else if (correctAnswer == 3) {
								testComplete = true;
								answer1Btn
										.setBackgroundResource(R.drawable.wrong_wrong);
								answer3Btn
										.setBackgroundResource(R.drawable.correct);
								passBtn.setVisibility(View.GONE);
								nextBtn.setVisibility(View.VISIBLE);
							} else if (correctAnswer == 4) {
								testComplete = true;
								answer1Btn
										.setBackgroundResource(R.drawable.wrong_wrong);
								answer4Btn
										.setBackgroundResource(R.drawable.correct);
								passBtn.setVisibility(View.GONE);
								nextBtn.setVisibility(View.VISIBLE);
							}
						}
						answer1Btn.invalidate();
						answer2Btn.invalidate();
						answer3Btn.invalidate();
						answer4Btn.invalidate();
					}
				});

				answer2Btn.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {

						timerclass.stopThread();
						if (canAnswer == true) {
							canAnswer = false;
							if (correctAnswer == 1) {
								testComplete = true;
								answer1Btn
										.setBackgroundResource(R.drawable.correct);
								answer2Btn
										.setBackgroundResource(R.drawable.wrong_wrong);
								passBtn.setVisibility(View.GONE);
								nextBtn.setVisibility(View.VISIBLE);
							} else if (correctAnswer == 2) {
								answer2Btn
										.setBackgroundResource(R.drawable.correct);
								score++;
								scoreTxtView.setText("score : "
										+ String.valueOf(score));
								passBtn.setVisibility(View.GONE);
								nextBtn.setVisibility(View.VISIBLE);
							} else if (correctAnswer == 3) {
								testComplete = true;
								answer2Btn
										.setBackgroundResource(R.drawable.wrong_wrong);
								answer3Btn
										.setBackgroundResource(R.drawable.correct);
								passBtn.setVisibility(View.GONE);
								nextBtn.setVisibility(View.VISIBLE);
							} else if (correctAnswer == 4) {
								testComplete = true;
								answer2Btn
										.setBackgroundResource(R.drawable.wrong_wrong);
								answer4Btn
										.setBackgroundResource(R.drawable.correct);
								passBtn.setVisibility(View.GONE);
								nextBtn.setVisibility(View.VISIBLE);
							}
						}
						answer1Btn.invalidate();
						answer2Btn.invalidate();
						answer3Btn.invalidate();
						answer4Btn.invalidate();
					}
				});

				answer3Btn.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						timerclass.stopThread();

						if (canAnswer == true) {
							canAnswer = false;
							if (correctAnswer == 1) {
								testComplete = true;
								answer1Btn
										.setBackgroundResource(R.drawable.correct);
								answer3Btn
										.setBackgroundResource(R.drawable.wrong_wrong);
								passBtn.setVisibility(View.GONE);
								nextBtn.setVisibility(View.VISIBLE);
							} else if (correctAnswer == 2) {
								testComplete = true;
								answer2Btn
										.setBackgroundResource(R.drawable.correct);
								answer3Btn
										.setBackgroundResource(R.drawable.wrong_wrong);
								passBtn.setVisibility(View.GONE);
								nextBtn.setVisibility(View.VISIBLE);
							} else if (correctAnswer == 3) {
								answer3Btn
										.setBackgroundResource(R.drawable.correct);
								score++;
								scoreTxtView.setText("score : "
										+ String.valueOf(score));
								passBtn.setVisibility(View.GONE);
								nextBtn.setVisibility(View.VISIBLE);
							} else if (correctAnswer == 4) {
								testComplete = true;
								answer3Btn
										.setBackgroundResource(R.drawable.wrong_wrong);
								answer4Btn
										.setBackgroundResource(R.drawable.correct);
								passBtn.setVisibility(View.GONE);
								nextBtn.setVisibility(View.VISIBLE);
							}
						}
						answer1Btn.invalidate();
						answer2Btn.invalidate();
						answer3Btn.invalidate();
						answer4Btn.invalidate();
					}
				});

				answer4Btn.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						timerclass.stopThread();

						if (canAnswer == true) {
							canAnswer = false;
							if (correctAnswer == 1) {
								testComplete = true;
								answer1Btn
										.setBackgroundResource(R.drawable.correct);
								answer4Btn
										.setBackgroundResource(R.drawable.wrong_wrong);
								passBtn.setVisibility(View.GONE);
								nextBtn.setVisibility(View.VISIBLE);
							} else if (correctAnswer == 2) {
								testComplete = true;
								answer2Btn
										.setBackgroundResource(R.drawable.correct);
								answer4Btn
										.setBackgroundResource(R.drawable.wrong_wrong);
								passBtn.setVisibility(View.GONE);
								nextBtn.setVisibility(View.VISIBLE);
							} else if (correctAnswer == 3) {
								testComplete = true;
								answer3Btn
										.setBackgroundResource(R.drawable.correct);
								answer4Btn
										.setBackgroundResource(R.drawable.wrong_wrong);
								passBtn.setVisibility(View.GONE);
								nextBtn.setVisibility(View.VISIBLE);
							}

							else if (correctAnswer == 4) {

								answer4Btn
										.setBackgroundResource(R.drawable.correct);
								score++;
								scoreTxtView.setText("score : "
										+ String.valueOf(score));
								passBtn.setVisibility(View.GONE);
								nextBtn.setVisibility(View.VISIBLE);
							}
						}
						answer1Btn.invalidate();
						answer2Btn.invalidate();
						answer3Btn.invalidate();
						answer4Btn.invalidate();
					}
				});

			} catch (JSONException e) {

				e.printStackTrace();
			}
			questionIndex++;
			if (questionIndex == testJsonArray.length()) {
				testComplete = true;
			}
		} else {
			timerclass.stopThread();
			if (DetectNetworkConnection
					.checkInternetConnection(TestPageFluxmachine.this)) {
				LoadResult(score, getSubjectId, getUnits, sendSlug, sentTitle);
			} else {
				Toast.makeText(getApplicationContext(),
						"Please check your Internet Connection",
						Toast.LENGTH_LONG).show();
			}

		}

	}

	private void LoadResult(int scoreResult, int subId, String getUnits,
			String sendSlug, String sentTitle) {

		HttpClient mClient = new DefaultHttpClient();

		HttpGet get = new HttpGet(Constans.POST_SCORE + "&user_id=" + userId
				+ "&score=" + scoreResult + "&unit_ids=" + getUnits
				+ "&sub_link_id=" + subId);

		try {
			mClient.execute(get);

			finish();
		} catch (ClientProtocolException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}
		Intent newIntent = new Intent(TestPageFluxmachine.this,
				ResultFluxmachine.class);
		newIntent.putExtra("sendSlug", sendSlug);
		newIntent.putExtra("scoreResult", scoreResult);
		newIntent.putExtra("userHighScore", userHighScore);
		newIntent.putExtra("subId", subId);
		newIntent.putExtra("getUnits", getUnits);
		newIntent.putExtra("sentTitle", sentTitle);
		// Log.i(sentTitle, "Board Title in Units Fluxmachine");
		startActivity(newIntent);

	}

	private void LoadFriendsScore() {
		String blinksUrl = Constans.GET_BLINKS + "&user_id=" + userId
				+ "&sub_link_id=" + getSubjectId + "&unit_ids=" + getUnits;
		// Log.i(blinksUrl, "Blinks Url");
		String testString = ApiHelper.getHttpResponseAsString(blinksUrl);
		// Log.i(testString, "test String");
		if (testString == null) {
			return;
		}
		try {
			JSONObject testJsonObject = new JSONObject(testString);
			userHighScore = testJsonObject.getInt("high_score");
			// Log.i(String.valueOf(userHighScore), "user Hogh Score");
			highScoreTxtView.setText(String.valueOf("High Score : "
					+ userHighScore));
			int userDayStreak = testJsonObject.getInt("day_streak");
			// Log.i(String.valueOf(userDayStreak), "user Day Streak");
			daySteakTxtView.setText(String.valueOf("Day Streak : "
					+ userDayStreak));
			int userOverAll = testJsonObject.getInt("overall");
			// Log.i(String.valueOf(userOverAll), "user over All");
			String userImage = testJsonObject.getString("user_image");
			// Log.i(userImage, "user Image");
			userFriends = testJsonObject.getJSONArray("friends");

			//
		} catch (JSONException e1) {

			e1.printStackTrace();
		}
		try {
			friendsList = new ArrayList<FriensItem>();
			if (userFriends == null) {
				return;
			}
			// Log.i(String.valueOf(userFriends), "User Friends#######");

			for (int i = 0; i < userFriends.length(); i++) {
				JSONObject friendsJsonObject = (JSONObject) userFriends.get(i);
				int userId = friendsJsonObject.getInt("user_id");
				// Log.i(String.valueOf(userId), "friend Hogh UserId Score");
				int scoreFriends = friendsJsonObject.getInt("high_score");
				// Log.i(String.valueOf(scoreFriends), "friend Hogh Score");
				String friendName = String.valueOf(friendsJsonObject
						.getString("name"));
				// Log.i(String.valueOf(friendName), "friend1 name");
				String friendImage = String.valueOf(friendsJsonObject
						.getString("user_image"));
				// Log.i(friendImage, "friend1 Image" + i);
				// String friendImage =
				// " http://www.clker.com/cliparts/b/1/f/a/1195445301811339265dagobert83_female_user_icon.svg.med.png";
				// Log.i(friendImage, "Friend Image");
				friendsList.add(new FriensItem(userId, String
						.valueOf(friendName), friendImage, scoreFriends));
			}

		} catch (JSONException e) {

			e.printStackTrace();
		}
		// Log.i(String.valueOf(friendsList), "User Friends List#######");
		ListAdapter classAdapter = new FriendsAdapter(friendsList, this);
		friendScrollListView.setAdapter(classAdapter);

	}

	private void FindViewById() {

		answer1Btn = (Button) findViewById(R.id.test_page_flux_answer1_btn);
		answer2Btn = (Button) findViewById(R.id.test_page_flux_answer2_btn);
		answer3Btn = (Button) findViewById(R.id.test_page_flux_answer3_btn);
		answer4Btn = (Button) findViewById(R.id.test_page_flux_answer4_btn);
		question = (TextView) findViewById(R.id.test_page_flux_question_tv);
		nextBtn = (Button) findViewById(R.id.test_page_flux_next_btn);
		passBtn = (Button) findViewById(R.id.test_page_flux_pass_btn);
		outOfQuestions = (TextView) findViewById(R.id.test_page_flux_out_of_questions_tv);
		scoreTxtView = (TextView) findViewById(R.id.test_page_flux_score_tv);
		highScoreTxtView = (TextView) findViewById(R.id.test_page_flux_high_score_tv);
		daySteakTxtView = (TextView) findViewById(R.id.test_page_flux_day_streak_tv);
		friendScrollListView = (HorizontalListview) findViewById(R.id.test_page_friends_scroll_gridview);
		newScroll = (ScrollView) findViewById(R.id.test_page_scroll_view);
		timeLeftTxtView = (TextView) findViewById(R.id.test_page_flux_time_tv);

	}

	@Override
	public void onBackPressed() {

		// UserVO userVO = SessionHandler.get().getUserVO();
		// if (userVO == null) {
		// super.onBackPressed();
		// } else {
		// Intent intent = new Intent(Intent.ACTION_MAIN);
		// intent.addCategory(Intent.CATEGORY_HOME);
		// intent.setFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
		//
		// startActivity(intent);
		//
		// }

	}

	public class CounterClass extends CountDownTimer {

		public CounterClass(long millisInFuture, long countDownInterval) {
			super(millisInFuture, countDownInterval);
		}

		@SuppressLint({ "NewApi", "DefaultLocale" })
		@TargetApi(Build.VERSION_CODES.GINGERBREAD)
		@Override
		public void onTick(long millisUntilFinished) {

			long millis = millisUntilFinished;
			// timer.setText("60");
			String hms = String.format("%02d",
			// TimeUnit.MILLISECONDS.toHours(millis),
			// TimeUnit.MILLISECONDS.toMinutes(millis)
			// - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS
			// .toHours(millis)),
					TimeUnit.MILLISECONDS.toSeconds(millis)
							- TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS
									.toMinutes(millis)));
			// System.out.println(hms);
			timeLeftTxtView.setText("Time Left :" + hms);
		}

		@Override
		public void onFinish() {

			// timeLeftTxtView.setText("Finish");
			checkAnswer(correctAnswer);
			// LoadResult(score, getSubjectId, getUnits, sendSlug, sentTitle);
			// cancel();
			// Toast.makeText(getApplicationContext(), "Over",
			// Toast.LENGTH_LONG)
			// .show();

		}

		public void stopThread() {
			cancel();
		}

	}

	public void checkAnswer(int correctAnswer2) {

		testComplete = true;
		if (correctAnswer2 == 1) {

			answer1Btn.setBackgroundResource(R.drawable.correct);
			passBtn.setVisibility(View.GONE);
			nextBtn.setVisibility(View.VISIBLE);
		} else if (correctAnswer2 == 2) {

			answer2Btn.setBackgroundResource(R.drawable.correct);

			passBtn.setVisibility(View.GONE);
			nextBtn.setVisibility(View.VISIBLE);
		} else if (correctAnswer2 == 3) {

			answer3Btn.setBackgroundResource(R.drawable.correct);

			passBtn.setVisibility(View.GONE);
			nextBtn.setVisibility(View.VISIBLE);
		}

		else if (correctAnswer2 == 4) {

			answer4Btn.setBackgroundResource(R.drawable.correct);

			passBtn.setVisibility(View.GONE);
			nextBtn.setVisibility(View.VISIBLE);

		}

	}

}
