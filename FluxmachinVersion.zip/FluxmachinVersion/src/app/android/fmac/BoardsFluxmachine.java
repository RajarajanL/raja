package app.android.fmac;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import app.android.constants.AnalyticsConstants;
import app.android.constants.Constans;
import app.android.fmac.adapters.BoardsAdapter;
import app.android.fmac.items.BoardsItem;
import app.android.fmac.session.SessionHandler;
import app.android.fmac.utils.ApiHelper;
import app.android.fmac.utils.DetectNetworkConnection;
import app.android.fmac.vo.UserVO;

public class BoardsFluxmachine extends Activity implements OnClickListener {
	ImageView backImv, menuImv;
	ListView boardListView;
	String[] boards = new String[] { "TamilNadu StateBoard", "Aptitude",
			"Gate", "TANCET", "G-Mate", "TNPSC", "Group-I", "Group-II",
			"Group-IV", "General Knowledge", "CAT", "UPSC", "MATHS", };
	List<BoardsItem> boardItemList = new ArrayList<BoardsItem>();
	TextView userName;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.bloards_flux);
		FluxmachineApplication application = (FluxmachineApplication) getApplication();
		application.trackScreen(AnalyticsConstants.BOARDS_ANALYTIC);

		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
				.permitAll().build();
		StrictMode.setThreadPolicy(policy);

		menuImv = (ImageView) findViewById(R.id.boards_flux_menu_imv);
		menuImv.setOnClickListener(this);
		boardListView = (ListView) findViewById(R.id.boards_flux_board_list_lv);
		userName = (TextView) findViewById(R.id.board_user_name_tv);
		final UserVO userVO = SessionHandler.get().getUserVO();
		// Log.i(String.valueOf(userVO.getUserId()) + userVO.getEmail()
		// + userVO.getfName() + userVO.getlName(), "User Vo");
		if (null != userVO) {
			userName.setText("Welcome, " + userVO.getfName() + " "
					+ userVO.getlName());

		}

		// ArrayAdapter<String> boardAdapterList = new
		// ArrayAdapter<String>(this,
		// R.layout.boards_adapter, R.id.board_adap_textView, boards);
		// boardListView.setAdapter(boardAdapterList);

		try {
			String boardString = ApiHelper
					.getHttpResponseAsString(Constans.GET_BOARDS);

			JSONArray boardsJsonArray = new JSONArray(boardString);

			for (int i = 0; i < boardsJsonArray.length(); i++) {
				JSONObject boardJOBj = (JSONObject) boardsJsonArray.get(i);
				String boardSlug = boardJOBj.getString("board_slug");
				int boardId = boardJOBj.getInt("board_id");
				String boardName = boardJOBj.getString("board_name");
				boardItemList
						.add(new BoardsItem(boardId, boardName, boardSlug));
			}

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BoardsAdapter boardAdapter = new BoardsAdapter(boardItemList, this);
		boardListView.setAdapter(boardAdapter);

		boardListView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {

				BoardsItem item = boardItemList.get(position);

				Intent newIntent = new Intent(BoardsFluxmachine.this,
						SubjectsFluxmachine.class);
				int sendId = item.getboardId();
				// Log.i(item.getboardSlug() + item.getboardTitle()
				// + item.getboardId(), "Boards ");
				String sendSlug = item.getboardSlug();
				String sentTitle = item.getboardTitle();
				newIntent.putExtra("sendId", sendId);
				newIntent.putExtra("sendSlug", sendSlug);
				newIntent.putExtra("sentTitle", sentTitle);
				if (DetectNetworkConnection
						.checkInternetConnection(BoardsFluxmachine.this)) {
					startActivity(newIntent);
				} else {
					Toast.makeText(getApplicationContext(),
							"Please check your Internet Connection",
							Toast.LENGTH_LONG).show();
				}

				// int itemposition = position;
				// String itemvalue = (String) boardListView
				// .getItemAtPosition(position);
				// Toast.makeText(getApplicationContext(), "" + itemvalue,
				// Toast.LENGTH_SHORT).show();
				// if (itemposition == 0) {
				// Intent classifiesIntent = new Intent(BoardsFluxmachine.this,
				// SubjectsFluxmachine.class);
				// classifiesIntent.putExtra("position", itemposition);
				// classifiesIntent.putExtra("itemvalue", itemvalue);
				// startActivity(classifiesIntent);
				// }
				// else if (itemposition==1){
				// Intent shoppingIntent=new Intent(BoardsFluxmachine.this,
				// SubjectsFluxmachine.class);
				// shoppingIntent.putExtra("position", itemposition);
				// shoppingIntent.putExtra("itemvalue", itemvalue);
				// startActivity(shoppingIntent);
				// }
			}
		});

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {

		case R.id.boards_flux_menu_imv:
			Intent menuIntent = new Intent(BoardsFluxmachine.this,
					FluxmachineMenu.class);
			startActivity(menuIntent);
			break;

		default:
			break;
		}

	}

	@Override
	public void onBackPressed() {
		UserVO userVO = SessionHandler.get().getUserVO();
		if (userVO == null) {
			super.onBackPressed();
		} else {
			Intent intent = new Intent(Intent.ACTION_MAIN);
			intent.addCategory(Intent.CATEGORY_HOME);
			intent.setFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);

			startActivity(intent);

		}

	}
}
