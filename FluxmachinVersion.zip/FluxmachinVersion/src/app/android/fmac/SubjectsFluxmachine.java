package app.android.fmac;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import app.android.constants.AnalyticsConstants;
import app.android.constants.Constans;
import app.android.fmac.adapters.SubjectAdapter;
import app.android.fmac.items.SubjectsItem;
import app.android.fmac.utils.ApiHelper;
import app.android.fmac.utils.DetectNetworkConnection;

public class SubjectsFluxmachine extends Activity implements OnClickListener {
	TextView boardTitle;
	GridView subjectsGrid;
	ImageView backImv, menuImv;

	String[] aptitudeSubjects = new String[] { "Quantitative Aptitude",
			"Logical Reasoning", "Verbal Ability", "Verbal Resoning", };

	String[] tamilNaduStateBoardSubjects = new String[] { "Physics",
			"Chemistry", "Computer Science", "Maths", "Comerces", };
	List<SubjectsItem> subjectItemList = new ArrayList<SubjectsItem>();
	String sentTitle;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.subjects_fluxmachine);
		FluxmachineApplication application = (FluxmachineApplication) getApplication();
		application.trackScreen(AnalyticsConstants.SUBJECTS_ANALYTIC);
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
				.permitAll().build();
		StrictMode.setThreadPolicy(policy);

		boardTitle = (TextView) findViewById(R.id.subjects_flux_boardName_tv);
		int getId = getIntent().getExtras().getInt("sendId");
		sentTitle = getIntent().getExtras().getString("sentTitle");
		boardTitle.setText(sentTitle);
		subjectsGrid = (GridView) findViewById(R.id.subjects_flux_subject_grid_gv);

		backImv = (ImageView) findViewById(R.id.subjects_flux_back_imv);
		backImv.setOnClickListener(this);

		menuImv = (ImageView) findViewById(R.id.subjects_flux_menu_imv);
		menuImv.setOnClickListener(this);

		ArrayAdapter<String> boardAdapterList = new ArrayAdapter<String>(this,
				R.layout.subjects_adapter, R.id.subjects_adapter_txt_tv,
				aptitudeSubjects);

		ArrayAdapter<String> boardAdapterList1 = new ArrayAdapter<String>(this,
				R.layout.subjects_adapter, R.id.subjects_adapter_txt_tv,
				tamilNaduStateBoardSubjects);
		final String sendSlug = getIntent().getExtras().getString("sendSlug");
		// Log.i(sendSlug, "Board Slug");

		try {
			String subjectString = ApiHelper
					.getHttpResponseAsString(Constans.GET_SUBJECTS
							+ "&board_slug=" + sendSlug);
			JSONArray subjectJsonArray = new JSONArray(subjectString);

			for (int i = 0; i < subjectJsonArray.length(); i++) {
				JSONObject subjectJOBj = (JSONObject) subjectJsonArray.get(i);
				int subjectId = subjectJOBj.getInt("sub_link_id");
				String subjectName = subjectJOBj.getString("subject_name");
				subjectItemList.add(new SubjectsItem(subjectId, subjectName));
			}

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		SubjectAdapter subjectAdapter = new SubjectAdapter(subjectItemList,
				this);
		subjectsGrid.setAdapter(subjectAdapter);

		// if(getId!=0){
		// subjectsGrid.setAdapter(boardAdapterList);
		// }else if(getId==1){
		// subjectsGrid.setAdapter(boardAdapterList1);
		// }
		subjectsGrid.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1,
					int position, long arg3) {
				// TODO Auto-generated method stub
				SubjectsItem item = subjectItemList.get(position);
				Intent subjectIntent = new Intent(SubjectsFluxmachine.this,
						UnitFluxMachineNew.class);
				String subjectName = item.getsubjectTitle();
				int subjectId = item.getsubjectId();
				subjectIntent.putExtra("subjectId", subjectId);
				subjectIntent.putExtra("subjectName", subjectName);
				subjectIntent.putExtra("sendSlug", sendSlug);
				subjectIntent.putExtra("sentTitle", sentTitle);

				if (DetectNetworkConnection
						.checkInternetConnection(SubjectsFluxmachine.this)) {
					startActivity(subjectIntent);
				} else {
					Toast.makeText(getApplicationContext(),
							"Please check your Internet Connection",
							Toast.LENGTH_LONG).show();
				}

			}
		});

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.subjects_flux_back_imv:
			Intent newIntent = new Intent(SubjectsFluxmachine.this,
					BoardsFluxmachine.class);
			if (DetectNetworkConnection
					.checkInternetConnection(SubjectsFluxmachine.this)) {
				startActivity(newIntent);
			} else {
				Toast.makeText(getApplicationContext(),
						"Please check your Internet Connection",
						Toast.LENGTH_LONG).show();
			}

			break;
		case R.id.subjects_flux_menu_imv:
			Intent newIntent1 = new Intent(getApplicationContext(),
					FluxmachineMenu.class);
			startActivity(newIntent1);
			break;

		default:
			break;
		}

	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		Intent newIntent = new Intent(SubjectsFluxmachine.this,
				BoardsFluxmachine.class);
		startActivity(newIntent);
		// UserVO userVO = SessionHandler.get().getUserVO();
		// if (userVO == null) {
		// super.onBackPressed();
		// } else {
		// Intent intent = new Intent(Intent.ACTION_MAIN);
		// intent.addCategory(Intent.CATEGORY_HOME);
		// intent.setFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
		//
		// startActivity(intent);
		//
		// }

	}

}
