package app.android.fmac;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.Signature;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v4.app.FragmentActivity;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;
import app.android.constants.AnalyticsConstants;
import app.android.constants.Constans;
import app.android.fmac.session.SessionHandler;
import app.android.fmac.utils.DetectNetworkConnection;
import app.android.fmac.vo.UserVO;

import com.facebook.AppEventsLogger;
import com.facebook.Session;
import com.facebook.SessionState;
import com.facebook.UiLifecycleHelper;
import com.facebook.model.GraphUser;
import com.facebook.widget.FacebookDialog;
import com.facebook.widget.LoginButton;

public class FluxmachineMainActivity extends FragmentActivity implements
		OnClickListener {
	private final String PENDING_ACTION_BUNDLE_KEY = "app.android.fmac:PendingAction";
	private LoginButton loginButton;
	private GraphUser user;
	private UiLifecycleHelper uiHelper;
	HttpEntity resEntity;

	private final Session.StatusCallback callback = new Session.StatusCallback() {
		@Override
		public void call(Session session, SessionState state,
				Exception exception) {
			onSessionStateChange(session, state, exception);
		}
	};

	private final FacebookDialog.Callback dialogCallback = new FacebookDialog.Callback() {
		@Override
		public void onError(FacebookDialog.PendingCall pendingCall,
				Exception error, Bundle data) {
			Log.d("HelloFacebook", String.format("Error: %s", error.toString()));
		}

		@Override
		public void onComplete(FacebookDialog.PendingCall pendingCall,
				Bundle data) {
			Log.d("HelloFacebook", "Success!");
		}
	};

	Button registerBtn, signIn, fbLogin;
	EditText email, password;
	String loginUrl = Constans.FLUX_LOGIN;
	// UserVO user;
	TextView newUser;
	public static final String My_USER_DATA = "my_user_data";
	SharedPreferences sharedpreferences;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		sharedpreferences = getSharedPreferences(My_USER_DATA,
				Context.MODE_PRIVATE);
		super.onCreate(savedInstanceState);
		uiHelper = new UiLifecycleHelper(this, callback);
		uiHelper.onCreate(savedInstanceState);

		if (savedInstanceState != null) {
			String name = savedInstanceState
					.getString(PENDING_ACTION_BUNDLE_KEY);
			// pendingAction = PendingAction.valueOf(name);
		}

		setContentView(R.layout.flux_log_in_version1);
		calculateHashKey("app.android.fmac");
		FluxmachineApplication application = (FluxmachineApplication) getApplication();
		application.trackScreen(AnalyticsConstants.LOGIN_ANALYTIC);
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
				.permitAll().build();
		StrictMode.setThreadPolicy(policy);

		loginButton = (LoginButton) findViewById(R.id.login_button_version1);
		loginButton.setBackgroundResource(R.drawable.fblogin111);
		loginButton.setReadPermissions("email");
		loginButton.setReadPermissions("");
		loginButton
				.setUserInfoChangedCallback(new LoginButton.UserInfoChangedCallback() {
					@Override
					public void onUserInfoFetched(GraphUser user) {

						FluxmachineMainActivity.this.user = user;
						updateUI();

					}
				});

		registerBtn = (Button) findViewById(R.id.flux_log1_forgot_btn);
		registerBtn.setOnClickListener(this);
		signIn = (Button) findViewById(R.id.flux_log1_sigIn_btn);
		signIn.setOnClickListener(this);
		email = (EditText) findViewById(R.id.flux_log1_email_et);
		password = (EditText) findViewById(R.id.flux_log1_password_et);

		password.setOnEditorActionListener(new OnEditorActionListener() {
			@Override
			public boolean onEditorAction(TextView v, int actionId,
					KeyEvent event) {
				if ((event != null && (event.getKeyCode() == KeyEvent.KEYCODE_ENTER))
						|| (actionId == EditorInfo.IME_ACTION_DONE)) {
					// Log.i("Enter", "Enter pressed");
					logIn();
				}
				return false;
			}
		});

		newUser = (TextView) findViewById(R.id.flux_log_vetion_newUser_tv);
		String udata = "Register";
		SpannableString content = new SpannableString(udata);
		content.setSpan(new UnderlineSpan(), 0, udata.length(), 0);
		newUser.setText(content);
		newUser.setOnClickListener(this);

	}

	private void calculateHashKey(String yourPackageName) {
		try {
			PackageInfo info = getPackageManager().getPackageInfo(
					yourPackageName, PackageManager.GET_SIGNATURES);
			for (Signature signature : info.signatures) {
				MessageDigest md = MessageDigest.getInstance("SHA");
				md.update(signature.toByteArray());
				// Log.d("KeyHash:",
				// Base64.encodeToString(md.digest(), Base64.DEFAULT));
			}
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.fluxmachine_main, menu);
		return true;
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.flux_log1_forgot_btn:
			Intent forgotIntent = new Intent(FluxmachineMainActivity.this,
					ForgotPassword.class);
			startActivity(forgotIntent);
			break;
		case R.id.flux_log1_sigIn_btn:
			logIn();

			break;

		case R.id.flux_log_vetion_newUser_tv:
			Intent registerIntent = new Intent(FluxmachineMainActivity.this,
					RegisterFluxmachine.class);
			startActivity(registerIntent);

			break;

		default:
			break;
		}

	}

	private void logIn() {
		if (DetectNetworkConnection
				.checkInternetConnection(FluxmachineMainActivity.this)) {
			String emailText = email.getText().toString();
			String passwordText = password.getText().toString();
			if (email.length() == 0) {
				email.setError("Please enter the login email address");
				email.setFocusable(true);
			} else if (passwordText.length() == 0) {
				password.setError("Please enter the password");
				password.setFocusable(true);
			} else {
				HttpClient loginHttpclient = new DefaultHttpClient();
				// Log.i(loginUrl, "log iN Url");
				HttpPost loginHttppost = new HttpPost(loginUrl + "&email="
						+ emailText + "&password=" + passwordText);

				// Log.i(loginUrl + "&email=" + emailText + "&password="
				// + passwordText, "ghjfhgkj");

				try {
					HttpResponse loginHttpResponse = loginHttpclient
							.execute(loginHttppost);
					String loginJsonResult = inputStreamToString(
							loginHttpResponse.getEntity().getContent())
							.toString();
					JSONObject loginJObj = new JSONObject(loginJsonResult);
					Integer status = loginJObj.getInt("status");
					// Integer status = 1;
					if (status == 1) {
						Integer userId = loginJObj.getInt("user_id");
						String firstName = loginJObj.getString("f_name");
						String loginEmail = loginJObj.getString("email");
						String lastName = loginJObj.getString("l_name");
						String userImage = loginJObj.getString("user_image");
						UserVO user = new UserVO(userId, firstName, lastName,
								loginEmail, userImage);
						SessionHandler.get().setUserVO(user, sharedpreferences);
						Intent logInIntent = new Intent(
								FluxmachineMainActivity.this,
								BoardsFluxmachine.class);
						startActivity(logInIntent);
					} else {
						Toast.makeText(getApplicationContext(),
								"Invalid Login Credentials", Toast.LENGTH_SHORT)
								.show();
					}

				} catch (ClientProtocolException e) {

					e.printStackTrace();
				} catch (IOException e) {

					e.printStackTrace();
				} catch (JSONException e) {

					e.printStackTrace();
				}

			}
		} else {

			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setMessage(
					"Looks like you do not have connectivity. Turn on your internet connection")
					.setPositiveButton("Ok", dialogClickListener)
					.setNegativeButton("Cancel", dialogClickListener).show();

		}

	}

	DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {

		@Override
		public void onClick(DialogInterface dialog, int which) {
			switch (which) {
			case DialogInterface.BUTTON_POSITIVE:
				// Yes button clicked
				startActivity(new Intent(
						android.provider.Settings.ACTION_WIRELESS_SETTINGS));
				break;

			case DialogInterface.BUTTON_NEGATIVE:
				// No button clicked
				Toast.makeText(FluxmachineMainActivity.this,
						"You Do not have Internet Connection",
						Toast.LENGTH_LONG).show();
				break;
			}
		}
	};

	@Override
	public void onBackPressed() {
		Intent intent = new Intent(Intent.ACTION_MAIN);
		intent.addCategory(Intent.CATEGORY_HOME);
		intent.setFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
		startActivity(intent);

	}

	private StringBuilder inputStreamToString(InputStream is) {

		String rLine = "";
		StringBuilder answer = new StringBuilder();

		InputStreamReader isr = new InputStreamReader(is);

		BufferedReader rd = new BufferedReader(isr);

		try {
			while ((rLine = rd.readLine()) != null) {
				answer.append(rLine);
			}
		}

		catch (IOException e) {
			e.printStackTrace();
		}
		return answer;

	}

	@Override
	protected void onResume() {
		super.onResume();
		uiHelper.onResume();

		AppEventsLogger.activateApp(this);

		// updateUI();
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		uiHelper.onSaveInstanceState(outState);

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		uiHelper.onActivityResult(requestCode, resultCode, data, dialogCallback);
	}

	@Override
	public void onPause() {
		super.onPause();
		uiHelper.onPause();

		AppEventsLogger.deactivateApp(this);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		uiHelper.onDestroy();
	}

	private void onSessionStateChange(Session session, SessionState state,
			Exception exception) {

		// updateUI();
	}

	private void updateUI() {
		Session session = Session.getActiveSession();
		boolean enableButtons = (session != null && session.isOpened());

		if (enableButtons && user != null) {
			// Log.i(user.getFirstName(), "First Name");
			// Log.i(user.getLastName(), "Last name");
			// Log.i(user.getId(), "User Id");
			// Log.i(user.getName(), "Get Name");
			//
			// Log.i(String.valueOf(user), "User Values");

			final String fbString = user.getInnerJSONObject().toString();
			if (fbString == null || fbString.equals("")) {
				return;
			}
			String encodedFbValue;
			try {
				encodedFbValue = URLEncoder.encode(fbString, "utf-8");
				HttpClient loginHttpclient = new DefaultHttpClient();
				HttpPost loginFbHttppost = new HttpPost(Constans.FB_LOGIN
						+ "&fb_data=" + encodedFbValue);
				// Log.i(Constans.FB_LOGIN + "&fb_data=" + encodedFbValue,
				// "dfadf");

				HttpResponse loginFbHttpResponse = loginHttpclient
						.execute(loginFbHttppost);
				String loginFbJsonResult = inputStreamToString(
						loginFbHttpResponse.getEntity().getContent())
						.toString();
				JSONObject loginFbJObj = new JSONObject(loginFbJsonResult);

				Integer userId = loginFbJObj.getInt("user_id");
				String firstName = loginFbJObj.getString("f_name");
				String loginEmail = loginFbJObj.getString("email");
				String lastName = loginFbJObj.getString("l_name");
				String userImage = loginFbJObj.getString("img");
				// Log.i(userImage, "Fb Image");
				session.closeAndClearTokenInformation();
				UserVO user = new UserVO(userId, firstName, lastName,
						loginEmail, userImage);
				SessionHandler.get().setUserVO(user, sharedpreferences);
				Intent logInIntent = new Intent(FluxmachineMainActivity.this,
						BoardsFluxmachine.class);
				startActivity(logInIntent);

			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			} catch (ClientProtocolException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// email.setText(user.getFirstName() + "," + user.getLastName());
		} else {
			// Log.i("Else Has been Called", "@@@");
		}
	}

}
