package app.android.fmac.utils;

import org.json.JSONObject;

import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.widget.ImageView;

public class DownLoadImageTask extends AsyncTask<ImageView, Void, Bitmap> {

	ImageView imageView = null;

	@Override
	protected Bitmap doInBackground(ImageView... imageViews) {
		this.imageView = imageViews[0];
		Bitmap bmp = null;
		try {
			JSONObject tags = (JSONObject) imageView.getTag();
			String imageUrl = tags.getString("url");
			boolean isRounded = tags.getBoolean("isRounded");
			int radius = tags.getInt("radius");
			bmp = (!isRounded) ? ImageHelper.getBitmapFromURL(imageUrl)
					: ImageHelper.getRoundedCornerBitmap(
							ImageHelper.getBitmapFromURL(imageUrl), radius);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bmp;
	}

	@Override
	protected void onPostExecute(Bitmap result) {
		imageView.setImageBitmap(result);
	}

}