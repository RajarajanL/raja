package app.android.fmac.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import app.android.fmac.R;
import app.android.fmac.items.FriensItem;

public class FriendsAdapterTwo extends ArrayAdapter<FriensItem> {
	private final LayoutInflater mInflater;

	public FriendsAdapterTwo(Context context, FriensItem values) {
		super(context, R.layout.friends_adapter);
		mInflater = (LayoutInflater) getContext().getSystemService(
				Context.LAYOUT_INFLATER_SERVICE);
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		Holder holder;
		if (convertView == null) {
			convertView = mInflater.inflate(R.layout.friends_adapter, parent,
					false);
			holder = new Holder();
			holder.friendName = (TextView) convertView
					.findViewById(R.id.friends_name_tv);
			holder.score = (TextView) convertView
					.findViewById(R.id.friend_score_tv);
			holder.imagefriend = (ImageView) convertView
					.findViewById(R.id.friend_imv);
			convertView.setTag(holder);
		} else {
			holder = (Holder) convertView.getTag();
		}
		holder.friendName.setText(getItem(position).getfriendName());
		holder.score.setText(String.valueOf(getItem(position).getscoRe()));
		holder.imagefriend.setBackgroundResource(R.drawable.ic_launcher);
		return convertView;
	}

	private static class Holder {
		public TextView score, friendName;
		public ImageView imagefriend;
	}
}
