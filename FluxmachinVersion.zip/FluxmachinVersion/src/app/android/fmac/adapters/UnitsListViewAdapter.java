package app.android.fmac.adapters;

import java.util.List;

import android.content.Context;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import app.android.fmac.R;
import app.android.fmac.items.UnitsItem;

public class UnitsListViewAdapter extends ArrayAdapter<UnitsItem> {
	Context context;
	LayoutInflater inflate;
	List<UnitsItem> unitList;
	private SparseBooleanArray mSelectedItemsIds;

	public UnitsListViewAdapter(Context context, int resourceId,
			List<UnitsItem> worldpopulationlist) {
		super(context, resourceId, worldpopulationlist);
		mSelectedItemsIds = new SparseBooleanArray();
		this.context = context;
		this.unitList = worldpopulationlist;
		inflate = LayoutInflater.from(context);
	}

	private class ViewHolder {
		TextView unidId;
		TextView unitName;
	}

	@Override
	public View getView(int position, View view, ViewGroup parent) {
		final ViewHolder holder;
		if (view == null) {
			holder = new ViewHolder();
			view = inflate.inflate(R.layout.unit_listview_item, null);
			holder.unidId = (TextView) view.findViewById(R.id.unit__idname_tv);
			holder.unitName = (TextView) view.findViewById(R.id.unit_name);
			view.setTag(holder);
		} else {
			holder = (ViewHolder) view.getTag();
		}
		holder.unidId.setText(String
				.valueOf(unitList.get(position).getunitId()));
		holder.unitName.setText(unitList.get(position).getunitTitle());
		holder.unidId.setVisibility(View.GONE);
		return view;

	}

	@Override
	public void remove(UnitsItem object) {
		// TODO Auto-generated method stub
		super.remove(object);
		notifyDataSetChanged();
	}

	public List<UnitsItem> getUnitList() {
		return unitList;

	}

	public void toggleSelection(int position) {
		selectView(position, !mSelectedItemsIds.get(position));
	}

	public void removeSelection() {
		mSelectedItemsIds = new SparseBooleanArray();
		notifyDataSetChanged();
	}

	public void selectView(int position, boolean value) {
		if (value)
			mSelectedItemsIds.put(position, value);
		else
			mSelectedItemsIds.delete(position);
		notifyDataSetChanged();
	}

	public int getSelectedCount() {
		return mSelectedItemsIds.size();
	}

	public SparseBooleanArray getSelectedIds() {
		return mSelectedItemsIds;
	}

}
