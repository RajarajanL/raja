package app.android.fmac.adapters;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import app.android.fmac.R;
import app.android.fmac.items.BoardsItem;

public class BoardsAdapter extends BaseAdapter {

	private List<BoardsItem> items;
	private Context context;
	private int numItems = 0;

	public BoardsAdapter(List<BoardsItem> items, Context context) {
		// TODO Auto-generated constructor stub
		this.items = items;
		this.context = context;
		this.numItems = items.size();
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return numItems;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return items.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		final BoardsItem item = items.get(position);
		LinearLayout itemLayout = (LinearLayout) LayoutInflater.from(context)
				.inflate(R.layout.boards_adapter, parent, false);
		TextView boardTitle = (TextView) itemLayout
				.findViewById(R.id.board_adap_textView);
		boardTitle.setText(item.getboardTitle());
		return itemLayout;
	}

}
