package app.android.fmac.adapters;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import app.android.fmac.R;
import app.android.fmac.items.UnitsItem;

public class UnitsAdapter extends BaseAdapter {
	private final List<UnitsItem> items;
	private final Context context;
	private int numItems = 0;

	public UnitsAdapter(List<UnitsItem> items, Context context) {
		this.items = items;
		this.context = context;
		this.numItems = items.size();
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return numItems;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return items.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub

		final UnitsItem item = items.get(position);
		LinearLayout itemLayout = (LinearLayout) LayoutInflater.from(context)
				.inflate(R.layout.unit_listview_item, parent, false);
		TextView subjectTitle = (TextView) itemLayout
				.findViewById(R.id.unit_name);
		subjectTitle.setText(item.getunitTitle());
		return itemLayout;

	}

}
