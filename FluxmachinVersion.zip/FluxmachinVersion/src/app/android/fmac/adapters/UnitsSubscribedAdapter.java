package app.android.fmac.adapters;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.LinearLayout;
import android.widget.TextView;
import app.android.fmac.R;
import app.android.fmac.items.SubscribeUnitItems;

public class UnitsSubscribedAdapter<T> extends BaseAdapter {

	private List<SubscribeUnitItems> items;
	ArrayList<T> mList;
	private Context context;

	SparseBooleanArray mSparseBooleanArray;
	LayoutInflater mInflater;

	public UnitsSubscribedAdapter(List<SubscribeUnitItems> items,
			Context context) {
		this.items = items;
		this.context = context;

		mSparseBooleanArray = new SparseBooleanArray();
	}

	public List<SubscribeUnitItems> getCheckedItems() {
		List<SubscribeUnitItems> mTempArry = new ArrayList<SubscribeUnitItems>();
		for (int i = 0; i < items.size(); i++) {
			if (mSparseBooleanArray.get(i)) {
				mTempArry.add(items.get(i));
			}
		}
		return mTempArry;
	}

	@Override
	public int getCount() {
		return items.size();
	}

	@Override
	public Object getItem(int position) {
		return items.get(position);
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		// Get the current list item
		final SubscribeUnitItems item = items.get(position);
		final LinearLayout itemLayout = (LinearLayout) LayoutInflater.from(
				context).inflate(R.layout.unit_selection, parent, false);
		TextView tvTitle = (TextView) itemLayout.findViewById(R.id.unit_tv);
		tvTitle.setText(item.getunitTitle());
		CheckBox cBox = (CheckBox) itemLayout.findViewById(R.id.unit_ck);
		cBox.setTag(position);
		cBox.setChecked(item.getunitSelected());
		// cBox.setTag(position);
		// cBox.setChecked(mSparseBooleanArray.get(position));
		mSparseBooleanArray.put(position, item.getunitSelected());
		cBox.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {
				// TODO Auto-generated method stub
				mSparseBooleanArray.put((Integer) buttonView.getTag(),
						isChecked);
			}
		});
		return itemLayout;
	}

}
