package app.android.fmac.adapters;

import java.util.List;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import app.android.fmac.R;
import app.android.fmac.items.FriensItem;
import app.android.fmac.utils.ImageHelper;

public class FriendsAdapter extends BaseAdapter {

	private final List<FriensItem> items;
	private final Context context;
	private int numItems = 0;

	public FriendsAdapter(List<FriensItem> items, Context context) {
		this.items = items;
		this.context = context;
		this.numItems = items.size();
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return numItems;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return items.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@SuppressLint("ViewHolder")
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		final FriensItem item = items.get(position);
		final LinearLayout itemLayout = (LinearLayout) LayoutInflater.from(
				context).inflate(R.layout.friends_adapter, parent, false);
		TextView friendName = (TextView) itemLayout
				.findViewById(R.id.friends_name_tv);
		friendName.setText(item.getfriendName());
		TextView frindScore = (TextView) itemLayout
				.findViewById(R.id.friend_score_tv);
		frindScore.setText(String.valueOf(item.getscoRe()));
		ImageView friendImage = (ImageView) itemLayout
				.findViewById(R.id.friend_imv);
		String image = item.getfriendImage();
		// Log.i(image, "Image Tag");

		ImageHelper.loadImage(friendImage, image, true, true, 30);
		// if (image.equals("") || image == null) {
		// Log.i(image, "User Image Empty");
		//
		// } else {
		// Log.i(image, "image");

		// ImageHelper.loadImage(friendImage, image, false, false, 30);
		// Bitmap finalImg = ImageHelper.getBitmapFromURL(image);
		// friendImage.setImageBitmap(finalImg);

		// URL url;
		// try {
		// url = new URL(image);
		// Bitmap bmp;
		// bmp = BitmapFactory.decodeStream(url.openConnection()
		// .getInputStream());
		// friendImage.setImageBitmap(bmp);
		// } catch (MalformedURLException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// } catch (IOException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		//
		// // Bitmap finalImg = ImageHelper.getBitmapFromURL(image);
		// // friendImage.setImageBitmap(finalImg);

		// }

		return itemLayout;
	}

}
