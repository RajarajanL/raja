package app.android.fmac;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import app.android.fmac.session.SessionHandler;
import app.android.fmac.vo.UserVO;

public class FluxmachineMenu extends Activity implements OnClickListener {
	RelativeLayout backRlaay;
	ListView settList;
	UserVO userVO;
	String[] settings = new String[] { "Log Out", };
	public static final String My_USER_DATA = "my_user_data";
	SharedPreferences sharedpreferences;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		sharedpreferences = getSharedPreferences(My_USER_DATA,
				Context.MODE_PRIVATE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.flux_menu);
		backRlaay = (RelativeLayout) findViewById(R.id.sett_relay_rl);
		backRlaay.setOnClickListener(this);
		settList = (ListView) findViewById(R.id.sett_listy_lv);
		ArrayAdapter<String> settingAdapterList = new ArrayAdapter<String>(
				this, R.layout.menu_adapter, R.id.menu_adap_textView, settings);
		settList.setAdapter(settingAdapterList);
		userVO = SessionHandler.get().getUserVO();

		settList.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				int itemposition = position;
				String itemvalue = (String) settList
						.getItemAtPosition(position);
				if (itemposition == 0) {
					Intent classifiesIntent = new Intent(FluxmachineMenu.this,
							FluxmachineMainActivity.class);
					SessionHandler.get().removeUser(sharedpreferences);
					startActivity(classifiesIntent);
					// } else if (itemposition == 1) {
					// Intent shoppingIntent = new Intent(FluxmachineMenu.this,
					// ChangePassword.class);
					// startActivity(shoppingIntent);
					// } else if (itemposition == 2) {
					//
					// Intent shoppingIntent = new Intent(FluxmachineMenu.this,
					// FluxmachineMainActivity.class);
					// userVO = null;
					//
					// startActivity(shoppingIntent);
				}
			}
		});

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.sett_relay_rl:
			finish();
			break;

		default:
			break;
		}

	}

}
