package app.android.fmac;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import app.android.constants.Constans;

public class ForgotPassword extends Activity implements OnClickListener {
	Button sendPass, cancel;
	EditText eMail;
	String eMAIL;
	HttpEntity resEntity;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.forgot_password);
		eMail = (EditText) findViewById(R.id.forgot_pass_email_et);

		sendPass = (Button) findViewById(R.id.forgot_pass_sendpass_btn);
		sendPass.setOnClickListener(this);
		cancel = (Button) findViewById(R.id.forgot_pass_cancel_btn);
		cancel.setOnClickListener(this);

	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.forgot_pass_cancel_btn:
			finish();
			break;
		case R.id.forgot_pass_sendpass_btn:

			eMAIL = eMail.getText().toString();
			if (eMAIL == null || eMAIL.equals("")) {
				return;
			} else {
				sendPassword(eMAIL);
			}

			break;

		default:
			break;
		}

	}

	protected void sendPassword(String eMAIL2) {

		HttpClient loginHttpclient = new DefaultHttpClient();

		HttpPost loginHttppost = new HttpPost(Constans.FORGOT_PASSWORD
				+ "&email=" + eMAIL2);

		try {
			HttpResponse loginHttpResponse = loginHttpclient
					.execute(loginHttppost);
			String loginJsonResult = inputStreamToString(
					loginHttpResponse.getEntity().getContent()).toString();
			if (loginJsonResult.equals("1") || loginJsonResult == "1") {
				Toast.makeText(getApplicationContext(), "Email has been sent ",
						Toast.LENGTH_SHORT).show();
			} else {
				Toast.makeText(getApplicationContext(), "NOt Registered",
						Toast.LENGTH_SHORT).show();
			}

		} catch (ClientProtocolException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	private StringBuilder inputStreamToString(InputStream is) {

		String rLine = "";
		StringBuilder answer = new StringBuilder();

		InputStreamReader isr = new InputStreamReader(is);

		BufferedReader rd = new BufferedReader(isr);

		try {
			while ((rLine = rd.readLine()) != null) {
				answer.append(rLine);
			}
		}

		catch (IOException e) {
			e.printStackTrace();
		}
		return answer;

	}

}
